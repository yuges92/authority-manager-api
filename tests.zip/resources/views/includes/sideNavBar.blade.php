<aside class="left-sidebar">
  <!-- Sidebar scroll-->
  <div class="scroll-sidebar">
    <!-- Sidebar navigation-->
    <nav class="sidebar-nav">
      <ul id="sidebarnav">
        <li><a href="/packages" aria-expanded="false"><i class="fas fa-cubes"></i><span class="hide-menu">Sara Packages</span></a></li>
        <li class="nav-small-cap">Authorities</li>
        <li class="">
          <a class="has-arrow " href="#" aria-expanded="false"><i class="fas fa-users"></i> <span class="hide-menu">Authorities</span></a>
          <ul aria-expanded="false" class="collapse" style="height: 10px;">
            <li><a href="map-google.html"><i class="fas fa-user-plus"></i> New Authority</a></li>
            <li><a href="map-vector.html"><i class="fas fa-user"></i> View</a></li>
          </ul>
        </li>
      </ul>
    </nav>
    <!-- End Sidebar navigation -->
  </div>
  <!-- End Sidebar scroll-->
  <!-- Bottom points-->
  <div class="sidebar-footer">
    <!-- item--><a href="" class="link" data-toggle="tooltip" title="Settings"><i class="fas fa-cogs"></i></a>
    <!-- item--><a href="" class="link" data-toggle="tooltip" title="Email"><i class="fas fa-envelope"></i></a>
    <!-- item--><a href="" class="link" data-toggle="tooltip" title="Logout"><i class="fas fa-power-off"></i></a> </div>
    <!-- End Bottom points-->
  </aside>

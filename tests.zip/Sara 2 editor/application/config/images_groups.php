<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| Foreign Characters
| -------------------------------------------------------------------
| This file contains an array of foreign characters for transliteration
| conversion used by the Text helper
|
*/
/*
|--------------------------------------------------------------------------
| Images Groups Select Box Options
|--------------------------------------------------------------------------
|
| The options for the select box with the images groups in welcome.php controller
|
*/

$images_groups = array ();
$images_groups['Made Easy Editor']['mee_batch_import'] = array('value'=>'mee_batch_import', 'name'=>'Batch Import', 'path'=>'/mee/batch_import/');
$images_groups['Made Easy Editor']['mee_case_studies'] = array('value'=>'mee_case_studies', 'name'=>'Case Studies', 'path'=>'/mee/case_studies/');
$images_groups['Made Easy Editor']['mee_classes_photos'] = array('value'=>'mee_classes_photos', 'name'=>'Classes Photos', 'path'=>'/mee/classes_photos/');
$images_groups['Made Easy Editor']['mee_general_images'] = array('value'=>'mee_general_images', 'name'=>'General Images', 'path'=>'/mee/general_images/');
$images_groups['Made Easy Editor']['mee_group_sponsors'] = array('value'=>'mee_group_sponsors', 'name'=>'Group Sponsors', 'path'=>'/mee/group_sponsors/');
$images_groups['Made Easy Editor']['mee_pdfs'] = array('value'=>'mee_pdfs', 'name'=>'Pdfs', 'path'=>'/mee/pdfs/');
$images_groups['Made Easy Editor']['mee_product_sponsors'] = array('value'=>'mee_product_sponsors', 'name'=>'Product Sponsors', 'path'=>'/mee/product_sponsors/');
$images_groups['Made Easy Editor']['mee_products'] = array('value'=>'mee_products', 'name'=>'Products', 'path'=>'/mee/products/');
$images_groups['Made Easy Editor']['mee_scenarios'] = array('value'=>'mee_scenarios', 'name'=>'Scenarios', 'path'=>'/mee/scenarios/');
$images_groups['Made Easy Editor']['mee_sponsors'] = array('value'=>'mee_sponsors', 'name'=>'Sponsors', 'path'=>'/mee/sponsors/');
$images_groups['Made Easy Editor']['mee_supplier_product_docs'] = array('value'=>'mee_supplier_product_docs', 'name'=>'Supplier Product Docs', 'path'=>'/mee/supplier_product_docs/');
$images_groups['Made Easy Editor']['mee_suppliers'] = array('value'=>'mee_suppliers', 'name'=>'Suppliers', 'path'=>'/mee/suppliers/');
$images_groups['Made Easy Editor']['mee_trade_associations'] = array('value'=>'mee_trade_associations', 'name'=>'Trade Associations', 'path'=>'/mee/trade_associations/');
$images_groups['Ask Sara']['asksara_answers_images'] = array('value'=>'asksara_answers_images', 'name'=>'Answers Images', 'path'=>'/sara4/dynamic/answers_images/');
$images_groups['Ask Sara']['asksara_authority_images'] = array('value'=>'asksara_authority_images', 'name'=>'Authority Images', 'path'=>'/sara4/dynamic/authority_images/');
$images_groups['Ask Sara']['asksara_clients'] = array('value'=>'asksara_clients', 'name'=>'Clients', 'path'=>'/sara4/dynamic/clients/');
$images_groups['Ask Sara']['asksara_disclaimers'] = array('value'=>'asksara_disclaimers', 'name'=>'Disclaimers', 'path'=>'/sara4/dynamic/disclaimers/');
$images_groups['Ask Sara']['asksara_group_authority_images'] = array('value'=>'asksara_group_authority_images', 'name'=>'Group Authority Images', 'path'=>'/sara4/dynamic/group_authority_images/');
$images_groups['Ask Sara']['asksara_group_images'] = array('value'=>'asksara_group_images', 'name'=>'Group Images', 'path'=>'/sara4/dynamic/group_images/');
$images_groups['Ask Sara']['asksara_ideas'] = array('value'=>'asksara_ideas', 'name'=>'Ideas', 'path'=>'/sara4/dynamic/ideas/');
$images_groups['Ask Sara']['asksara_producttypes_images'] = array('value'=>'asksara_producttypes_images', 'name'=>'Product Types Images', 'path'=>'/sara4/dynamic/producttypes_images/');
$images_groups['Ask Sara']['asksara_question_answer_group_images'] = array('value'=>'asksara_question_answer_group_images', 'name'=>'Question Answer Group Images', 'path'=>'/sara4/dynamic/question_answer_group_images/');
$images_groups['Ask Sara']['asksara_statements'] = array('value'=>'asksara_statements', 'name'=>'Statements', 'path'=>'/sara4/dynamic/statements/');
$images_groups['Ask Sara']['asksara_topic_images'] = array('value'=>'asksara_topic_images', 'name'=>'Topic Images', 'path'=>'/sara4/dynamic/topic_images/');


/* End of file foreign_chars.php */
/* Location: ./application/config/foreign_chars.php */
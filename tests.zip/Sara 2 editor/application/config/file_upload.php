<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/*
  |--------------------------------------------------------------------------
  | Configuration For Uploaded Files
  |--------------------------------------------------------------------------
  |
 */
$config['question_picture'] = array(
    'upload_path' => SARA_QUESTIONS_PICS_DIR,
    'upload_url' => SARA_QUESTIONS_PICS_URL,
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
$config['idea_picture'] = array(
    'upload_path' => SARA_IDEAS_PICS_DIR,
    'upload_url' => SARA_IDEAS_PICS_URL,
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
$config['answer_picture'] = array(
    'upload_path' => SARA_ANSWERS_PICS_DIR,
    'upload_url' => SARA_ANSWERS_PICS_URL,
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
$config['authority_picture'] = array(
    'upload_path' => SARA_AUTHORITY_PICS_DIR,
    'upload_url' => SARA_AUTHORITY_PICS_URL,
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
$config['disclaimer_picture'] = array(
    'upload_path' => SARA_DISCLAIMERS_PICS_DIR,
    'upload_url' => SARA_DISCLAIMERS_PICS_URL,
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
/*
$config['topic_picture'] = array(
    'upload_path' => "C:/Websites/reable/public/assets/img/topic/",
    'upload_url' => "dev.reable.dlf.org.uk/assets/img/topic/",
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
$config['section_picture'] = array(
    'upload_path' => "C:/Websites/reable/public/assets/img/section/",
    'upload_url' => "dev.reable.dlf.org.uk/assets/img/section/",
    'allowed_types' => "jpg|jpeg",
    'overwrite' => TRUE,
    'remove_spaces' => TRUE,
    'max_size' => "1000KB"
);
 */

/* End of file file_upload.php */
/* Location: ./application/config/file_upload.php */
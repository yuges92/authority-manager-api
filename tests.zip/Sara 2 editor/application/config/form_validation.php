<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/*
  |--------------------------------------------------------------------------
  | Rules for Save Selfserve User Form
  |--------------------------------------------------------------------------
  |
  | XCXCXC.
  |
 */

$config['save_selfserve_user'] = array(
    'uid' => array(
        'field' => 'uid',
        'label' => 'User Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[10000]'
    ),
    'username' => array(
        'field' => 'username',
        'label' => 'Username',
        'rules' => 'trim|required|valid_email'
    ),
    
    'firstname' => array(
        'field' => 'firstname',
        'label' => 'Firstname',
        'rules' => 'trim|max_length[30]|name_validation'
    ),
    'lastname' => array(
        'field' => 'lastname',
        'label' => 'Lastname',
        'rules' => 'trim|max_length[25]|name_validation'
    ),
    'phone' => array(
        'field' => 'phone',
        'label' => 'Phone',
        'rules' => 'trim|required|max_length[20]'
    ),
    'company' => array(
        'field' => 'company',
        'label' => 'Company',
        'rules' => 'trim|required|max_length[60]|supplier_name_validation'
    ),
    'supplierId' => array(
        'field' => 'supplierId',
        'label' => 'Supplier Id',
        'rules' => 'trim|supplier_id_validation'
    ),
    'active' => array(
        'field' => 'active',
        'label' => 'Active',
        'rules' => 'trim|min_length[1]|exact_length[1]|callback_active_check'
    )
);


$config['edit_authority'] = array(
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'supplier_id' => array(
        'field' => 'supplier_id',
        'label' => 'Supplier Id',
        'rules' => 'trim|supplier_id_validation'
    ),
    'full_name' => array(
        'field' => 'full_name',
        'label' => 'Full Name',
        'rules' => 'trim|required|max_length[120]'
    ),
    'short_name' => array(
        'field' => 'short_name',
        'label' => 'Short Name',
        'rules' => 'trim|required|max_length[50]|authority_short_name_validation'
    ),
    'authority_type' => array(
        'field' => 'authority_type',
        'label' => 'Authority Type',
        'rules' => 'trim|authority_type_check'
    ),
    'email' => array(
        'field' => 'email',
        'label' => 'Email',
        'rules' => 'trim|max_length[255]|valid_email'
    ),
    'local_authority_url' => array(
        'field' => 'local_authority_url',
        'label' => 'Local Authority Url',
        'rules' => 'trim|max_length[255]|url_validation'
    ),
    'website' => array(
        'field' => 'website',
        'label' => 'Ask Question Url',
        'rules' => 'trim|max_length[255]|url_validation'
    ),
    'always_disclaimer' => array(
        'field' => 'always_disclaimer',
        'label' => 'Always Disclaimer',
        'rules' => 'trim|max_length[3]'
    ),
    'introduction' => array(
        'field' => 'introduction',
        'label' => 'Introduction',
        'rules' => 'trim|max_length[10000]'
    ),
    'report_results_message' => array(
        'field' => 'report_results_message',
        'label' => 'Report Results Message',
        'rules' => 'trim|max_length[10000]'
    ),
    'report_no_results_message' => array(
        'field' => 'report_no_results_message',
        'label' => 'Report No Results Message',
        'rules' => 'trim|max_length[10000]'
    ),
    'helpline_text' => array(
        'field' => 'helpline_text',
        'label' => 'Helpline',
        'rules' => 'trim|max_length[100]'
    ),
    'send_report_to_authority' => array(
        'field' => 'send_report_to_authority',
        'label' => 'Send Report to Authority',
        'rules' => 'trim|max_length[3]'
    ),
    'send_report_to_friend' => array(
        'field' => 'send_report_to_friend',
        'label' => 'Send Report to Friend',
        'rules' => 'trim|max_length[3]'
    ),
    'disclaimer_text' => array(
        'field' => 'disclaimer_text',
        'label' => 'Disclaimer Text',
        'rules' => 'trim|max_length[10000]'
    ),
    'disclaimer_text_cy' => array(
        'field' => 'disclaimer_text_cy',
        'label' => 'Disclaimer Text (Welsh)',
        'rules' => 'trim|max_length[10000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
    'local_authority' => array(
        'field' => 'local_authority',
        'label' => 'Local Authority',
        'rules' => 'trim|max_length[3]'
    ),
    'retailer_location' => array(
        'field' => 'retailer_location',
        'label' => 'Retailer Location',
        'rules' => 'trim|max_length[50]'
    ),
    'include_childrens_group' => array(
        'field' => 'include_childrens_group',
        'label' => 'Include Childrens Group',
        'rules' => 'trim|max_length[3]'
    ),
    'feedback_form_url' => array(
        'field' => 'feedback_form_url',
        'label' => 'Feedback Form URL',
        'rules' => 'trim|max_length[255]'
    ),
    'feedback_form_url_cy' => array(
        'field' => 'feedback_form_url_cy',
        'label' => 'Feedback Form URL (Welsh)',
        'rules' => 'trim|max_length[255]'
    ),
    'show_related_products' => array(
        'field' => 'show_related_products',
        'label' => 'Show Related Products',
        'rules' => 'trim|max_length[3]'
    ),
);

$config['new_authority'] = array(
    'supplier_id' => array(
        'field' => 'supplier_id',
        'label' => 'Supplier Id',
        'rules' => 'trim|supplier_id_validation'
    ),
    'full_name' => array(
        'field' => 'full_name',
        'label' => 'Full Name',
        'rules' => 'trim|required|max_length[120]|is_unique_authority[AS_authority.full_name]'
    ),
    'short_name' => array(
        'field' => 'short_name',
        'label' => 'Short Name',
        'rules' => 'trim|required|max_length[50]|authority_short_name_validation'
    ),
    'authority_type' => array(
        'field' => 'authority_type',
        'label' => 'Authority Type',
        'rules' => 'trim|authority_type_check'
    ),
    'email' => array(
        'field' => 'email',
        'label' => 'Email',
        'rules' => 'trim|max_length[255]|valid_email'
    ),
    'local_authority_url' => array(
        'field' => 'local_authority_url',
        'label' => 'Local Authority Url',
        'rules' => 'trim|max_length[255]|url_validation'
    ),
    'website' => array(
        'field' => 'website',
        'label' => 'Website',
        'rules' => 'trim|max_length[255]|url_validation'
    ),
    'always_disclaimer' => array(
        'field' => 'always_disclaimer',
        'label' => 'Always Disclaimer',
        'rules' => 'trim|max_length[3]'
    ),
    'introduction' => array(
        'field' => 'introduction',
        'label' => 'Introduction',
        'rules' => 'trim|max_length[10000]'
    ),
    'report_results_message' => array(
        'field' => 'report_results_message',
        'label' => 'Report Results Message',
        'rules' => 'trim|max_length[10000]'
    ),
    'report_no_results_message' => array(
        'field' => 'report_no_results_message',
        'label' => 'Report No Results Message',
        'rules' => 'trim|max_length[10000]'
    ),
    'helpline_text' => array(
        'field' => 'helpline_text',
        'label' => 'Helpline',
        'rules' => 'trim|max_length[100]'
    ),
    'send_report_to_authority' => array(
        'field' => 'send_report_to_authority',
        'label' => 'Send Report to Authority',
        'rules' => 'trim|max_length[3]'
    ),
    'send_report_to_friend' => array(
        'field' => 'send_report_to_friend',
        'label' => 'Send Report to Friend',
        'rules' => 'trim|max_length[3]'
    ),
    'disclaimer_text' => array(
        'field' => 'disclaimer_text',
        'label' => 'Disclaimer Text',
        'rules' => 'trim|max_length[10000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
    'local_authority' => array(
        'field' => 'local_authority',
        'label' => 'Local Authority',
        'rules' => 'trim|max_length[3]'
    ),
    'retailer_location' => array(
        'field' => 'retailer_location',
        'label' => 'Retailer Location',
        'rules' => 'trim|max_length[50]'
    ),
    'include_childrens_group' => array(
        'field' => 'include_childrens_group',
        'label' => 'Include Childrens Group',
        'rules' => 'trim|max_length[3]'
    ),
    'feedback_form_url' => array(
        'field' => 'feedback_form_url',
        'label' => 'Feedback Form URL',
        'rules' => 'trim|max_length[255]'
    ),
    'feedback_form_url_cy' => array(
        'field' => 'feedback_form_url_cy',
        'label' => 'Feedback Form URL (Welsh)',
        'rules' => 'trim|max_length[255]'
    ),
    'show_related_products' => array(
        'field' => 'show_related_products',
        'label' => 'Show Related Products',
        'rules' => 'trim|max_length[3]'
    ),
    
);

$config['group_details'] = array(
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Group Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['section_details'] = array(
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Section Id',
        'rules' => 'trim|required|numeric'
    )
);


$config['edit_question'] = array(
    'questionid' => array(
        'field' => 'questionid',
        'label' => 'Question Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'description' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
    'explanation' => array(
        'field' => 'explanation',
        'label' => 'Explanation',
        'rules' => 'trim|max_length[10000]'
    ),
    'internalnotes' => array(
        'field' => 'internalnotes',
        'label' => 'Internal Notes',
        'rules' => 'trim|max_length[10000]'
    ),
    'status' => array(
        'field' => 'status',
        'label' => 'Status',
        'rules' => 'trim|max_length[50]|question_status_validation'
    ),
    'order' => array(
        'field' => 'order',
        'label' => 'Order',
        'rules' => 'trim|numeric|less_than[20]'
    ),
    'samplequestion' => array(
        'field' => 'email',
        'label' => 'Email',
        'rules' => 'trim|max_length[255]|max_length[3]'
    ),
);

$config['new_question'] = array(
    'description' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
    'explanation' => array(
        'field' => 'explanation',
        'label' => 'Explanation',
        'rules' => 'trim|max_length[10000]'
    ),
    'internalnotes' => array(
        'field' => 'internalnotes',
        'label' => 'Internal Notes',
        'rules' => 'trim|max_length[10000]'
    ),
    'status' => array(
        'field' => 'status',
        'label' => 'Status',
        'rules' => 'trim|max_length[50]|question_status_validation'
    ),
    'order' => array(
        'field' => 'order',
        'label' => 'Order',
        'rules' => 'trim|numeric|less_than[20]'
    ),
    'samplequestion' => array(
        'field' => 'email',
        'label' => 'Email',
        'rules' => 'trim|max_length[255]|max_length[3]'
    ),
);

$config['new_question_translation'] = array(
    'questionid' => array(
        'field' => 'questionid',
        'label' => 'Question Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'sadescription' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'explanation' => array(
        'field' => 'explanation',
        'label' => 'Explanation',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_question_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Question Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'questionid' => array(
        'field' => 'questionid',
        'label' => 'Question Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'sadescription' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'explanation' => array(
        'field' => 'explanation',
        'label' => 'Explanation',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['question_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Question Translation Id',
        'rules' => 'trim|required|numeric'
    )
);


$config['new_idea_translation'] = array(
    'ideaid' => array(
        'field' => 'ideaid',
        'label' => 'Idea Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|max_length[10000]'
    ),
    'sadescription' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_idea_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Idea Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'ideaid' => array(
        'field' => 'ideaid',
        'label' => 'Idea Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|max_length[10000]'
    ),
    'sadescription' => array(
        'field' => 'sadescription',
        'label' => 'Description',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['idea_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Idea Translation Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['new_disclaimer_translation'] = array(
    'disclaimerid' => array(
        'field' => 'disclaimerid',
        'label' => 'Disclaimer Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|required|max_length[100]'
    ),
    'disclaimer' => array(
        'field' => 'disclaimer',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_disclaimer_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Disclaimer Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'disclaimerid' => array(
        'field' => 'disclaimerid',
        'label' => 'Disclaimer Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|required|max_length[100]'
    ),
    'disclaimer' => array(
        'field' => 'disclaimer',
        'label' => 'Disclaimer',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['disclaimer_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Disclaimer Translation Id',
        'rules' => 'trim|required|numeric'
    )
);


$config['new_answer_translation'] = array(
    'answerid' => array(
        'field' => 'answerid',
        'label' => 'Answer Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[1000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_answer_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Answer Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'answerid' => array(
        'field' => 'answerid',
        'label' => 'Answer Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['answer_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Answer Translation Id',
        'rules' => 'trim|required|numeric'
    )
);


$config['client_page_setting_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Client Page Setting Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['edit_client_page_setting'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Client Page Setting Id',
        'rules' => 'trim|required|numeric'
    ),
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'page' => array(
        'field' => 'page',
        'label' => 'Page',
        'rules' => 'trim|max_length[50]'
    ),
    'block_type' => array(
        'field' => 'block_type',
        'label' => 'Block Type',
        'rules' => 'trim|max_length[50]'
    ),
    'block_setting_name' => array(
        'field' => 'block_setting_name',
        'label' => 'Block Setting Name',
        'rules' => 'trim|max_length[100]'
    ),
    'block_setting_value' => array(
        'field' => 'block_setting_value',
        'label' => 'Block Setting Value',
        'rules' => 'trim|required|max_length[1000]'
    ),
);

$config['new_client_page_setting'] = array(
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'page' => array(
        'field' => 'page',
        'label' => 'Page',
        'rules' => 'trim|max_length[50]'
    ),
    'block_type' => array(
        'field' => 'block_type',
        'label' => 'Block Type',
        'rules' => 'trim|max_length[50]'
    ),
    'block_setting_name' => array(
        'field' => 'block_setting_name',
        'label' => 'Block Setting Name',
        'rules' => 'trim|max_length[100]'
    ),
    'block_setting_value' => array(
        'field' => 'block_setting_value',
        'label' => 'Block Setting Value',
        'rules' => 'trim|required|max_length[1000]'
    ),
);

$config['edit_sectionidea'] = array(
    'order' => array(
        'field' => 'order',
        'label' => 'Order',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'pkey' => array(
        'field' => 'pkey',
        'label' => 'Email',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    )
);

$config['new_group_translation'] = array(
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Group Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'name' => array(
        'field' => 'name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[100]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_group_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Group Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Group Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'name' => array(
        'field' => 'name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[100]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['group_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Group Translation Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['new_section_translation'] = array(
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Section Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'name' => array(
        'field' => 'name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[100]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_section_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Section Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'sectionid' => array(
        'field' => 'sectionid',
        'label' => 'Section Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'name' => array(
        'field' => 'name',
        'label' => 'Name',
        'rules' => 'trim|required|max_length[100]'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Description',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['section_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Section Translation Id',
        'rules' => 'trim|required|numeric'
    )
);





$config['save_idea'] = array(
    'ideaid' => array(
        'field' => 'ideaid',
        'label' => 'Idea Id',
        'rules' => 'trim|numeric'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Idea Title',
        'rules' => 'trim|required|title_validation|max_length[100]'
    ),
    'sadescription' => array(
        'field' => 'sadescription',
        'label' => 'Idea Description',
        'rules' => 'trim|required|max_length[8000]'
    ),
    'picture' => array(
        'field' => 'picture',
        'label' => 'Idea Picture',
        'rules' => 'trim|max_length[50]'
    )
);


$config['save_disclaimer'] = array(
    'discliamerid' => array(
        'field' => 'discliamerid',
        'label' => 'Disclaimer Id',
        'rules' => 'trim|numeric'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Disclaimer Title',
        'rules' => 'trim|required|title_validation|max_length[100]'
    ),
    'disclaimer' => array(
        'field' => 'disclaimer',
        'label' => 'Disclaimer Description',
        'rules' => 'trim|required|max_length[3000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Disclaimer filename',
        'rules' => 'trim|max_length[50]'
    )
);

$config['save_topic'] = array(
    'topic_id' => array(
        'field' => 'topic_id',
        'label' => 'Topic Id',
        'rules' => 'trim|numeric'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Topic Title',
        'rules' => 'trim|required|topic_title_validation|max_length[100]'
    ),
    'picture' => array(
        'field' => 'picture',
        'label' => 'Topic Picture',
        'rules' => 'trim|max_length[50]'
    )
);

$config['answer_details'] = array(
    'answerid' => array(
        'field' => 'answerid',
        'label' => 'Answer Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['save_answer'] = array(
    'ideaid' => array(
        'field' => 'answerid',
        'label' => 'Answer Id',
        'rules' => 'trim|required|numeric'
    ),
    'description' => array(
        'field' => 'description',
        'label' => 'Answer Description',
        'rules' => 'trim|required|max_length[1000]'
    ),
    'index' => array(
        'field' => 'index',
        'label' => 'Answer Index',
        'rules' => 'trim|required|numeric'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
);

$config['question_details'] = array(
    'questionid' => array(
        'field' => 'questionid',
        'label' => 'Question Id',
        'rules' => 'trim|required|numeric'
    )
);

//$config['save_question'] = array(
//    'questionid' => array(
//        'field' => 'questionid',
//        'label' => 'Question Id',
//        'rules' => 'trim|required|numeric'
//    ),
//    'description' => array(
//        'field' => 'description',
//        'label' => 'Question Description',
//        'rules' => 'trim|required|max_length[1000]'
//    ),
//    'filename' => array(
//        'field' => 'filename',
//        'label' => 'Filename',
//        'rules' => 'trim|max_length[255]'
//    ),
//);

$config['account_details'] = array(
    'accno' => array(
        'field' => 'accno',
        'label' => 'Account number',
        'rules' => 'trim|required|numeric'
    )
);

$config['save_account'] = array(
    'accno' => array(
        'field' => 'accno',
        'label' => 'Account number',
        'rules' => 'trim|required|numeric'
    ),
    'username' => array(
        'field' => 'username',
        'label' => 'Username',
//        'rules' => 'trim|required|max_length[256]|username_validation|is_unique[sara_account.username]'
        'rules' => 'trim|required|max_length[256]|username_validation'
    ),
    'password' => array(
        'field' => 'password',
        'label' => 'Password',
        'rules' => 'trim|required|max_length[20]'
    ),
    'rpassword' => array(
        'field' => 'rpassword',
        'label' => 'Password Confirmation',
        'rules' => 'trim|required|max_length[20]|matches[password]'
    ),
    'read_permission' => array(
        'field' => 'read_permission',
        'label' => 'Read Permission',
        'rules' => 'trim|max_length[2]'
    ),
    'write_permission' => array(
        'field' => 'write_permission',
        'label' => 'Write Permission',
        'rules' => 'trim|max_length[2]'
    ),
    'edit_permission' => array(
        'field' => 'edit_permission',
        'label' => 'Edit Permission',
        'rules' => 'trim|max_length[2]'
    ),
    'delete_permission' => array(
        'field' => 'delete_permission',
        'label' => 'Delete Permission',
        'rules' => 'trim|max_length[2]'
    ),
    'active' => array(
        'field' => 'active',
        'label' => 'Active',
        'rules' => 'trim|max_length[2]'
    ),
    'created' => array(
        'field' => 'created',
        'label' => 'Created',
        'rules' => 'trim|max_length[25]'
    ),
    'company_name' => array(
        'field' => 'company_name',
        'label' => 'Company',
        'rules' => 'trim|max_length[120]'
    )
);

/*
$config['forgot_password'] = array(
    'username' => array(
        'field' => 'username',
        'label' => 'Username',
        'rules' => 'trim|required|max_length[256]|username_validation'
    )
);

$config['login'] = array(
    'username' => array(
        'field' => 'username',
        'label' => 'Username',
        'rules' => 'trim|required|max_length[256]|username_validation'
    ),
    'password' => array(
        'field' => 'password',
        'label' => 'Password',
        'rules' => 'trim|max_length[256]'
    )
);

$config['change_password'] = array(
    'cpassword' => array(
        'field' => 'cpassword',
        'label' => 'Current Password',
        'rules' => 'trim|required|current_user_password_validation'
    ),
    'npassword' => array(
        'field' => 'npassword',
        'label' => 'New Password',
        'rules' => 'trim|required|min_length[8]|max_length[20]|password_validation'
    ),
    'rpassword' => array(
        'field' => 'rpassword',
        'label' => 'Password Confirmation',
        'rules' => 'trim|required|min_length[8]|max_length[20]|matches[npassword]'
    )
);

$config['reset_password'] = array(
    'username' => array(
        'field' => 'username',
        'label' => 'Username',
        'rules' => 'trim|required|max_length[256]|username_validation'
    ),
    'password' => array(
        'field' => 'password',
        'label' => 'Password',
        'rules' => 'trim|required|min_length[8]|max_length[20]|password_validation'
    ),
    'passconf' => array(
        'field' => 'passconf',
        'label' => 'Password Confirmation',
        'rules' => 'trim|required|min_length[8]|max_length[20]|matches[password]'
    )
);
*/


$config['new_textreplacetranslation_translation'] = array(
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'look_for' => array(
        'field' => 'look_for',
        'label' => 'Look for',
        'rules' => 'trim|max_length[500]'
    ),
    'action' => array(
        'field' => 'action',
        'label' => 'Action',
        'rules' => 'trim|max_length[50]'
    ),
    'replace_with' => array(
        'field' => 'replace_with',
        'label' => 'Replace with',
        'rules' => 'trim|max_length[3000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);


$config['edit_textreplacetranslation_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Text Replace Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'look_for' => array(
        'field' => 'look_for',
        'label' => 'Look for',
        'rules' => 'trim|max_length[500]'
    ),
    'action' => array(
        'field' => 'action',
        'label' => 'Action',
        'rules' => 'trim|max_length[50]'
    ),
    'replace_with' => array(
        'field' => 'replace_with',
        'label' => 'Replace with',
        'rules' => 'trim|max_length[3000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['authority_text_replace_list_all'] = array(
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'start' => array(
        'field' => 'start',
        'label' => 'Start',
        'rules' => 'trim|required|is_natural|less_than[10000]'
    ),
    'limit' => array(
        'field' => 'limit',
        'label' => 'Limit',
        'rules' => 'trim|required|is_natural|less_than[1001]'
    ),
    'sort' => array(
        'field' => 'sort',
        'label' => 'Sort',
        'rules' => 'trim|required|authoritytextreplace_sort_check'
    ),
    'dir' => array(
        'field' => 'dir',
        'label' => 'Sort Direction',
        'rules' => 'trim|required|dir_check'
    ),
);

$config['authority_text_replace_translation_list_all'] = array(
    'authority_id' => array(
        'field' => 'authority_id',
        'label' => 'Authority Id',
        'rules' => 'trim|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'start' => array(
        'field' => 'start',
        'label' => 'Start',
        'rules' => 'trim|required|is_natural|less_than[10000]'
    ),
    'limit' => array(
        'field' => 'limit',
        'label' => 'Limit',
        'rules' => 'trim|required|is_natural|less_than[1001]'
    ),
    'sort' => array(
        'field' => 'sort',
        'label' => 'Sort',
        'rules' => 'trim|required|authoritytextreplace_sort_check'
    ),
    'dir' => array(
        'field' => 'dir',
        'label' => 'Sort Direction',
        'rules' => 'trim|required|dir_check'
    ),
);


$config['page_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Page Id',
        'rules' => 'trim|required|numeric'
    )
);

$config['save_page'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Page Id',
        'rules' => 'trim|required|numeric'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|required|max_length[200]'
    ),
    'body_text' => array(
        'field' => 'body_text',
        'label' => 'Body Text',
        'rules' => 'trim|required|max_length[10000]'
    ),
    'filename' => array(
        'field' => 'filename',
        'label' => 'Filename',
        'rules' => 'trim|max_length[255]'
    ),
);



$config['new_page_translation'] = array(
    'pageid' => array(
        'field' => 'pageid',
        'label' => 'Page Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|required|max_length[200]'
    ),
    'body_text' => array(
        'field' => 'body_text',
        'label' => 'Body Text',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['edit_page_translation'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Page Translation Id',
        'rules' => 'trim|required|numeric'
    ),
    'pageid' => array(
        'field' => 'pageid',
        'label' => 'Page Id',
        'rules' => 'trim|required|numeric|is_natural_no_zero|less_than[100000]'
    ),
    'title' => array(
        'field' => 'title',
        'label' => 'Title',
        'rules' => 'trim|required|max_length[200]'
    ),
    'body_text' => array(
        'field' => 'body_text',
        'label' => 'Body Text',
        'rules' => 'trim|max_length[10000]'
    ),
    'code' => array(
        'field' => 'code',
        'label' => 'Language Code',
        'rules' => 'trim|required|max_length[10]|translation_code_validation'
    ),
);

$config['page_translation_details'] = array(
    'id' => array(
        'field' => 'id',
        'label' => 'Page Translation Id',
        'rules' => 'trim|required|numeric'
    )
);

/* End of file product_details_form_rules.php */
/* Location: ./application/config/product_details_form_rules.php */
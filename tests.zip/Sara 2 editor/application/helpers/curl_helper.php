<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter URL Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/helpers/url_helper.html
 */

// ------------------------------------------------------------------------

/**
 * Site URL
 *
 * Checks for valid (not dead) links programatically using PHP cURL
 *
 * @access	public
 * @param	string
 * @param	string
 * @return	string
 */
if ( ! function_exists('curl_url_http_code'))
{
	function curl_url_http_code($url, $timeout = 30) {
        
        $CI =& get_instance();
        $CI->curl->create($url);
        $opts = array(CURLOPT_RETURNTRANSFER => true, // do not output to browser
                                      CURLOPT_URL => $url,            // set URL
                                      CURLOPT_NOBODY => true, 		  // do a HEAD request only
                                      CURLOPT_TIMEOUT => $timeout);   // set timeout
        
        $CI->curl->options($opts);//exit;
        $CI->curl->execute();
       // $CI->curl->debug();
        
        $curl_info = $CI->curl->info;
        return intval($curl_info['http_code']);
        
    }
}

/* End of file url_helper.php */
/* Location: ./APPLICATION/helpers/url_helper.php */
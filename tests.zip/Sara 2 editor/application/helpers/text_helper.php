<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * CodeIgniter Text Helpers
 *
 * @package		CodeIgniter
 * @subpackage	Helpers
 * @category	Helpers
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/helpers/text_helper.html
 */

// ------------------------------------------------------------------------

/**
 * stripped_of_invalid_utf8_chars_string
 *
 * Cleans the string of any invalid utf-8 characters
 *
 * @access	public
 * @param	string
 * @return	string
 */
if ( ! function_exists('stripped_of_invalid_utf8_chars_string'))
{
	function stripped_of_invalid_utf8_chars_string( $orig_string ) {
	
		$stripped_of_invalid_utf8_chars_string = iconv('UTF-8', 'UTF-8//IGNORE', $orig_string);
		if ($stripped_of_invalid_utf8_chars_string !== $orig_string) {
			// one or more chars were invalid, and so they were stripped out.
			// if you need to know where in the string the first stripped character was, 
			// then see http://stackoverflow.com/questions/7475437/find-first-character-that-is-different-between-two-strings
		}
		return $stripped_of_invalid_utf8_chars_string;
	}
}
// ------------------------------------------------------------------------

/* End of file text_helper.php */
/* Location: ./system/helpers/text_helper.php */
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('save_image'))
{

    function save_image($type, $filename) {

        $CI = get_instance();
        
        $result = array();
        if (is_uploaded_file($_FILES[$type.'_picture']['tmp_name'])) {

            if ($_FILES[$type.'_picture']['error'] === 0) {
                $CI->load->library('upload');
                $CI->config->load('file_upload', TRUE);
                $settings = $CI->config->item($type.'_picture', 'file_upload');
                $settings['file_name'] = $filename;
                if (!file_exists($settings['upload_path'])) { // create directory if it does not exist
                    mkdir($settings['upload_path'], 0777, true);
                }
                $CI->upload->initialize($settings);
                if (!$CI->upload->do_upload($type.'_picture')) {
                    $result = array('error' => 1, 'message' => strip_tags($CI->upload->display_errors()));
                } elseif (file_exists( $settings['upload_path'] . '/' . $filename)) {
                    $result = array('success' => 1, 'filename' => $filename);
                }
            } else {
                $result = array('error' => 1, 'message' => $_FILES[$type.'_picture']['error']);
            }
        }

        return $result;
    }

}

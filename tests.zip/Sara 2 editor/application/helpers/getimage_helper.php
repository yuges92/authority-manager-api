<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//if ( ! function_exists('ci_save_image_upload'))
//{
//	function ci_save_image_upload($type, $type_id, $action, $sourceUrl, $filename) {
//        
//            $CI = get_instance();
//            
//            $CI->load->model('imageupload_model', '', TRUE);
//            $irecord = array(
//                'url' => $sourceUrl . '/' . $filename,
//                'type' => $type,
//                'type_id' => $type_id,
//                'action' => $action,
//                'uploaded_by' => $_SESSION["seuname"],
//                'status' => 'IN PROGRESS'
//            );
//            
////            echo '<pre>';
////            print_r($irecord);
////            echo '</pre>';
////            exit;
//            $CI->imageupload_model->insert($irecord);
//   
//    }
//}

/* End of file getimage_helper.php */
/* Location: ./APPLICATION/helpers/getimage_helper.php */
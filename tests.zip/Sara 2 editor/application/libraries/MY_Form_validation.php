<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class MY_Form_validation extends CI_Form_validation {

    function __construct($config = array()) {
        parent::__construct($config);
    }

    // get CI instance object 
    public function __get($object) {
        $this->CI = &get_instance();
        return $this->CI->$object;
    }

    /**
     * Add error
     *
     * Adds a custom error to the form validation array
     *
     * @return  array
     */
    function add_to_error_array($field = '', $message = '') {
        if (!isset($this->_error_array[$field])) {
            $this->_error_array[$field] = $message;
        }

        return;
    }

    /**
     * Error Array
     *
     * Returns the error messages as an array
     *
     * @return  array
     */
    function error_array() {
        if (count($this->_error_array) === 0)
            return FALSE;
        else
            return $this->_error_array;
    }

    function set_post_validation_error($field, $message) {
        if (!isset($this->_field_data[$field])) {
            $this->_field_data[$field]['postdata'] = '';
        }

        $this->_field_data[$field]['error'] = $message;

        if (!isset($this->_error_array[$field])) {
            $this->_error_array[$field] = $message;
        }
    }

    function product_id_validation($str) {

        $this->CI->form_validation->set_message('product_id_validation', 'The %s field must be a valid product id.');

        return (preg_match('/^\d{7}$/', $str) > 0 && intval($str) > 0);
    }

    function name_validation($str) {

        $this->CI->form_validation->set_message('name_validation', 'The %s field must contain the following chars: [a-zA-Z0-9. &]');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. &";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function manufacturer_name_validation($str) {

        $this->CI->form_validation->set_message('manufacturer_name_validation', 'The %s field must be a valid manufacturer name.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. &,";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function picname_validation($str) {

        $this->CI->form_validation->set_message('picname_validation', 'The %s field must be a valid image name.');

        $length = strlen($str);
        if ($length > 36) {
            return FALSE;
        }

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.";
        for ($i = 0; $i < strlen(trim($length)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function supplier_name_validation($str) {

        $this->CI->form_validation->set_message('supplier_name_validation', 'The %s field must be a valid supplier name.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. &";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function product_name_validation($str) {

        $this->CI->form_validation->set_message('product_name_validation', 'The %s field must be a valid product name.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789. '-_,&";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function product_price_validation($str) {

        $this->CI->form_validation->set_message('product_price_validation', 'The %s field must be a valid product price.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function price_quantity_validation($str) {

        $this->CI->form_validation->set_message('price_quantity_validation', 'The %s field must be a valid product price quantity.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ;";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function price_other_info($str) {

        $this->CI->form_validation->set_message('price_quantity_validation', 'The %s field must be a valid product price other info.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ;";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function picture_validation($str) {

        $this->CI->form_validation->set_message('picture_validation', 'The %s field must be a valid picture field.');

        $valid_chars = "0123456789LSM-.,jpg";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function picture_size_validation($str) {

        $this->CI->form_validation->set_message('picture_size_validation', 'The %s field must be a valid picture size field.');

        if ($str && !in_array($str, array('S', 'M', 'L'))) {
            return FALSE;
        }
        return TRUE;
    }

    function product_ean_validation($str) {

        $this->CI->form_validation->set_message('product_ean_validation', 'The %s field must be a valid product code.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\ .'-_+:;#/()";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function supplier_id_validation($str) {

        $this->CI->form_validation->set_message('supplier_id_validation', 'The %s field must be a valid supplier id.');

        $is_valid = (preg_match('/^\d{7}$/', $str) > 0 && intval($str) > 0);
        if (!$is_valid) {
            return FALSE;
        }

        return TRUE;
    }

    public function url_validation($str) {

        $this->CI->form_validation->set_message('url_validation', 'The %s field must be a valid url.');

        $pattern = "/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i";
        if ($str && !preg_match($pattern, $str)) {
            echo $str;
            exit;
            return FALSE;
        }

        return TRUE;
    }

    public function video_url_validation($str) {

        $this->CI->form_validation->set_message('video_url_validation', 'The %s field must be a valid video url.');

        $pattern = "/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i";
        if ($str && !preg_match($pattern, $str)) {
            return FALSE;
        }

        return TRUE;
    }

    // validates http://youtu.be/xxxxxxxxxxx
    public function youtube_video_url_validation($str) {

        $this->CI->form_validation->set_message('youtube_video_url_validation', 'The %s field must be a valid YouTube video url.');

        $pattern = "#^http://youtu\.be/[\w-]{11}$#";
        if ($str && !preg_match($pattern, $str)) {
            return FALSE;
        }

        return TRUE;
    }

    /**
     * Is Unique
     *
     * @access public
     * @param string
     * @param field
     * @return bool
     */
    public function is_unique_authority($str, $field) {

        $this->CI->form_validation->set_message('is_unique_authority', 'Already exists in the database.');

        list($table, $field) = explode('.', $field);

        if (isset($this->CI->db)) {
            //$query = $this->CI->db->limit(1)->get_where($table, array($field => $str));
            $query = $this->CI->db->where($field, $str)->get("$table"); // Removed limit
            return $query->num_rows() === 0;
        }

        return FALSE;
    }

    function authority_short_name_validation($str) {

        $this->CI->form_validation->set_message('authority_short_name_validation', 'The %s field has invalid characters. Only alpha letters, digits and underscores are allowed.');

        $valid_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    /**
     * Is Unique
     *
     * @access public
     * @param string
     * @param field
     * @return bool
     */
    public function is_unique_authoritycity($str, $field) {

        $this->CI->form_validation->set_message('is_unique_authoritycity', 'The %s field already exists in the database.');

        list($table, $field) = explode('.', $field);

        if (isset($this->CI->db)) {
            //$query = $this->CI->db->limit(1)->get_where($table, array($field => $str));
            $query = $this->CI->db->where($field, $str)->get(DB_NAME . "[dbo].[$table]"); // Removed limit
            return $query->num_rows() === 0;
        }

        return FALSE;
    }

    /**
     * Is Unique
     *
     * @access public
     * @param string
     * @param field
     * @return bool
     */
    public function is_unique_ideacity($str, $field) {

        $this->CI->form_validation->set_message('is_unique_ideacity', 'The %s field already exists in the database.');

        list($table, $field) = explode('.', $field);

        if (isset($this->CI->db)) {
            //$query = $this->CI->db->limit(1)->get_where($table, array($field => $str));
            $query = $this->CI->db->where($field, $str)->get(DB_NAME . "[dbo].[$table]"); // Removed limit
            return $query->num_rows() === 0;
        }

        return FALSE;
    }

    function current_user_password_validation($password) {

        //This function checks the current password in admin reset
        $this->CI->form_validation->set_message('current_user_password_validation', 'The %s field must match your account password');
        $session_data = $this->CI->session->all_userdata();
        $user = $this->CI->user_model->findByUsername($session_data['username']);
        if ($user > 0) {
            return $this->CI->securehash->validate_hash($password, $user['password'], $user['salt']);
        }

        return FALSE;
    }

    public function question_sort_check($str) {
        if (!in_array($str, array('questionid', 'sadescription', 'section_name'))) {
            $this->form_validation->set_message('question_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function questiontranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'sadescription'))) {
            $this->form_validation->set_message('questiontranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function ideatranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'sadescription'))) {
            $this->form_validation->set_message('ideatranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function disclaimertranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'title'))) {
            $this->form_validation->set_message('disclaimertranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function answertranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'description'))) {
            $this->form_validation->set_message('answertranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function grouptranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'name', 'description'))) {
            $this->form_validation->set_message('grouptranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function clientpagesetting_sort_check($str) {
        if (!in_array($str, array('id', 'page', 'block_type', 'block_setting_name', 'block_setting_value'))) {
            $this->form_validation->set_message('clientpagesetting_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function idea_sort_validation($str) {
        if (!in_array($str, array('ideaid', 'title'))) {
            $this->form_validation->set_message('idea_sort_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    
    public function question_status_validation($str) {
        if (!in_array($str, array('C', 'X', 'S'))) {
            $this->form_validation->set_message('question_status_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function pagetranslation_sort_check($str) {
        if (!in_array($str, array('id', 'language', 'code', 'title'))) {
            $this->form_validation->set_message('pagetranslation_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function translation_code_validation($str) {
        
        //load in the values from the config file. 
        $valid_language_codes   = $this->CI->config->item('valid_language_codes');
        
        if (!array_key_exists($str, $valid_language_codes)) {
            $this->form_validation->set_message('translation_code_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    

    public function sectionidea_sort_validation($str) {
        if (!in_array($str, array('ideaid', 'title', 'displaytype', 'order'))) {
            $this->form_validation->set_message('sectionidea_sort_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function ideareference_sort_validation($str) {
        if (!in_array($str, array('ideaid', 'title', 'author'))) {
            $this->form_validation->set_message('ideareference_sort_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function ideacity_sort_validation($str) {
        if (!in_array($str, array('id', 'county'))) {
            $this->form_validation->set_message('ideacity_sort_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
	public function authority_type_check($str) {
        $authority_type_allowed = array('BASIC', 'COMPLEX', 'COMMERCIAL', 'BASIC1');
        if (!in_array($str, $authority_type_allowed)) {
            $this->form_validation->set_message('authority_type_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function authority_sort_check($str) {
        if (!in_array($str, array('authority_id', 'authority_type', 'full_name', 'supplier_id'))) {
            $this->form_validation->set_message('authority_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
	
    public function authoritycity_sort_validation($str) {
        if (!in_array($str, array('id', 'county'))) {
            $this->form_validation->set_message('authoritycity_sort_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    public function dir_validation($str) {
        if (!in_array($str, array('DESC', 'ASC'))) {
            $this->form_validation->set_message('dir_validation', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

//    public function sort_dir_validation($str) {
//        if (!in_array($str, array('DESC', 'ASC'))) {
//            $this->form_validation->set_message('sort_dir_validation', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }

    /**
     * Valid Username
     *
     * @access	public
     * @param	string
     * @return	bool
     */
    public function username_validation($str) {
        $this->CI->form_validation->set_message('username_validation', 'The %s field must be a valid Email Address');
        return (!preg_match("/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix", $str)) ? FALSE : TRUE;
    }

    /**
     * Valid Password
     *
     * @access	public
     * @param	string
     * @return	bool
     */
    public function password_validation($str) {

        /*
          ^                  // the start of the string
          (?=.*[a-z])        // use positive look ahead to see if at least one lower case letter exists
          (?=.*[A-Z])        // use positive look ahead to see if at least one upper case letter exists
          (?=.*\d)           // use positive look ahead to see if at least one digit exists
          (?=.*[_\W])        // use positive look ahead to see if at least one underscore or non-word character exists
          .+                 // gobble up the entire string
          $                  // the end of the string
         */
        if (!preg_match("/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/", $str)) {
            //$this->CI->form_validation->set_message('password_validation', 'The %s field must contain at least one uppercase, one lowercase, one digit and one underscore');
            return FALSE;
        }

        return TRUE;
    }

    function title_validation($str) {

        $this->CI->form_validation->set_message('title_validation', 'The %s field has invalid characters.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,-()'? ";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function section_title_validation($str) {

        $this->CI->form_validation->set_message('section_title_validation', 'The %s field has invalid characters.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function topic_title_validation($str) {

        $this->CI->form_validation->set_message('topic_title_validation', 'The %s field has invalid characters.');

        $valid_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
        for ($i = 0; $i < strlen(trim($str)); $i++) {
            $char = substr(trim($str), $i, 1);
            $pos = strrpos($valid_chars, $char);
            if ($pos === false) { // note: three equal signs
                return FALSE;
            }
        }
        return TRUE;
    }

    function authoritytextreplace_sort_check($str) {
        if (!in_array($str, array('id', 'authority_id', 'look_for', 'action', 'replace_with'))) {
            $this->form_validation->set_message('authoritytextreplace_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function authoritycity_sort_check($str) {
        if (!in_array($str, array('id', 'city'))) {
            $this->form_validation->set_message('authoritycity_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    function dir_check($str) {
        if (!in_array($str, array('DESC', 'ASC'))) {
            $this->form_validation->set_message('active_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    
    /**
     * Valid recaptcha
     *
     * @access	public
     * @param	string
     * @return	bool
     */
    public function recaptcha_response_field_validation($str) {
        $this->CI->form_validation->set_message('recaptcha_response_field_validation', 'The %s field is incorrect.');
        //Call to recaptcha to get the data validation set within the class. 
        $this->CI->recaptcha->recaptcha_check_answer();
        return (!$this->CI->recaptcha->getIsValid()) ? FALSE : TRUE;
    }

    // Validate a “does match” type 
    function is($str, $field) {
        $this->CI->form_validation->set_message('is', "%s contains an invalid response");
        return $str === $field;
    }

}
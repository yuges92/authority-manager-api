<?php

Class Ideatranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($itId) {

        $itId = intval($itId);
        
        $this->db->select('it.*');
        $this->db->from('AS_ideatranslation it');
        $this->db->where('it.id', $itId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllByIdea($iId) {

        $this->db->select('*');
        $this->db->from('AS_ideatranslation it');
        $this->db->where('it.ideaid', intval($iId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdea($iId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'code', 'language', 'title', 'sadescription'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_ideatranslation it');
        $this->db->where('it.ideaid', intval($iId));  //this is condition    
        $this->db->order_by("it.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneByIdeaIdAndCode($itId, $code) {

        $itId = intval($itId);
        
        $this->db->select('it.*');
        $this->db->from('AS_ideatranslation it');
        $this->db->where('it.ideaid', $itId);
        $this->db->where('it.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }

    function update($itId, $idea_translation) {
        
        $this->db->where('id', intval($itId));
        $query_result = $this->db->update('AS_ideatranslation', $idea_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($idea_translation) {

        $query_result = $this->db->insert('AS_ideatranslation', $idea_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_ideatranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}

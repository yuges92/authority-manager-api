<?php

Class Global_setting_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('[id], [name], [value], [site]');
        $this->db->from('global_setting');
        $this->db->where('id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAll($filter_by, $search_key) {

        $sql = "SELECT Count(id) AS total
                FROM [" . DB_NAME . "].[dbo].[global_setting] gs WHERE 1=1 ";

        if (strlen($search_key) > 0) {

            $search_key = $this->db->escape_like_str($search_key);

            if ($filter_by == 11) {
                $sql .= " AND gs.id LIKE '%$search_key%'";
            } elseif ($filter_by == 12) {
                $sql .= " AND gs.name LIKE '%$search_key%'";
            }
        }

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function searchByTitle($title) {

        $title = $this->db->escape_like_str($title);

        $sql = "SELECT t.[id], t.[name]
                FROM [" . DB_NAME . "].[dbo].[global_setting] gs
                WHERE gs.name LIKE '$title%'
                ORDER BY t.[title] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($filter_by, $search_key, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT gs.[id]
                    ,gs.[name]
                    ,gs.[value]
                    ,gs.[site]
               FROM [" . DB_NAME . "].[dbo].[global_setting] gs WHERE 1=1 ";

        if (strlen($search_key) > 0) {

            $search_key = $this->db->escape_like_str($search_key);

            if ($filter_by == 11) {
                $sql .= " AND gs.id LIKE '%$search_key%'";
            } elseif ($filter_by == 12) {
                $sql .= " AND gs.name LIKE '%$search_key%'";
            }
        }



        if (!in_array($sort, array('id', 'name'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY gs.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($id, $global_setting) {
        $this->db->where('id', $id);

        $query_result = $this->db->update('global_setting', $global_setting);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function insert($global_setting) {

        $query_result = $this->db->insert('global_setting', $global_setting);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

}

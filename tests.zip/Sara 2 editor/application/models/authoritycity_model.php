<?php

Class Authoritycity_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('ac.*');
        $this->db->from('AS_authoritycity ac');
        $this->db->where('ac.id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllByAuthorityId($authority_id) {

        $authority_id = intval($authority_id);

        $this->db->select('Count(ac.id) AS total');
        $this->db->from('AS_authoritycity ac');
        $this->db->where('ac.authority_id', $authority_id);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAuthorityId($authority_id, $start, $limit, $sort, $dir) {

        $authority_id = intval($authority_id);

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        if (!in_array($sort, array('city'))) {
            $sort = 'city';
        }
        $dir = trim($dir);
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT ac.id
                        ,ac.authority_id
                        ,ac.city
                        ,ac.county
                FROM AS_authoritycity ac WHERE ac.authority_id=$authority_id";
        $sql.=" ORDER BY ac.$sort $dir";
        $sql.= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAuthorityCities($authority_id) {

        $authority_id = intval($authority_id);

        $sql = "SELECT ac.city
                FROM AS_authoritycity ac WHERE ac.authority_id=$authority_id";
        $query = $this->db->query($sql);
        
        $cities=array();
        foreach ($query->result_array() as $record) :
            $cities[]=$record['city'];
        endforeach;
        
        return $cities;
        
    }
    
    
    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('AS_authoritycity', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }
    
    
    function insert_batch($records) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert_batch('AS_authoritycity', $records);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('AS_authoritycity', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
    function update($id, $record) {
        $this->db->where('id', $id);
        
        $query_result = $this->db->update('AS_authoritycity', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }
    

}

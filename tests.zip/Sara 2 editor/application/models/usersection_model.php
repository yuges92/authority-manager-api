<?php

Class UserSection_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('*');
        $this->db->from('global_setting');
        $this->db->where('id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllByAuthorityAndDateRange($date_from, $date_to) {

        $sql = "SELECT Count(id) AS total
                FROM [" . DB_NAME . "].[dbo].[global_setting] gs WHERE 1=1 ";

        if (strlen($search_key) > 0) {

            $search_key = $this->db->escape_like_str($search_key);

            if ($filter_by == 11) {
                $sql .= " AND gs.id LIKE '%$search_key%'";
            } elseif ($filter_by == 12) {
                $sql .= " AND gs.name LIKE '%$search_key%'";
            }
        }

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function searchAllUserCompletedByAuthority($auth, $date_from, $date_to) {

        // $name = $this->db->escape_like_str($name);

        $DB2 = $this->load->database('live', TRUE);

        $sql = "SELECT sectionid AS 'SECTION ID', name AS 'SECTION NAME', COUNT(completed) AS 'TOTAL COMPLETED'
                FROM (
                    SELECT DISTINCT
                      [DLF_livedata].[dbo].[usersection].[sectionid]
                      ,[DLF_livedata].[dbo].[usersection].[completed]
                      ,[DLF_livedata].[dbo].[usersection].[timestamp]
                      ,s.[name]
                    FROM [DLF_livedata].[dbo].[usersection]
                    INNER JOIN [DLF_livedata].[dbo].[session] ON [DLF_livedata].[dbo].[usersection].[email]=[DLF_livedata].[dbo].[session].[session_id]
                    INNER JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON [DLF_livedata].[dbo].[usersection].[sectionid]=s.[sectionid]
                    WHERE [DLF_livedata].[dbo].[usersection].[timestamp] >= '03/09/2017' AND  [DLF_livedata].[dbo].[usersection].[timestamp] < '07/09/2017'
                    AND [DLF_livedata].[dbo].[session].[authority]='northyorks'
                ) AS data
                GROUP BY name, sectionid
                ORDER BY name ";

        $query = $DB2->query($sql);
        echo '<pre>';
        print_r($query->result_array());
        echo '</pre>';
        exit;
        //echo $this->db->last_query();exit;
        //return $result;
    }

}

<?php

/* SARA Group Table */

Class Group_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($sId) {

        $sql = " SELECT group_tbl_1.*, group_tbl_2.name as pname
                FROM ( SELECT TOP 1 A.[sectionid],
                             A.[used],
                             A.[name],
                             A.[order],
                             A.[description],
                             A.[parent_id],
                             A.[filename],
                             A.[video_url],
                             ( CASE
                                 WHEN B.num_subgroups IS NULL THEN 0
                                 ELSE B.num_subgroups
                               END ) + ( CASE
                                           WHEN C.num_sections IS NULL THEN 0
                                           ELSE C.num_sections
                                         END ) AS num_children
                FROM   [" . DB_NAME . "].[dbo].[AS_group] A
                       LEFT JOIN (SELECT B.[parent_id],
                                         Count(*) AS num_subgroups
                                  FROM   [" . DB_NAME . "].[dbo].[AS_group] B
                                  WHERE  B.[parent_id] IS NOT NULL
                                  GROUP  BY B.[parent_id]) B
                              ON A.[sectionid] = B.[parent_id]
                       LEFT JOIN (SELECT C.[parent_id],
                                         Count(*) AS num_sections
                                  FROM   [" . DB_NAME . "].[dbo].[AS_section] C
                                  WHERE  C.[parent_id] IS NOT NULL
                                          OR C.[parent_id] != 0
                                  GROUP  BY C.[parent_id]) C
                              ON A.[sectionid] = C.[parent_id]
                WHERE  A.[sectionid] = ?
                ORDER  BY A.[sectionid] ASC ) AS group_tbl_1
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_group] group_tbl_2 ON group_tbl_1.[parent_id]=group_tbl_2.sectionid";

        $query = $this->db->query($sql, array(intval($sId)));
        if ($query->num_rows() == 0) {
            return FALSE;
        }

        return $query->result()[0];
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findTopGroups() {

        $sql = "SELECT A.[sectionid]
                ,A.[used]
                ,A.[name]
                ,A.[order]
                ,A.[description]
                ,A.[parent_id]
                ,A.[filename]
                ,A.[video_url]
                ,(CASE WHEN B.num_subgroups IS NULL THEN 0 ELSE B.num_subgroups END) + (CASE WHEN C.num_sections IS NULL THEN 0 ELSE C.num_sections END) AS num_children
                FROM [" . DB_NAME . "].[dbo].[AS_group] A
                LEFT JOIN
                        (SELECT B.[parent_id] , count(*) as num_subgroups
                        FROM [" . DB_NAME . "].[dbo].[AS_group] B
                        WHERE B.[parent_id] IS NOT NULL
                        GROUP BY B.[parent_id]) B
                ON A.[sectionid]=B.[parent_id]
                LEFT JOIN
                        (SELECT C.[parent_id] , count(*) as num_sections
                        FROM [" . DB_NAME . "].[dbo].[AS_section] C
                        WHERE C.[parent_id] IS NOT NULL OR C.[parent_id]!=0
                        GROUP BY C.[parent_id]) C
                ON A.[sectionid]=C.[parent_id]
                WHERE A.[parent_id] IS NULL
                ORDER BY A.[sectionid] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    public function countAllUnverified() {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    public function countAll() {

        $sql = "SELECT Count(a.authority_id) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_authority] a ";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT [authority_id]
                    ,a.[supplier_id]
                    ,a.[full_name]
                    ,a.[short_name]
                    ,a.[authority_type]
                    ,a.[email]
                    ,a.[local_authority_url]
                    ,a.[ask_question_url]
                    ,a.[website]
                    ,a.[always_disclaimer]
                    ,a.[introduction]
                    ,a.[disclaimer_text]
                    ,a.[disclaimer_text_cy]
                    ,a.[filename]
                    ,a.[local_authority]
                    ,a.[retailer_location]
               FROM [" . DB_NAME . "].[dbo].[AS_authority] a ";

        if (!in_array($sort, array('authority_id', 'authority_type', 'full_name', 'supplier_id'))) {
            $sort = 'authority_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql .= " ORDER BY a.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

//    public function countAllByNameAndType($name, $type) {
//
//        $name = $this->db->escape_like_str($name);
//        $type = $this->db->escape_like_str($type);
//
//        $sql = "SELECT Count(authority_id) AS total
//                FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.title LIKE '$name%' AND a.authority_type='$type'";
//
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByNameAndType($name, $type) {

        $name = $this->db->escape_like_str($name);
        $type = $this->db->escape_like_str($type);

        $sql = "SELECT  a.[authority_id]
                    ,a.[authority_type]
                    ,a.[title]
                    ,a.[authority]
                    ,a.[status]
                    ,a.[description]
                    ,a.[group_id]
                    ,a.[picture]
                    ,a.[video]
                    ,a.[created_by]
                    ,a.[created]
                    ,a.[verified_by]
                    ,a.[verified]
                    ,a.[product_id]
                    ,a.[user_id]
                    ,a.[modified]
                    ,a.[modified_by]
               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.title LIKE '$name%' AND a.authority_type='$type' 
               ORDER BY a.[title] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($authority_id, $authority) {
        $this->db->where('authority_id', $authority_id);

        $query_result = $this->db->update('AS_authority', $authority);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function insert($authority) {

        $query_result = $this->db->insert('AS_authority', $authority);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return $this->db->insert_id();
    }

//    public function getImagesData() {
//
//        $sql = "SELECT  a.[authority_id],a.[picture]
//               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.[picture] IS NOT NULL AND a.[picture]!=''
//               ORDER BY a.[authority_id] ASC";
//
//        $query = $this->db->query($sql);
//        return $query->result_array();
//    }

}

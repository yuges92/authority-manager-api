<?php

Class Clientpagesetting_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($cpsId) {

        $cpsId = intval($cpsId);
        
        $this->db->select('cps.*');
        $this->db->from('AS_authority_pagesetting cps');
        $this->db->where('cps.id', $cpsId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllByAuthority($aId) {

        $this->db->select('*');
        $this->db->from('AS_authority_pagesetting cps');
        $this->db->where('cps.authority_id', intval($aId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all authority page setting records in database.
     * @access public
     * @return array|false the authority page setting records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAuthority($aId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'page', 'block_type', 'block_setting_name', 'block_setting_value'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_authority_pagesetting csp');
        $this->db->where('csp.authority_id', intval($aId));  //this is condition    
        $this->db->order_by("csp.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneBySetting($cpstrecord) {

        $this->db->select('cps.*');
        $this->db->from('AS_authority_pagesetting cps');
        $this->db->where('cps.authority_id', $cpstrecord['authority_id']);
        $this->db->where('cps.page', $cpstrecord['page']);
        $this->db->where('cps.block_type', $cpstrecord['block_type']);
        $this->db->where('cps.block_setting_name', $cpstrecord['block_setting_name']);
        //$this->db->where('cps.block_setting_value', $cpstrecord['block_setting_value']);
        $this->db->limit(1);

        $query = $this->db->get();
        //print_r($this->db->last_query());exit;
        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }
    
    function update($cpsId, $cPs) {
        
        $this->db->where('id', intval($cpsId));
        $query_result = $this->db->update('AS_authority_pagesetting', $cPs);
        
     // print_r($this->db->last_query());exit;
        
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($cPs) {

        $query_result = $this->db->insert('AS_authority_pagesetting', $cPs);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($cpsId) {

        $query_result = $this->db->delete('AS_authority_pagesetting', array('id' => $cpsId));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}
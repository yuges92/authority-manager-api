<?php

Class Disclaimer_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($disclaimerid) {

        if (!$disclaimerid) {
            return false;
        }

        $this->db->select('d.*');
        $this->db->from('AS_disclaimer d');
        $this->db->where('d.disclaimerid', $disclaimerid);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

//    public function countAllUnverified() {
//
//        $sql = "SELECT Count(id) AS total
//                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";
//        
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//        
//    }
    
    
    public function countAll() {

        $sql = "SELECT COUNT(d.disclaimerid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_disclaimer] d ";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (in_array($sort, array('disclaimerid', 'title'))) {
            $sort = 'disclaimerid';
        }
        
        if (in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT d.[disclaimerid]
                      ,d.[title]
                      ,d.[disclaimer]
                      ,d.[references]
                      ,d.[filename]
                      ,d.[created]
                      ,d.[created_by]
                      ,d.[modified]
                      ,d.[modified_by]
                FROM [" . DB_NAME . "].[dbo].[AS_disclaimer] d
                ORDER BY d.[$sort] $dir OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);
        return $query->result_array();
    }

    function update($disclaimerid, $disclaimer) {
        $this->db->where('disclaimerid', $disclaimerid);
        $query_result = $this->db->update('AS_disclaimer', $disclaimer);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
         
        return true;
    }

    function insert($disclaimer) {
        
        $query_result = $this->db->insert('AS_disclaimer', $disclaimer);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
        
    }
    
//     public function getImagesData() {
//
//        $sql = "SELECT  a.[authority_id],a.[picture]
//               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.[picture] IS NOT NULL AND a.[picture]!=''
//               ORDER BY a.[authority_id] ASC";
//
//        $query = $this->db->query($sql);
//        return $query->result_array();
//    }
}

<?php

Class Authoritytextreplacetranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('atrt.*');
        $this->db->from('AS_authority_textreplacetranslation atrt');
        $this->db->where('atrt.id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function findOneByIdAndCode($datrtId) {

        $datrtId = intval($datrtId);
        
        $this->db->select('atrt.*');
        $this->db->from('AS_authority_textreplacetranslation atrt');
        $this->db->where('atrt.id', $datrtId);
       // $this->db->where('atrt.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }
    
    public function countAllByAuthorityId($authority_id) {

        $authority_id = intval($authority_id);

        $this->db->select('Count(atrt.id) AS total');
        $this->db->from('AS_authority_textreplacetranslation atrt');
        $this->db->where('atrt.authority_id', $authority_id);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAuthorityId($authority_id, $start_param, $limit_param, $sort_param, $dir_param) {

        $authority_id = intval($authority_id);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = 'id';
        if (in_array($sort_param, array('id', 'authority_id', 'look_for', 'action', 'replace_with'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT *
                FROM [" . DB_NAME . "].[dbo].[AS_authority_textreplacetranslation] atrt WHERE atrt.authority_id=$authority_id 
                ORDER BY atrt.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('AS_authority_textreplacetranslation', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('AS_authority_textreplacetranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
    function update($id, $record) {
        $this->db->where('id', $id);
        
        $query_result = $this->db->update('AS_authority_textreplacetranslation', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }
    

}

<?php

Class Page_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * returns an page record by id in database.
     * @access public
     * @return array|false the page record found in database, FALSE otherwise (i.e.none record found).
     */
    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('p.*');
        $this->db->from('AS_page p');
        $this->db->where('p.id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    /**
     * returns count of all page records in database.
     * @access public
     * @return int|false the count of all page records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAll() {

        $sql = "SELECT COUNT(p.id) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_page] p";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all page records in database.
     * @access public
     * @return array|false the page records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'title'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT p.id
                    ,p.title
                    ,p.body_text
                FROM [" . DB_NAME . "].[dbo].[AS_page] p";
        
        $sql.=" ORDER BY p.$sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($id, $page) {
        $this->db->where('id', $id);
        $query_result = $this->db->update('AS_page', $page);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
         return true;
    }

    function insert($page) {
        
        $query_result = $this->db->insert('AS_page', $page);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_page', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
}

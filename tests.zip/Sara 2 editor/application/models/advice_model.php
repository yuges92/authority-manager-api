<?php

Class Advice_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($advice_id) {

        if (!$advice_id) {
            return false;
        }

        $this->db->select('[advice_id], [advice_type], [title], [advice], [status], [description], [group_id], [picture], [video], [created_by], [created], [verified_by], [verified], [product_id], [user_id], [modified], [modified_by]');
        $this->db->from('[dlfwebapp].[dbo].[advice]');
        $this->db->where('advice_id', $advice_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllUnverified() {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    
    
    public function countAll($search_by, $search_key, $filter_type) {

        $sql = "SELECT Count(advice_id) AS total
                FROM [dlfwebapp].[dbo].[advice] a WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            
            $search_key = $this->db->escape_like_str($search_key);
            
            if($search_by==11) {
                $sql .= " AND a.advice_id LIKE '$search_key%'";
            } elseif($search_by==12) {
                $sql .= " AND a.title LIKE '$search_key%'";
            }
        }
        
        if (strlen($filter_type) > 0) {
            $filter_type = $this->db->escape_like_str($filter_type);
            $sql .= " AND a.advice_type = '$filter_type'";
        }
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($search_by, $search_key, $filter_type, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT  a.[advice_id]
                    ,a.[advice_type]
                    ,a.[title]
                    ,a.[advice]
                    ,a.[status]
                    ,a.[description]
                    ,a.[group_id]
                    ,a.[picture]
                    ,a.[video]
                    ,a.[created_by]
                    ,a.[created]
                    ,a.[verified_by]
                    ,a.[verified]
                    ,a.[product_id]
                    ,a.[user_id]
                    ,a.[modified]
                    ,a.[modified_by]
               FROM [dlfwebapp].[dbo].[advice] a WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            $search_key = $this->db->escape_like_str($search_key);
            if($search_by==11) {
                $sql .= " AND a.advice_id LIKE '$search_key%'";
            } elseif($search_by==12) {
                $sql .= " AND a.title LIKE '$search_key%'";
            }
        }
        
        if (strlen($filter_type) > 0) {
            $filter_type = $this->db->escape_like_str($filter_type);
            $sql .= " AND a.advice_type = '$filter_type'";
        }
        

        if (!in_array($sort, array('advice_id', 'title', 'advice_type'))) {
            $sort = 'advice_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY a.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

//     public function countAllByNameAndType($name, $type) {
//
//         $name = $this->db->escape_like_str($name);
//         $type = $this->db->escape_like_str($type);
//         
//        $sql = "SELECT Count(advice_id) AS total
//                FROM [dlfwebapp].[dbo].[advice] a WHERE a.title LIKE '$name%' AND a.advice_type='$type'";
//           
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByNameAndType($name, $type) {

        $name = $this->db->escape_like_str($name);
        $type = $this->db->escape_like_str($type);
        
        $sql = "SELECT  a.[advice_id]
                    ,a.[advice_type]
                    ,a.[title]
                    ,a.[advice]
                    ,a.[status]
                    ,a.[description]
                    ,a.[group_id]
                    ,a.[picture]
                    ,a.[video]
                    ,a.[created_by]
                    ,a.[created]
                    ,a.[verified_by]
                    ,a.[verified]
                    ,a.[product_id]
                    ,a.[user_id]
                    ,a.[modified]
                    ,a.[modified_by]
               FROM [dlfwebapp].[dbo].[advice] a WHERE a.title LIKE '$name%' AND a.advice_type='$type' 
               ORDER BY a.[title] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($advice_id, $advice) {
        $this->db->where('advice_id', $advice_id);
        
        $query_result = $this->db->update('[dlfwebapp].[dbo].[advice]', $advice);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }

//    
//    
//    function findByUsername($username) {
//        $this->db->select('id, username, password, oldpassword, salt, supplierId, company, active');
//        $this->db->from('madeeasy_account');
//        $this->db->where('username', $username);
//        $this->db->limit(1);
//
//        $query = $this->db->get();
//
//        if ($query->num_rows() == 1) {
//            return $query->row_array();
//        } else {
//            return false;
//        }
//    }
//    
//    function findOneById($id) {
//        $this->db->select('id, username, supplierId, company, tstamp, token, active');
//        $this->db->from('selfserve_user');
//        $this->db->where('id', $id);
//        $this->db->limit(1);
//
//        $query = $this->db->get();
//
//        if ($query->num_rows() == 1) {
//            return $query->row_array();
//        } else {
//            return false;
//        }
//    }
//    
    function insert($advice) {
        
        $query_result = $this->db->insert('[dlfwebapp].[dbo].[advice]', $advice);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
        
    }
    
//     public function getImagesData() {
//
//        $sql = "SELECT  a.[advice_id],a.[picture]
//               FROM [dlfwebapp].[dbo].[advice] a WHERE a.[picture] IS NOT NULL AND a.[picture]!=''
//               ORDER BY a.[advice_id] ASC";
//
//        $query = $this->db->query($sql);
//        return $query->result_array();
//    }
    
    
    
//
//    function update( $uid, $user )
//    {
//        $this->db->where('id', $uid );
//        $this->db->update('selfserve_user', $user);
//        return true;
//    }
//    function create_user() {
//        $first_name = $this->input->post('first_name');
//        $last_name = $this->input->post('last_name');
//        $username = $this->input->post('user_login');
//        $eml = $this->input->post('email_address');
//        $clear_pass = $this->input->post('password');
//        $member_data = array('user_login' => $username, 'user_pass' => md5($clear_pass), 'user_email' => $eml, 'first_name' => $first_name, 'last_name' => $last_name);
//        $insert = $this->db->insert('ci_users', $member_data);
//        return $insert;
//    }
}

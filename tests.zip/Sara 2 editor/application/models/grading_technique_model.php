<?php

Class Grading_technique_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('[id], [grading_id], [technique_id]');
        $this->db->from('[dlfwebapp].[dbo].[grading_technique]');
        $this->db->where('id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

        function findByGradingAndTechniqueId($grading_id, $technique_id) {

        if (!$grading_id || !$technique_id) {
            return false;
        }

        $this->db->select('[id], [grading_id], [technique_id]');
        $this->db->from('[dlfwebapp].[dbo].[grading_technique]');
        $this->db->where('grading_id', $grading_id);
        $this->db->where('technique_id', $technique_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllTechniquesByGradingId($gId) {

        $gId = intval($gId);

        $this->db->select('Count(id) AS total');
        $this->db->from('[dlfwebapp].[dbo].[grading_technique]');
        $this->db->where('grading_id', $gId);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }
    
    function findBySafetyAndTopicId($grading_id, $topic_id) {

        if (!$grading_id || !$topic_id) {
            return false;
        }

        $this->db->select('[id], [grading_id], [topic_id]');
        $this->db->from('[dlfwebapp].[dbo].[grading_technique]');
        $this->db->where('grading_id', $grading_id);
        $this->db->where('topic_id', $topic_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllByEquipmentId($gId) {

        $gId = intval($gId);

        $this->db->select('Count(id) AS total');
        $this->db->from('[dlfwebapp].[dbo].[grading_technique]');
        $this->db->where('grading_id', $gId);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllTechniquesByGradingId($gId, $start, $limit, $sort, $dir) {

        $gId = intval($gId);

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT gt.id, gt.grading_id, gt.technique_id, ad.title 
                FROM [dlfwebapp].[dbo].[advice] ad 
                INNER JOIN [dlfwebapp].[dbo].[grading_technique] gt ON gt.technique_id=ad.advice_id 
                WHERE gt.grading_id=$gId";

        if (!in_array($sort, array('grading_id', 'title'))) {
            $sort = 'grading_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY gt.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('[dlfwebapp].[dbo].[grading_technique]', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('[dlfwebapp].[dbo].[grading_technique]', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        
        return true;
    }

}

<?php

Class Goal_technique_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('[id], [goal_id], [technique_id]');
        $this->db->from('[dlfwebapp].[dbo].[goal_technique]');
        $this->db->where('id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    function findByGoalAndTechniqueId($goal_id, $technique_id) {

        if (!$goal_id || !$technique_id) {
            return false;
        }

        $this->db->select('[id], [goal_id], [technique_id]');
        $this->db->from('[dlfwebapp].[dbo].[goal_technique]');
        $this->db->where('goal_id', $goal_id);
        $this->db->where('technique_id', $technique_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllTechniquesByGoalId($gId) {

        $eid = intval($gId);

        $this->db->select('Count(id) AS total');
        $this->db->from('[dlfwebapp].[dbo].[goal_technique]');
        $this->db->where('goal_id', $gId);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllTechniquesByGoalId($gId, $start, $limit, $sort, $dir) {

        $gId = intval($gId);

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT gt.id, gt.goal_id, gt.technique_id, ad.title 
                FROM [dlfwebapp].[dbo].[advice] ad 
                INNER JOIN [dlfwebapp].[dbo].[goal_technique] gt ON gt.technique_id=ad.advice_id 
                WHERE gt.goal_id=$gId";

        if (!in_array($sort, array('goal_id', 'title'))) {
            $sort = 'goal_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY gt.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('[dlfwebapp].[dbo].[goal_technique]', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('[dlfwebapp].[dbo].[goal_technique]', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }

}

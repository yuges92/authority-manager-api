<?php

Class GeoData_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByName($name) {

        $name = $this->db->escape_like_str($name);
        
        $sql = "SELECT DISTINCT 
                    [town], [county]
                FROM AS_geodata gd
                WHERE gd.town LIKE '%$name%' OR gd.county LIKE '%$name%'
                ORDER BY gd.[town] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
     public function findAllCounties() {

        $sql = "SELECT DISTINCT gd.[county]
                FROM AS_geodata gd
                ORDER BY gd.[county] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    public function findAllCountiesByName($name) {

        $name = $this->db->escape_like_str($name);
        
        $sql = "SELECT DISTINCT gd.[county]
                FROM AS_geodata gd
                WHERE gd.county LIKE '%$name%'
                ORDER BY gd.[county] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    function findOneCountyByCounty($county) {

        if (!$county) {
            return false;
        }

        $this->db->select('*');
        $this->db->from('AS_geodata');
        $this->db->where('county', $county);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    public function findAllCitiesByCounty($county) {

        $county = $this->db->escape_like_str($county);
        
        $sql = "SELECT DISTINCT gd.[town]
                FROM AS_geodata gd
                WHERE gd.county LIKE '%$county%'
                ORDER BY gd.[town] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

}

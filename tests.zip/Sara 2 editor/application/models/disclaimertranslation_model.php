<?php

Class Disclaimertranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($dtId) {

        $dtId = intval($dtId);
        
        $this->db->select('dt.*');
        $this->db->from('AS_disclaimertranslation dt');
        $this->db->where('dt.id', $dtId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllByDisclaimer($dId) {

        $this->db->select('*');
        $this->db->from('AS_disclaimertranslation dt');
        $this->db->where('dt.disclaimerid', intval($dId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByDisclaimer($dId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'code', 'language', 'title', 'disclaimer'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_disclaimertranslation dt');
        $this->db->where('dt.disclaimerid', intval($dId));  //this is condition    
        $this->db->order_by("dt.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneByDisclaimerIdAndCode($dtId, $code) {

        $dtId = intval($dtId);
        
        $this->db->select('dt.*');
        $this->db->from('AS_disclaimertranslation dt');
        $this->db->where('dt.disclaimerid', $dtId);
        $this->db->where('dt.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }

    function update($dtId, $disclaimer_translation) {
        
        $this->db->where('id', intval($dtId));
        $query_result = $this->db->update('AS_disclaimertranslation', $disclaimer_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($disclaimer_translation) {

        $query_result = $this->db->insert('AS_disclaimertranslation', $disclaimer_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_disclaimertranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}

<?php

Class Authoritytextreplace_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('atr.*');
        $this->db->from('AS_authority_textreplace atr');
        $this->db->where('atr.id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    public function countAllByAuthorityId($authority_id) {

        $authority_id = intval($authority_id);

        $this->db->select('Count(atr.id) AS total');
        $this->db->from('AS_authority_textreplace atr');
        $this->db->where('atr.authority_id', $authority_id);

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAuthorityId($authority_id, $start_param, $limit_param, $sort_param, $dir_param) {

        $authority_id = intval($authority_id);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = 'id';
        if (in_array($sort_param, array('id', 'authority_id', 'look_for', 'action', 'replace_with'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT atr.id
                      ,atr.authority_id
                      ,atr.look_for
                      ,atr.action
                      ,atr.replace_with
                FROM AS_authority_textreplace atr WHERE atr.authority_id=$authority_id 
                ORDER BY atr.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('AS_authority_textreplace', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('AS_authority_textreplace', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
    function update($id, $record) {
        $this->db->where('id', $id);
        
        $query_result = $this->db->update('AS_authority_textreplace', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }
    

}

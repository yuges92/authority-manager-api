<?php

Class SectionIdea_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($pkey) {

        if (!$pkey) {
            return false;
        }

        $this->db->select('si.pkey,si.sectionid,i.ideaid,i.title AS ideatitle,i.sadescription AS ideadescription,i.references,si.displaytype,si.order');
        $this->db->from('AS_section_idea si');
        $this->db->join('AS_idea i', 'si.ideaid=i.ideaid', 'left');
        $this->db->where('si.pkey', $pkey);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    /*
    public function countAllUnverified() {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    */
    
    public function countAll($sectionid) {

        $sectionid = intval($sectionid);
        
        $sql = "SELECT COUNT(si.sectionid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_section_idea] si
                WHERE si.sectionid='$sectionid'";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($sectionid, $start, $limit, $order_by, $dir) {

        $sectionid = intval($sectionid);
        
        if (!in_array($order_by, array('displaytype', 'order', 'title', 'ideaid'))) {
            $order_by = 'i.ideaid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }
        
        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        //$sort = trim($sort);
        //$dir = trim($dir);

        $this->db->select('si.pkey,si.sectionid,i.ideaid,i.title AS ideatitle,i.sadescription AS ideadescription,i.references,si.displaytype,si.order');
        $this->db->from('AS_section_idea si');
        $this->db->join('AS_idea i', 'si.ideaid=i.ideaid', 'left');
        $this->db->where('si.sectionid', $sectionid);
        
//        $sql = "SELECT si.pkey
//                      ,si.sectionid
//                      ,i.ideaid
//                      ,i.title AS ideatitle
//                      ,i.sadescription AS ideadescription
//                      ,i.[references]
//                      ,si.displaytype
//                      ,si.[order]
//                FROM sectionidea si
//                LEFT JOIN idea i ON si.ideaid=i.ideaid
//                WHERE si.sectionid='$sectionid'";
        
//        if (!in_array($sort, array('ideaid', 'title', 'displaytype', 'order'))) {
//            $sort = 'ideaid';
//        }
//        if (!in_array($dir, array('DESC', 'ASC'))) {
//            $dir = 'ASC';
//        }
//
//        $sql.=" ORDER BY i.[$sort] $dir";
//        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

//        $query = $this->db->query($sql);
//
//        return $query->result_array();
        
        $this->db->where('si.sectionid', $sectionid);  //this is condition   
        $this->db->order_by("i.$order_by", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }


    function update($pkey, $sectionidea) {
        $this->db->where('pkey', $pkey);
        
        $query_result = $this->db->update('AS_section_idea', $sectionidea);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }

    function insert($authority) {
        
        $query_result = $this->db->insert('authority', $authority);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
        
    }
    
    function delete($pkey) {

        $query_result = $this->db->delete('AS_section_idea', array('pkey' => $pkey));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
}

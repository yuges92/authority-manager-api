<?php

Class Reference_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($references_id) {

        if (!$references_id) {
            return false;
        }

        $this->db->select('[references_id]
                            ,[author]
                            ,[year]
                            ,[title]
                            ,[journal]
                            ,[edition]
                            ,[vol_and_no]
                            ,[chapter]
                            ,[pages]
                            ,[publisher]
                            ,[place]
                            ,[url]
                            ,[abstract]
                            ,[isbn_doi]
                            ,CONVERT(VARCHAR(10), [last_accessed], 121) AS [last_accessed]
                            ,[last_accessed_original]
                            ,[evidence_type]
                            ,[type]
                            ,[non_english_title]
                            ,[created]
                            ,[created_by]
                            ,[modified]
                            ,[modified_by]
                            ,[status]
                            ,CONVERT(VARCHAR(10), [isreview_date], 121) AS [isreview_date]');
        $this->db->from('references');
        $this->db->where('references_id', $references_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAll($search_by, $search_key) {

        $sql = "SELECT Count(r.references_id) AS total
                FROM [" . DB_NAME . "].[dbo].[references] r WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            
            $search_key = $this->db->escape_like_str($search_key);
            
            if($search_by==11) {
                $sql .= " AND r.references_id LIKE '$search_key%'";
            } elseif($search_by==12) {
                $sql .= " AND r.title LIKE '$search_key%'";
            } elseif($search_by==13) {
                $sql .= " AND r.year LIKE '$search_key%'";
            } elseif($search_by==14) {
                $sql .= " AND r.author LIKE '$search_key%'";
            } elseif($search_by==15) {
                $sql .= " AND r.journal LIKE '$search_key%'";
            }
        }
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($search_by, $search_key, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT r.[references_id]
                    ,r.[author]
                    ,r.[year]
                    ,r.[title]
                    ,r.[journal]
                    ,r.[edition]
                    ,r.[vol_and_no]
                    ,r.[chapter]
                    ,r.[pages]
                    ,r.[publisher]
                    ,r.[place]
                    ,r.[url]
                    ,r.[abstract]
                    ,r.[isbn_doi]
                    ,r.[last_accessed]
                    ,r.[evidence_type]
                    ,r.[type]
                    ,r.[non_english_title]
                    ,r.[created]
                    ,r.[created_by]
                    ,r.[modified]
                    ,r.[modified_by]
                    ,r.[status]
                    ,r.[status]
                    ,r.[isreview_date]
               FROM [" . DB_NAME . "].[dbo].[references] r WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            $search_key = $this->db->escape_like_str($search_key);
            if($search_by==11) {
                $sql .= " AND r.references_id LIKE '$search_key%'";
            } elseif($search_by==12) {
                $sql .= " AND r.title LIKE '$search_key%'";
            } elseif($search_by==13) {
                $sql .= " AND r.year LIKE '$search_key%'";
            } elseif($search_by==14) {
                $sql .= " AND r.author LIKE '$search_key%'";
            } elseif($search_by==15) {
                $sql .= " AND r.journal LIKE '$search_key%'";
            }
        }
        
        if (!in_array($sort, array('references_id', 'title', 'author', 'year', 'journal'))) {
            $sort = 'references_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY r.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    /**
     * returns all idea references records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAllByIdea($sara_ideaid) {

        $sara_ideaid = intval($sara_ideaid);
        if ($sara_ideaid < 0) {
            $sara_ideaid = 0;
        }
         
        $sql = "SELECT Count(rl.[ref_lookup_pk]) AS total
                FROM [" . DB_NAME . "].[dbo].[references] r
                LEFT JOIN [" . DB_NAME . "].[dbo].[ref_lookup] rl
                ON r.[references_id]=rl.[ref_id]
                WHERE rl.[ideaid]=$sara_ideaid";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    
    
    /**
     * returns all idea references records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdea($sara_ideaid, $start, $limit, $sort, $dir) {

        $sara_ideaid = intval($sara_ideaid);
        if ($sara_ideaid < 0) {
            $sara_ideaid = 0;
        }
        
        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT r.[references_id]
                    ,r.[author]
                    ,r.[year]
                    ,r.[title]
                    ,rl.[ref_lookup_pk] as id
                FROM [" . DB_NAME . "].[dbo].[references] r
                LEFT JOIN [" . DB_NAME . "].[dbo].[ref_lookup] rl
                ON r.[references_id]=rl.[ref_id]
                WHERE rl.[ideaid]=$sara_ideaid";
        
        if (!in_array($sort, array('references_id', 'title', 'author', 'year'))) {
            $sort = 'references_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY r.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    /**
     * returns all disclainer references records in database.
     * @access public
     * @return array|false the disclainer references records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAllByDisclaimer($dId) {

        $sql = "SELECT Count(rl.[ref_lookup_pk]) AS total
                FROM [" . DB_NAME . "].[dbo].[references] r
                LEFT JOIN [" . DB_NAME . "].[dbo].[ref_lookup] rl
                ON r.[references_id]=rl.[ref_id]
                WHERE rl.[sara_disclaimerid]=?";
        
        $query = $this->db->query($sql, array('sara_disclaimerid', intval($dId)));
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    
    
    /**
     * returns all disclainer references records in database.
     * @access public
     * @return array|false the disclainer references records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByDisclaimer($dId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }
        if (!in_array($sort, array('references_id', 'title', 'author', 'year'))) {
            $sort = 'references_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT r.[references_id]
                    ,r.[author]
                    ,r.[year]
                    ,r.[title]
                    ,rl.[ref_lookup_pk] as id
                FROM [" . DB_NAME . "].[dbo].[references] r
                LEFT JOIN [" . DB_NAME . "].[dbo].[ref_lookup] rl
                ON r.[references_id]=rl.[ref_id]
                WHERE rl.[sara_disclaimerid]=?";
        

        $sql.=" ORDER BY r.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql, array('sara_disclaimerid', intval( $dId ) ));
        $result = $query->result_array();
        echo $this->db->last_query();exit;
        
        return $result;
    }
    
     /**
     * returns all journals records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllJournalsByName($name) {

        $name = $this->db->escape_like_str($name);
        
        $sql = "SELECT DISTINCT r.[journal]
                FROM [" . DB_NAME . "].[dbo].[references] r
                WHERE r.journal LIKE '%$name%'
                ORDER BY r.[journal] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    
    
    /*
     public function countAllByNameAndType($name, $type) {

         $name = $this->db->escape_like_str($name);
         $type = $this->db->escape_like_str($type);
         
        $sql = "SELECT Count(references_id) AS total
                FROM [" . DB_NAME . "].[dbo].[references] a WHERE a.title LIKE '$name%' AND a.advice_type='$type'";
           
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }*/

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
   /* public function findAllByNameAndType($name, $type) {

        $name = $this->db->escape_like_str($name);
        $type = $this->db->escape_like_str($type);
        
        $sql = "SELECT  a.[references_id]
                    ,a.[advice_type]
                    ,a.[title]
                    ,a.[references]
                    ,a.[status]
                    ,a.[description]
                    ,a.[group_id]
                    ,a.[picture]
                    ,a.[video]
                    ,a.[created_by]
                    ,a.[created]
                    ,a.[verified_by]
                    ,a.[verified]
                    ,a.[product_id]
                    ,a.[user_id]
                    ,a.[modified]
                    ,a.[modified_by]
               FROM [" . DB_NAME . "].[dbo].[references] a WHERE a.title LIKE '$name%' AND a.advice_type='$type' 
               ORDER BY a.[title] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }*/

    function update($references_id, $reference) {
        $this->db->where('references_id', $references_id);
        
        $query_result = $this->db->update('references', $reference);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }

    function insert($reference) {
        
        $query_result = $this->db->insert('references', $reference);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
        
    }
    
}

<?php

Class Ideaauthority_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function insert($record) {

        $query_result = $this->db->insert('AS_idea_authority', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('AS_idea_authority', array('pkey' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}
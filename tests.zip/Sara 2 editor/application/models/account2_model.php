<?php

Class Account2_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * returns an account record by id in database.
     * @access public
     * @return array|false the account record found in database, FALSE otherwise (i.e.none record found).
     */
    function find($accno) {

        if (!$accno) {
            return false;
        }

        $this->db->select('accno
                          ,username
                          ,password
                          ,type
                          ,read_permission
                          ,write_permission
                          ,edit_permission
                          ,delete_permission
                          ,created
                          ,company_name
                          ,active');
        $this->db->from('sara_account a');
        $this->db->where('a.accno', $accno);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    /**
     * returns count of all account records in database.
     * @access public
     * @return int|false the count of all account records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAll() {

        $sql = "SELECT COUNT(a.accno) AS total
                FROM sara_account a";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all answer records in database.
     * @access public
     * @return array|false the answer records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (!in_array($sort, array('accno', 'username', 'company_name'))) {
            $sort = 'accno';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT a.accno
                    ,a.username
                    ,a.read_permission
                    ,a.write_permission
                    ,a.edit_permission
                    ,a.delete_permission
                    ,a.created
                    ,a.company_name
                FROM sara_account a";

        $sql.=" ORDER BY a.$sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($accno, $account) {
        $this->db->where('accno', $accno);
        $query_result = $this->db->update('sara_account', $account);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }

    function insert($account) {

        $query_result = $this->db->insert('sara_account', $account);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return $this->db->insert_id();
    }

//    function delete($accno) {
//
//        $query_result = $this->db->delete(DB_NAME . '[dbo].[sara_account]', array('accno' => $accno));
//        if (!$query_result) {
//            $this->error = $this->db->_error_message();
//            $this->errorno = $this->db->_error_number();
//            return false;
//        }
//        return true;
//    }

}

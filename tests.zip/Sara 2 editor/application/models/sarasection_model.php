<?php

Class Sarasection_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    public function findAllSaraDefaultSections() {

        $sql = "SELECT *
                FROM [" . DB_NAME . "].[dbo].[AS_section] s
                WHERE (s.url IS NULL OR s.url='' ) AND s.sectionid not in (
                        SELECT DISTINCT sa.sectionid
                        FROM [" . DB_NAME . "].[dbo].[AS_section_authority] sa
                        WHERE sa.authority_id = '20' OR sa.authority_id = '21' OR sa.authority_id = '43' OR sa.authority_id = '47' OR sa.authority_id = '38'
                )
                ORDER BY s.name ASC";

     //   echo $sql;exit;
        
        $query = $this->db->query($sql);
        return $query->result_array();
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAuthorityIds($authority_ids) {

        $this->db->select('s.sectionid
                          ,s.name
                          ,s.order
                          ,s.description
                          ,s.video_url
                          ,s.url
                          ,s.firstquestionid
                          ,s.parent_id
                          ,s.filename
                          ,s.peer_verified
                          ,s.peer_verified_by
                          ,s.used');
        $this->db->from('AS_section s');
        $this->db->join('AS_section_authority sa', 'sa.sectionid=s.sectionid', 'left');
        $this->db->where_in('sa.authority_id', $authority_ids);
        $this->db->where("(s.url IS NULL OR s.url='')");
        $this->db->order_by("s.name", "asc");
        $query = $this->db->get();

        //print_r($this->db->last_query());
        //exit;

        return $query->result_array();
    }

}

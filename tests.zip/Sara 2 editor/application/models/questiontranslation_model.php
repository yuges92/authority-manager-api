<?php

Class Questiontranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($qtId) {

        $qtId = intval($qtId);
        
        $this->db->select('qt.*');
        $this->db->from('AS_questiontranslation qt');
        $this->db->where('qt.id', $qtId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllByQuestion($qId) {

        $this->db->select('*');
        $this->db->from('AS_questiontranslation qt');
        $this->db->where('qt.questionid', intval($qId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByQuestion($qId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'code', 'language', 'sadescription'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_questiontranslation qt');
        //$this->db->join('question q', 'qt.questionid = q.questionid');
        $this->db->where('qt.questionid', intval($qId));  //this is condition    
        $this->db->order_by("qt.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneByQuestionIdAndCode($qtId, $code) {

        $qtId = intval($qtId);
        
        $this->db->select('qt.*');
        $this->db->from('AS_questiontranslation qt');
        $this->db->where('qt.questionid', $qtId);
        $this->db->where('qt.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }

    function update($qtId, $question_translation) {
        
        $this->db->where('id', intval($qtId));
        $query_result = $this->db->update('AS_questiontranslation', $question_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($question_translation) {

        $query_result = $this->db->insert('AS_questiontranslation', $question_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_questiontranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}

<?php

Class Reference_link_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($references_id) {

        if (!$references_id) {
            return false;
        }

        $this->db->select('*');
        $this->db->from('reference_link');
        $this->db->where('id', $references_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

     public function countAllByReferenceId($references_id) {

         $references_id = intval($references_id);
         
        $sql = "SELECT Count(rl.references_id) AS total
                FROM [" . DB_NAME . "].[dbo].[reference_link] rl
                WHERE rl.references_id = $references_id";
           
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByReferenceId($references_id, $start, $limit, $sort, $dir) {

        $references_id=intval($references_id);
        
        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT rl.*
               FROM [" . DB_NAME . "].[dbo].[reference_link] rl
               WHERE references_id=$references_id";
        
        if (!in_array($sort, array('references_id', 'lme_groupid', 'lme_scenarion_id', 'lme_scenarion_id', 'sara_ideaid','sara_disclaimerid','dlf_class_id','reable_advice_id'))) {
            $sort = 'references_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY rl.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    

    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('reference_link', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function update($rId, $record) {
        $this->db->where('id', $rId);
        
        $query_result = $this->db->update('reference_link', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }
    
    function delete($id) {

        $query_result = $this->db->delete('reference_link', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }

}

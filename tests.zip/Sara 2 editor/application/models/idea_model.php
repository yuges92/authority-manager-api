<?php

Class Idea_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($ideaid) {

        $ideaid = intval($ideaid);
        if($ideaid<0) {
            $ideaid=0;
        }
        
        $this->db->select('i.*');
        $this->db->from('AS_idea i');
        $this->db->where('i.ideaid', $ideaid);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

//    public function countAllUnverified() {
//
//        $sql = "SELECT Count(id) AS total
//                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";
//        
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//        
//    }
    
    
    public function countAll() {

        $sql = "SELECT COUNT(i.ideaid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_idea] i";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT i.ideaid
                      ,i.title
                      ,i.sadescription
                      ,i.[references]
                      ,i.filename
                      ,i.created
                      ,i.created_by
                      ,i.modified
                      ,i.modified_by
                FROM [" . DB_NAME . "].[dbo].[AS_idea] i";
        
        if (!in_array($sort, array('ideaid', 'title'))) {
            $sort = 'ideaid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY i.$sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

//     public function countAllByNameAndType($name, $type) {
//
//         $name = $this->db->escape_like_str($name);
//         $type = $this->db->escape_like_str($type);
//         
//        $sql = "SELECT Count(a.authority_id) AS total
//                FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.title LIKE '$name%' AND a.authority_type='$type'";
//           
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByNameAndType($name, $type) {

        $name = $this->db->escape_like_str($name);
        $type = $this->db->escape_like_str($type);
        
        $sql = "SELECT  a.authority_id
                    ,a.authority_type
                    ,a.title
                    ,a.authority
                    ,a.status
                    ,a.description
                    ,a.group_id
                    ,a.picture
                    ,a.video
                    ,a.created_by
                    ,a.created
                    ,a.verified_by
                    ,a.verified
                    ,a.product_id
                    ,a.user_id
                    ,a.modified
                    ,a.modified_by
               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.title LIKE '$name%' AND a.authority_type='$type' 
               ORDER BY a.title ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($ideaid, $idea) {
        
//        echo '<pre>';
//        print_r($idea);
//        echo '</pre>';
//        exit;
        
        $ideaid = intval($ideaid);
        
        $this->db->where('ideaid', $ideaid);
        $query_result = $this->db->update('AS_idea', $idea);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
         
        return true;
    }

    function insert($idea) {
        
        $query_result = $this->db->insert('AS_idea', $idea);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
        
    }
    
//     public function getImagesData() {
//
//        $sql = "SELECT  a.authority_id,a.picture
//               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.picture IS NOT NULL AND a.picture!=''
//               ORDER BY a.authority_id ASC";
//
//        $query = $this->db->query($sql);
//        return $query->result_array();
//    }
}

<?php

Class Disclaimerauthority_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $sql="SELECT da.* FROM [" . DB_NAME . "].[dbo].[AS_disclaimer_authority] da WHERE da.pkey=".$id;
        $query = $this->db->query($sql);

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    function insert($record) {

        $query_result = $this->db->insert('AS_disclaimer_authority', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $sql="DELETE FROM [" . DB_NAME . "].[dbo].[AS_disclaimer_authority] WHERE pkey=".$id;
        
        $query = $this->db->query($sql);

        if ($query) {
            return true;
        } else {
            return false;
        }
    }
    
}
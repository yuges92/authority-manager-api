<?php

Class Answer_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    /**
     * returns an answer record by id in database.
     * @access public
     * @return array|false the answer record found in database, FALSE otherwise (i.e.none record found).
     */
    function find($answerid) {

        if (!$answerid) {
            return false;
        }

        $this->db->select('a.*');
        $this->db->from('AS_answer a');
        $this->db->where('a.answerid', $answerid);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    /**
     * returns count of all answer records in database.
     * @access public
     * @return int|false the count of all answer records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAll() {

        $sql = "SELECT COUNT(a.answerid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_answer] a";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all answer records in database.
     * @access public
     * @return array|false the answer records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (!in_array($sort, array('answerid', 'description'))) {
            $sort = 'answerid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT a.answerid
                    ,a.description
                    ,a.[index]
                    ,a.filename
                FROM [" . DB_NAME . "].[dbo].[AS_answer] a";
        
        $sql.=" ORDER BY a.$sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    
    /**
     * returns all answer records in database.
     * @access public
     * @return array|false the answer records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByQuestion($qId) {

        $qId = intval($qId);
        
        $sql = "SELECT a.description
                    ,qa.nextquestionid
                    ,q.sadescription
                FROM [" . DB_NAME . "].[dbo].[AS_question_answer] qa 
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_answer] a ON qa.answerid=a.answerid
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_question] q ON qa.nextquestionid=q.questionid
                WHERE qa.questionid=$qId";
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($answerid, $answer) {
        $this->db->where('answerid', $answerid);
        $query_result = $this->db->update('AS_answer', $answer);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
         return true;
    }

    function insert($answer) {
        
        $query_result = $this->db->insert('AS_answer', $answer);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
         return $this->db->insert_id();
    }
    
    function delete($answerid) {

        $query_result = $this->db->delete('AS_answer', array('answerid' => $answerid));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
}

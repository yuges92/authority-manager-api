<?php

Class Question_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($qId) {

        $qId = intval($qId);

        $this->db->select('q.*');
        $this->db->from('AS_question q');
        $this->db->where('q.questionid', $qId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllBySection($sId) {

        $sId = intval($sId);

        $sql = "SELECT COUNT(q.questionid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_question] q
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE q.[sectionid] = $sId";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllBySection($sId, $start, $limit, $sort, $dir) {

        $sId = intval($sId);

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit > 1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('questionid', 'sadescription'))) {
            $sort = 'questionid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT q.[questionid],
                    q.[sadescription],
                    q.[filename],
                    q.[sectionid],
                    s.[name] AS sectionname,
                    q.[reportgroup],
                    q.[status],
                    q.[order],
                    q.[reportgroup],
                    q.[explanation],
                    q.[internalnotes],
                    q.[samplequestion],
                    ( CASE WHEN s.firstquestionid=q.[questionid] THEN 1 ELSE 0 END ) AS isfirstquestion
                FROM   [" . DB_NAME . "].[dbo].[AS_question] q
                    LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE  q.[sectionid] = $sId ";

        $sql .= " ORDER BY q.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    public function countAllByIdea($ideaid) {

        $sql = "SELECT COUNT(q.questionid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_question_answer_idea] qai
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_question] q ON qai.questionid = q.questionid
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE qai.[ideaid] = ?";

        $query = $this->db->query($sql, array(intval($ideaid)));
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdea($ideaid, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (!in_array($sort, array('questionid', 'name'))) {
            $sort = 'questionid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT q.[questionid],
                       CAST (q.[sadescription] AS VARCHAR(MAX)) AS [sadescription],
                       s.[name] AS section_name,
                       qai.[ideaid]
                FROM [" . DB_NAME . "].[dbo].[AS_question_answer_idea] qai
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_question] q ON qai.questionid = q.questionid
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE  qai.[ideaid] = ?";

        Switch ($sort) :
            case 'questionid' :
                $sort = 'q.[questionid]';
                break;
            case 'name':
                $sort = 's.[name]';
                break;
        endswitch;

        $sql .= " ORDER BY $sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql, array(intval($ideaid)));

        return $query->result_array();
    }

    public function countAllByDisclaimer($disclaimerid) {

        $sql = "SELECT COUNT(q.questionid) AS total
                FROM [" . DB_NAME . "].[dbo].[AS_question_answer_disclaimer] qad
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_question] q ON qad.questionid = q.questionid
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE qad.[disclaimerid] = ?";

        $query = $this->db->query($sql, array(intval($disclaimerid)));
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all the disclaimer question records in database.
     * @access public
     * @return array|false the disclaimer questions records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByDisclaimer($dId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        if (!in_array($sort, array('questionid', 'name'))) {
            $sort = 'questionid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT q.[questionid],
                       CAST (q.[sadescription] AS VARCHAR(MAX)) AS [sadescription],
                       s.[name] AS section_name,
                       qad.[disclaimerid]
                FROM [" . DB_NAME . "].[dbo].[AS_question_answer_disclaimer] qad
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_question] q ON qad.questionid = q.questionid
                LEFT JOIN [" . DB_NAME . "].[dbo].[AS_section] s ON q.sectionid = s.sectionid
                WHERE qad.[disclaimerid] = ?";

        Switch ($sort) :
            case 'questionid' :
                $sort = 'q.[questionid]';
                break;
            case 'name':
                $sort = 's.[name]';
                break;
        endswitch;

        $sql .= " ORDER BY $sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql, array(intval($dId)));

        return $query->result_array();
    }

    function update($questionid, $question) {
        $this->db->where('questionid', $questionid);

        $query_result = $this->db->update('AS_question', $question);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($question) {

//        echo '<pre>';
//        print_r($question);
//        echo '</pre>';
//        exit;
//        
        $query_result = $this->db->insert('AS_question', $question);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }

}

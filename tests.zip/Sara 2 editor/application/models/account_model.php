<?php

Class Account_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function findByUsername($username) {
        $this->db->select('type');
        $this->db->from('madeeasy_account');
        $this->db->where('username', $username);
        //$this->db->where('type', 'administrator');
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->row_array();
        } else {
            return false;
        }
    }
    
//    function findOneById($id) {
//        $this->db->select('id, username, supplierId, company, tstamp, token, active');
//        $this->db->from('selfserve_user');
//        $this->db->where('id', $id);
//        $this->db->limit(1);
//
//        $query = $this->db->get();
//
//        if ($query->num_rows() == 1) {
//            return $query->row_array();
//        } else {
//            return false;
//        }
//    }
    
//    function insert($user) {
//        
////        $data = array(
////            'username' => $username,
////            'password' => md5('#rEpUbLiC@123')
////        );
//
////        echo '<pre>';
////        print_r($user);
////        echo '</pre>';
//        
//        return $this->db->insert('selfserve_user', $user);
//    }

//    function update( $uid, $user )
//    {
//        $this->db->where('id', $uid );
//        $this->db->update('selfserve_user', $user);
//        return true;
//    }
    
//    function create_user() {
//        $first_name = $this->input->post('first_name');
//        $last_name = $this->input->post('last_name');
//        $username = $this->input->post('user_login');
//        $eml = $this->input->post('email_address');
//        $clear_pass = $this->input->post('password');
//        $member_data = array('user_login' => $username, 'user_pass' => md5($clear_pass), 'user_email' => $eml, 'first_name' => $first_name, 'last_name' => $last_name);
//        $insert = $this->db->insert('ci_users', $member_data);
//        return $insert;
//    }

}

<?php

Class Sectiontranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($gtId) {

        $gtId = intval($gtId);
        
        $this->db->select('st.*');
        $this->db->from('AS_sectiontranslation st');
        $this->db->where('st.id', $gtId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllBySection($sId) {

        $this->db->select('*');
        $this->db->from('AS_sectiontranslation st');
        $this->db->where('st.sectionid', intval($sId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllBySection($sId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'code', 'language', 'name', 'description'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_sectiontranslation st');
        $this->db->where('st.sectionid', intval($sId));  //this is condition    
        $this->db->order_by("st.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneBySectionIdAndCode($stId, $code) {

        $stId = intval($stId);
        
        $this->db->select('st.*');
        $this->db->from('AS_sectiontranslation st');
        $this->db->where('st.sectionid', $stId);
        $this->db->where('st.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }

    function update($stId, $section_translation) {
        
        $this->db->where('id', intval($stId));
        $query_result = $this->db->update('AS_sectiontranslation', $section_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($section_translation) {

        $query_result = $this->db->insert('AS_sectiontranslation', $section_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_sectiontranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}

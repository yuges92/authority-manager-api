<?php

Class Equipment_topic_model extends CI_Model {

    function __construct() {
        parent::__construct();

    }

    function find($id) {

        if (!$id) {
            return false;
        }

        $this->db->select('[id], [equipment_id], [topic_id]');
        $this->db->from('[dlfwebapp].[dbo].[equipment_topic]');
        $this->db->where('id', $id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    function findByEquipmentAndTopicId($equipment_id, $topic_id) {

        if (!$equipment_id || !$topic_id) {
            return false;
        }

        $this->db->select('[id], [equipment_id], [topic_id]');
        $this->db->from('[dlfwebapp].[dbo].[equipment_topic]');
        $this->db->where('equipment_id', $equipment_id);
        $this->db->where('topic_id', $topic_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    
    public function countAllByEquipmentId($eId) {

        $eId = intval($eId);
        
        $this->db->select('Count(id) AS total');
        $this->db->from('[dlfwebapp].[dbo].[equipment_topic]');
        $this->db->where('equipment_id', $eId);
       
        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByEquipmentId($eId, $start, $limit, $sort, $dir) {

        $eId = intval($eId);
        
        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }
        $sort = intval($sort);
        if ($sort <= 0) {
            $sort = 1;
        }
        
        $sql = "SELECT et.[id]
                    ,et.[topic_id]
                    ,t.[title]
                FROM [dlfwebapp].[dbo].[equipment_topic] et, [dlfwebapp].[dbo].[topic] t 
                WHERE et.topic_id=t.topic_id AND et.equipment_id=$eId";
        
        $dir = trim($dir);
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY $sort $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }
    
    
    function insert($record) {
        
        //return $this->db->insert('selfserve_user', $user);
        
        $query_result = $this->db->insert('[dlfwebapp].[dbo].[equipment_topic]', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
        
    }

    function delete( $id )
    {
         
        $query_result = $this->db->delete('[dlfwebapp].[dbo].[equipment_topic]', array('id' => $id)); 
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
         
         return true;
        
    }
}
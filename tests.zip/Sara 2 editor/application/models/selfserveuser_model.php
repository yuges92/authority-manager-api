<?php

Class SelfServeUser_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($pid) {

        if (!$pid) {
            return false;
        }

        $this->db->select('id, username, firstname, lastname, phone, company, supplierId, active, createdAt, updatedAt, updatedBy, [statistics], lastLoginAt');
        $this->db->from('selfserve_user');
        $this->db->where('id', $pid);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllUnverified() {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    
     /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllUnverIfied($start, $limit, $sort, $dir) {

        $sql = "SELECT [id]
                ,[firstname]
                ,[lastname]
                ,[username]
                ,[phone]
                ,[typeAccess]
                ,[active]
                ,[supplierId]
                ,[company]
                ,[updatedAt]
                ,[updatedBy]
                ,[createdAt]
                ,[salt]
                ,[token]
                ,[tstamp]
                ,[file]
                ,[statistics]
                ,[lastLoginAt]
            FROM [" . DB_NAME . "].[dbo].[selfserve_user] WHERE supplierId IS NULL OR supplierId=''";

        
        if (!in_array($sort, array('createdAt', 'company', 'username'))) {
            $sort = 'createdAt';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }
        $sql.=" ORDER BY [dbo].[selfserve_user].[$sort] $dir";
        
        $sql .= " OFFSET " . intval($start) . " ROWS FETCH NEXT ". intval($limit) ."ROWS ONLY";

        $query = $this->db->query($sql);
        return $query->result_array();
    }
    
    public function countAll($search_key='') {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user";
        
        if(strlen($search_key)>0) {
            $search_key = $this->db->escape_like_str($search_key);
            $sql.=" WHERE username LIKE '%$search_key%' OR company LIKE '%$search_key%'";
        }
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($search_key, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT [id]
                        ,[firstname]
                        ,[lastname]
                        ,[username]
                        ,[phone]
                        ,[typeAccess]
                        ,[active]
                        ,[supplierId]
                        ,[company]
                        ,[updatedAt]
                        ,[updatedBy]
                        ,[createdAt]
                        ,[salt]
                        ,[token]
                        ,[tstamp]
                        ,[file]
                        ,[statistics]
                        ,[lastLoginAt]
                    FROM [" . DB_NAME . "].[dbo].[selfserve_user] ";

        if(strlen($search_key)>0) {
            $search_key = $this->db->escape_like_str($search_key);
            $sql.=" WHERE username LIKE '%$search_key%' OR company LIKE '%$search_key%'";
        }
        

        if (!in_array($sort, array('createdAt', 'company', 'username'))) {
            $sort = 'createdAt';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY [dbo].[selfserve_user].[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($uid, $selfserve_user) {
        $this->db->where('id', $uid);
        
        $query_result = $this->db->update('selfserve_user', $selfserve_user);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }

//    
//    
//    function findByUsername($username) {
//        $this->db->select('id, username, password, oldpassword, salt, supplierId, company, active');
//        $this->db->from('madeeasy_account');
//        $this->db->where('username', $username);
//        $this->db->limit(1);
//
//        $query = $this->db->get();
//
//        if ($query->num_rows() == 1) {
//            return $query->row_array();
//        } else {
//            return false;
//        }
//    }
//    
//    function findOneById($id) {
//        $this->db->select('id, username, supplierId, company, tstamp, token, active');
//        $this->db->from('selfserve_user');
//        $this->db->where('id', $id);
//        $this->db->limit(1);
//
//        $query = $this->db->get();
//
//        if ($query->num_rows() == 1) {
//            return $query->row_array();
//        } else {
//            return false;
//        }
//    }
//    
//    function insert($user) {
//        
////        $data = array(
////            'username' => $username,
////            'password' => md5('#rEpUbLiC@123')
////        );
//
////        echo '<pre>';
////        print_r($user);
////        echo '</pre>';
//        
//        return $this->db->insert('selfserve_user', $user);
//    }
//
//    function update( $uid, $user )
//    {
//        $this->db->where('id', $uid );
//        $this->db->update('selfserve_user', $user);
//        return true;
//    }
//    function create_user() {
//        $first_name = $this->input->post('first_name');
//        $last_name = $this->input->post('last_name');
//        $username = $this->input->post('user_login');
//        $eml = $this->input->post('email_address');
//        $clear_pass = $this->input->post('password');
//        $member_data = array('user_login' => $username, 'user_pass' => md5($clear_pass), 'user_email' => $eml, 'first_name' => $first_name, 'last_name' => $last_name);
//        $insert = $this->db->insert('ci_users', $member_data);
//        return $insert;
//    }
}

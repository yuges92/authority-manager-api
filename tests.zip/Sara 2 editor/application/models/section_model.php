<?php

Class Section_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($sId) {

        $sql = "  SELECT s.[sectionid],
                        s.[name],
                        s.[order],
                        s.[description],
                        s.[video_url],
                        s.[url],
                        s.[firstquestionid],
                        s.[parent_id],
                        g.[name] AS pname,
                        s.[filename],
                        s.[peer_verified],
                        s.[peer_verified_by],
                        s.[used]
                 FROM   [" . DB_NAME . "].[dbo].[AS_section] s
                        LEFT JOIN [" . DB_NAME . "].[dbo].[AS_group] g
                               ON g.sectionid = s.[parent_id]
                 WHERE  s.[sectionid] = ?
                 ORDER  BY s.[name] ASC  ";

        //echo $sql;exit;
        
        $query = $this->db->query($sql, array(intval($sId)));
        if ($query->num_rows() == 0) {
            return FALSE;
        }
        
        return $query->result()[0];
        
    }
    
     /* 
      * returns all section ideas records in database.
      * @access public
      * @return array|false the section ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdea($ideaid, $start, $limit, $sort, $dir) {

        $start = intval($start);
         if ($start < 0) {
             $start = 0;
         }
         $limit = intval($limit);
         if ($limit < 0) {
             $limit = 1000;
         }
        
        if (!in_array($sort, array('sectionid', 'name'))) {
            $sort = 'sectionid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }
        
        $sql = "SELECT DISTINCT s.[name], s.[sectionid]
                FROM [" . DB_NAME . "].[dbo].[AS_section] s, [" . DB_NAME . "].[dbo].[AS_section_idea] si
                WHERE s.[sectionid]=si.[sectionid] AND si.[ideaid]=?";
        
        Switch($sort) :
            case 'sectionid' :
                $sort = 's.[sectionid]';
                break;
            case 'name':
                $sort = 's.[name]';
                break;
        endswitch;
        
        $sql.=" ORDER BY $sort $dir";
        $sql.= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql, array(intval($ideaid)));
        $result = $query->result_array();
        //echo $this->db->last_query();exit;
        return $result;
    }
    
    
    
    /**
     * returns count of all disclainer sections records in database.
     * @access public
     * @return array|false the count of all disclainer sections records found in database, FALSE otherwise (i.e.none record found).
     */
    public function countAllByDisclaimer($dId) {

        $sql = "SELECT DISTINCT COUNT(s.[sectionid]) as total
                FROM [" . DB_NAME . "].[dbo].[AS_section] s, [" . DB_NAME . "].[dbo].[AS_section_disclaimer] si
                WHERE s.[sectionid]=si.[sectionid] AND si.[disclaimerid]=?";
        
        $query = $this->db->query($sql, array(intval($dId)));
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
        
    }
    
    /**
     * returns all section ideas records in database.
     * @access public
     * @return array|false the section ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByDisclaimer($dId, $start, $limit, $sort, $dir) {

        $start = intval($start);
         if ($start < 0) {
             $start = 0;
         }
         $limit = intval($limit);
         if ($limit < 0) {
             $limit = 1000;
         }
        
        if (!in_array($sort, array('sectionid', 'name'))) {
            $sort = 'sectionid';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }
        
        $sql = "SELECT DISTINCT s.[name], s.[sectionid]
                FROM [" . DB_NAME . "].[dbo].[AS_section] s, [" . DB_NAME . "].[dbo].[AS_section_disclaimer] si
                WHERE s.[sectionid]=si.[sectionid] AND si.[disclaimerid]=?";
        
        Switch($sort) :
            case 'sectionid' :
                $sort = 's.[sectionid]';
                break;
            case 'name':
                $sort = 's.[name]';
                break;
        endswitch;
        
        $sql.=" ORDER BY $sort $dir";
        $sql.= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql, array(intval($dId)));
        
        $result = $query->result_array();
        //echo $this->db->last_query();exit;
        return $result;
        
    }
    
    public function countAll($filter_by, $search_key) {

        $sql = "SELECT Count(section_id) AS total
                FROM [dlfwebapp].[dbo].[section] s WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            
            $search_key = $this->db->escape_like_str($search_key);
            
            if($filter_by==11) {
                $sql .= " AND s.section_id LIKE '%$search_key%'";
            } elseif($filter_by==12) {
                $sql .= " AND s.title LIKE '%$search_key%'";
            }
        }
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($filter_by, $search_key, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT s.[section_id]
                    ,s.[title]
                    ,s.[picture]
               FROM [dlfwebapp].[dbo].[section] s WHERE 1=1 ";
        
        if (strlen($search_key) > 0) {
            
            $search_key = $this->db->escape_like_str($search_key);
            
            if($filter_by==11) {
                $sql .= " AND s.section_id LIKE '%$search_key%'";
            } elseif($filter_by==12) {
                $sql .= " AND s.title LIKE '%$search_key%'";
            }
        }
        
        

        if (!in_array($sort, array('section_id', 'title'))) {
            $sort = 'section_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY s.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($sId, $section) {
        $this->db->where('section_id', $sId);
        
        $query_result = $this->db->update('[dlfwebapp].[dbo].[section]', $section);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }

    function insert($section) {
        
        $query_result = $this->db->insert('[dlfwebapp].[dbo].[section]', $section);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return $this->db->insert_id();
         
    }
}
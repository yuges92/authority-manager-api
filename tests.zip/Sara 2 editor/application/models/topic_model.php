<?php

Class Topic_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($tId) {

        if (!$tId) {
            return false;
        }

        $this->db->select('[topic_id], [title], [picture]');
        $this->db->from('[dlfwebapp].[dbo].[topic]');
        $this->db->where('topic_id', $tId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAll($filter_by, $search_key) {

        $sql = "SELECT Count(topic_id) AS total
                FROM [dlfwebapp].[dbo].[topic] t WHERE 1=1 ";

        if (strlen($search_key) > 0) {

            $search_key = $this->db->escape_like_str($search_key);

            if ($filter_by == 11) {
                $sql .= " AND t.topic_id LIKE '%$search_key%'";
            } elseif ($filter_by == 12) {
                $sql .= " AND t.title LIKE '%$search_key%'";
            }
        }

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function searchByTitle($title) {

        $title = $this->db->escape_like_str($title);

        $sql = "SELECT t.[topic_id], t.[title]
                FROM [dlfwebapp].[dbo].[topic] t
                WHERE t.title LIKE '$title%'
                ORDER BY t.[title] ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($filter_by, $search_key, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        $dir = trim($dir);

        $sql = "SELECT t.[topic_id]
                    ,t.[title]
                    ,t.[picture]
               FROM [dlfwebapp].[dbo].[topic] t WHERE 1=1 ";

        if (strlen($search_key) > 0) {

            $search_key = $this->db->escape_like_str($search_key);

            if ($filter_by == 11) {
                $sql .= " AND t.topic_id LIKE '%$search_key%'";
            } elseif ($filter_by == 12) {
                $sql .= " AND t.title LIKE '%$search_key%'";
            }
        }



        if (!in_array($sort, array('topic_id', 'title'))) {
            $sort = 'topic_id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql.=" ORDER BY t.[$sort] $dir";
        $sql .= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($tId, $topic) {
        $this->db->where('topic_id', $tId);

        $query_result = $this->db->update('[dlfwebapp].[dbo].[topic]', $topic);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function insert($topic) {

        $query_result = $this->db->insert('[dlfwebapp].[dbo].[topic]', $topic);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

}

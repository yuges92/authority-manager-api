<?php

Class Supplier_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($sid) {

        if (!$sid) {
            return false;
        }

        $sql = "SELECT "
                . "case WHEN (t2.total_products IS NOT NULL AND t2.total_products>200) THEN 'Y' else 'N' end AS is_master,"
                . "[dbo].[supplier].[supplier_id] , "
                . "[dbo].[supplier].[status] , "
                . "[dbo].[supplier].[supplier_name] , "
                . "[dbo].[supplier].[visitor] , "
                . "[dbo].[supplier].[po_box] , "
                . "[dbo].[supplier].[street_1] , "
                . "[dbo].[supplier].[street_2] , "
                . "[dbo].[supplier].[street_3] , "
                . "[dbo].[supplier].[town_city] , "
                . "[dbo].[supplier].[county] , "
                . "[dbo].[supplier].[postcode] , "
                . "[dbo].[supplier].[country] , "
                . "[dbo].[supplier].[telephone] , "
                . "[dbo].[supplier].[textphone] , "
                . "[dbo].[supplier].[freephone] , "
                . "[dbo].[supplier].[fax] , "
                . "[dbo].[supplier].[email] , "
                . "CAST([dbo].[supplier].[notes] AS Text) as notes , "
                . "[dbo].[supplier].[contact_name] , "
                . "[dbo].[supplier].[contact_job_title] , "
                . "[dbo].[supplier].[contact_email] , "
                . "[dbo].[supplier].[contact_phone] , "
                . "[dbo].[supplier].[showroom] , "
                . "[dbo].[supplier].[accessible] , "
                . "[dbo].[supplier].[homedemo] , "
                . "[dbo].[supplier].[ISO9000] , "
                . "CAST([dbo].[supplier].[external_notes] AS Text) as external_notes , "
                . "[dbo].[supplier].[status_notes] , "
                . "[dbo].[supplier].[web_address] , "
                . "[dbo].[supplier].[store_locator_url] , "
                . "[dbo].[supplier].[withhold_address] , "
                . "[dbo].[supplier].[mail_order] , "
                . "[dbo].[supplier].[internet] , "
                . "[dbo].[supplier].[second_hand] , "
                . "[dbo].[supplier].[national_supplier] , "
                . "[dbo].[supplier].[sell_direct_to_public] , "
                . "[dbo].[supplier].[uk_base] , "
                . "[dbo].[supplier].[BHTA_member] , "
                . "[dbo].[supplier].[created] , "
                . "[dbo].[supplier].[created_by] , "
                . "CONVERT(CHAR(20),[dbo].[supplier].[modified],113) as modified , "
                . "[dbo].[supplier].[modified_by] , "
                . "CONVERT(CHAR(20),[dbo].[supplier].[verified],113) as verified , "
                . "[dbo].[supplier].[verified_by] , "
                . "[dbo].[supplier].[reciprocal_link] , "
                . "[dbo].[supplier].[tsa_member] , "
                . "[dbo].[supplier].[is_selfserve_verified] , "
                . "[dbo].[supplier].[annual_turnover] , "
                . "[dbo].[supplier].[marketing_spend] , "
                . "[dbo].[supplier].[is_manufacturer] , "
                . "[dbo].[supplier].[is_sole_distributor] , "
                . "[dbo].[supplier].[image_permission] , "
                . "[dbo].[supplier].[hire] , "
                . "[dbo].[supplier].[reseller] , "
                . "[dbo].[supplier].[bhta_equivalent] , "
                . "[dbo].[supplier].[tsa_equivalent] , "
                . "[dbo].[supplier].[trade_association] , "
                . "[dbo].[supplier].[charity] , "
                . "CONVERT(CHAR(20),[dbo].[supplier] .selfservice_modified,113) AS selfservice_modified , "
                . "[dbo].[supplier].[selfservice_modified_by] AS selfservice_modified_by, "
                . "[dbo].[supplier].[in_supplier_directory], "
                . "[dbo].[supplier].[image], "
                . "[dbo].[supplier].[after_sales_support], "
                . "[dbo].[supplier].[healthcare_professional_advice], "
                . "[dbo].[supplier].[training_on_product_use], "
                . "[dbo].[supplier].[free_postage_and_packaging], "
                . "[dbo].[supplier].[add_to_mailing_list], "
                . "[dbo].[supplier].[sells_to_public_sector], "
                . "[dbo].[supplier].[first_contacted], "
                . "[dbo].[supplier].[last_contacted], "
                . "[dbo].[supplier].[contact_attempt], "
                . "[dbo].[supplier].[about], "
                . "[dbo].[supplier].[socialmedia_1], "
                . "[dbo].[supplier].[socialmedia_2] "
                . "FROM [dbo].[supplier] "
                . "LEFT JOIN ( "
                . "SELECT [dbo].[product_supplier].[supplier_id], count([dbo].[product_supplier].[product_id]) AS total_products "
                . "FROM [dbo].[product_supplier] "
                . "LEFT JOIN [dbo].[product] ON [dbo].[product_supplier].[product_id]=[dbo].[product].[product_id] "
                . "WHERE ([dbo].[product].[status]='C' OR [dbo].[product].[status]='N') and  [dbo].[product_supplier].status='C'
"
                . "GROUP BY [dbo].[product_supplier].[supplier_id]) t2 "
                . "ON [dbo].[supplier].[supplier_id]=t2.[supplier_id] "
                . "WHERE [dbo].[supplier].[supplier_id]=? ";

        $query = $this->db->query($sql, array($sid));
        
        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

}
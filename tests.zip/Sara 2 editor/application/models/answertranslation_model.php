<?php

Class Answertranslation_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($atId) {

        $atId = intval($atId);
        
        $this->db->select('at.*');
        $this->db->from('AS_answertranslation at');
        $this->db->where('at.id', $atId);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
    }
    
    public function countAllByAnswer($aId) {

        $this->db->select('*');
        $this->db->from('AS_answertranslation at');
        $this->db->where('at.answerid', intval($aId));
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByAnswer($aId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0 || $limit>1000) {
            $limit = 1000;
        }

        if (!in_array($sort, array('id', 'code', 'language', 'description'))) {
            $sort = 'id';
        }
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $this->db->select('*');
        $this->db->from('AS_answertranslation at');
        $this->db->where('at.answerid', intval($aId));  //this is condition    
        $this->db->order_by("at.$sort", strtolower($dir));
        $this->db->limit($limit, $start);
        $query = $this->db->get();
        return $query->result_array();
        
    }
    
    public function findOneByAnswerIdAndCode($atId, $code) {

        $atId = intval($atId);
        
        $this->db->select('at.*');
        $this->db->from('AS_answertranslation at');
        $this->db->where('at.answerid', $atId);
        $this->db->where('at.code', $code);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return FALSE;
        }
        
    }

    function update($atId, $answer_translation) {
        
        $this->db->where('id', intval($atId));
        $query_result = $this->db->update('AS_answertranslation', $answer_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return TRUE;
    }

    function insert($answer_translation) {

        $query_result = $this->db->insert('AS_answertranslation', $answer_translation);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return FALSE;
        }

        return $this->db->insert_id();
    }
    
    function delete($id) {

        $query_result = $this->db->delete('AS_answertranslation', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
}
<?php

Class Imageupload_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function insert($record) {

//        $query_result = $this->db->insert('[sara6].[dbo].[imageupload]', $record);
//        if (!$query_result) {
//            $this->error = $this->db->_error_message();
//            $this->errorno = $this->db->_error_number();
//            return false;
//        }

        return true;
    }

    function delete($id) {

//        $query_result = $this->db->delete('[sara6].[dbo].[imageupload]', array('id' => $id));
//        if (!$query_result) {
//            $this->error = $this->db->_error_message();
//            $this->errorno = $this->db->_error_number();
//            return false;
//        }
        return true;
    }
    
}
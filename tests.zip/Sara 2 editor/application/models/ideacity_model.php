<?php

Class Ideacity_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($iId) {

        $this->db->select('*');
        $this->db->from('AS_ideacity');
        $this->db->where('id', intval($iId));
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }

    public function countAllByIdeaId($iId) {

        $this->db->select('COUNT(ic.id) AS total');
        $this->db->from('AS_ideacity ic');
        $this->db->where('ic.ideaid', intval($iId));

        $query = $this->db->get();
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdeaId($iId, $start, $limit, $sort, $dir) {

        $start = intval($start);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = trim($sort);
        if (!in_array($sort, array('city'))) {
            $sort = 'city';
        }
        $dir = trim($dir);
        if (!in_array($dir, array('DESC', 'ASC'))) {
            $dir = 'ASC';
        }

        $sql = "SELECT ic.[id]
                        ,ic.[ideaid]
                        ,ic.[city]
                        ,ic.[county]
                FROM [" . DB_NAME . "].[dbo].[AS_ideacity] ic WHERE ic.ideaid=".intval($iId);
        $sql.=" ORDER BY ic.[$sort] $dir";
        $sql.= " OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);
        
//        print_r($this->db->last_query());
//        EXIT;
        
        
        return $query->result_array();
    }

    /**
     * returns all idea cities records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findIdeaCities($iId) {

        $sql = "SELECT ic.[city]
                FROM [" . DB_NAME . "].[dbo].[AS_ideacity] ic 
                WHERE ic.ideaid=".intval($iId);
        
        $query = $this->db->query($sql);
        
        $cities=array();
        foreach ($query->result_array() as $record) :
            $cities[]=$record['city'];
        endforeach;
        
        return $cities;
        
    }
    
    
    
    function insert($record) {

        //return $this->db->insert('selfserve_user', $user);

        $query_result = $this->db->insert('AS_ideacity', $record);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function delete($id) {

        $query_result = $this->db->delete('AS_ideacity', array('id' => $id));
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }
        return true;
    }
    
    function update($iId, $record) {
        $this->db->where('id', $iId);
        
        $query_result = $this->db->update('AS_ideacity', $record);
        if(!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
         }
        
        return true;
    }
    
}
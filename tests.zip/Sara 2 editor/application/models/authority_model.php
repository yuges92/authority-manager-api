<?php

Class Authority_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function find($authority_id) {

        if (!$authority_id) {
            return false;
        }

        $this->db->select('a.*');
        $this->db->from('AS_authority a');
        $this->db->where('a.authority_id', $authority_id);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    
    function findByShortName($auth) {

        if (!$auth) {
            return false;
        }

        $this->db->select('a.*');
        $this->db->from('AS_authority a');
        $this->db->where('a.short_name', $auth);
        $this->db->limit(1);

        $query = $this->db->get();

        if ($query->num_rows() == 1) {
            return $query->result()[0];
        } else {
            return false;
        }
    }
    

    public function countAllUnverified() {

        $sql = "SELECT Count(id) AS total
                FROM selfserve_user WHERE supplierId IS NULL OR supplierId=''";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    public function countAll() {

        $sql = "SELECT Count(a.authority_id) AS total
                FROM AS_authority a ";

        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAll($start_param, $limit_param, $sort_param, $dir_param) {

        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }
        $sort = 'authority_id';
        if (in_array($sort_param, array('authority_id', 'authority_type', 'full_name', 'supplier_id'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT a.authority_id
                    ,a.supplier_id
                    ,a.full_name
                    ,a.short_name
                    ,a.authority_type
                    ,a.email
                    ,a.local_authority_url
                    ,a.website
                    ,a.active
                    ,a.always_disclaimer
                    ,a.introduction
                    ,a.disclaimer_text
                    ,a.disclaimer_text_cy
                    ,a.filename
                    ,a.local_authority
                    ,a.retailer_location
               FROM AS_authority a
               ORDER BY a.$sort $dir
               OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";

     //   echo $sql;exit;
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    /**
     * returns all authority ideas records in database.
     * @access public
     * @return array|false the authority ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByIdea($ideaid, $start_param, $limit_param, $sort_param, $dir_param) {

        $ideaid = intval($ideaid);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = 'authority_id';
        if (in_array($sort_param, array('authority_id', 'full_name', 'supplier_id'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT DISTINCT a.authority_id
                               ,a.full_name
                               ,a.supplier_id
                               ,ia.ideaid
                FROM AS_authority a, AS_idea_authority ia
                WHERE a.authority_id=ia.authority_id AND ia.ideaid=$ideaid 
                ORDER BY a.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    /**
     * returns all authority idsgiven an idea records in database.
     * @access public
     * @return array|false the authority ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllIdsByIdea($ideaid) {

        $ideaid = intval($ideaid);
        
        $sql = "SELECT DISTINCT a.authority_id
                FROM AS_authority a, AS_idea_authority ia
                WHERE a.authority_id=ia.authority_id AND ia.ideaid=$ideaid
                ORDER BY a.authority_id";

        $query = $this->db->query($sql);

        $ids = array();
        $i = 0;
        foreach ($query->result_array() as $row) :
            $ids[$i] = $row['authority_id'];
            $i++;
        endforeach;

        return $ids;
    }

    /**
     * returns all authority not linked to ideas records in database.
     * @access public
     * @return array|false the authority ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllNotLinkedtoIdea($ideaid, $start_param, $limit_param, $sort_param, $dir_param) {

        $ideaid = intval($ideaid);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }

        $sort = 'authority_id';
        if (in_array($sort_param, array('authority_id', 'full_name', 'supplier_id'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT a.authority_id
                      ,a.supplier_id
                      ,a.full_name
                FROM AS_authority a
                WHERE a.authority_id NOT IN ( SELECT ia.authority_id
                                                FROM AS_idea_authority ia
                                                WHERE ia.ideaid=$ideaid )
                ORDER BY a.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    
     /**
     * counts all authority disclaimers records in database.
     * @access public
     * @return array|false the total of authority disclaimers records found in database or no records found.
     */
    public function countAllByDisclaimer($disclaimerid) {

        $disclaimerid = intval($disclaimerid);
        
        $sql = "SELECT DISTINCT COUNT(a.authority_id) AS total
                FROM AS_authority a, AS_disclaimer_authority da
                WHERE a.authority_id=da.authority_id AND da.disclaimerid=$disclaimerid";
        
        $query = $this->db->query($sql);
        $result = $query->result_array();
        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
        return $count;
    }
    
    
    /**
     * returns all authority disclaimers records in database.
     * @access public
     * @return array|false the authority ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByDisclaimer($disclaimerid, $start_param, $limit_param, $sort_param, $dir_param) {

        $disclaimerid = intval($disclaimerid);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }
        $sort = 'authority_id';
        if (in_array($sort_param, array('authority_id', 'full_name', 'supplier_id'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT DISTINCT a.authority_id
                               ,a.full_name
                               ,a.supplier_id
                               ,da.disclaimerid
                               ,da.pkey
                FROM AS_authority a, AS_disclaimer_authority da
                WHERE a.authority_id=da.authority_id AND da.disclaimerid=$disclaimerid 
                ORDER BY a.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

    /**
     * returns all authority idsgiven an idea records in database.
     * @access public
     * @return array|false the authority ideas records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllIdsByDisclaimer($disclaimerid) {

        $disclaimerid = intval($disclaimerid);
        
        $sql = "SELECT DISTINCT a.authority_id
                FROM AS_authority a, AS_disclaimer_authority da
                WHERE a.authority_id=da.authority_id AND da.disclaimerid=$disclaimerid
                ORDER BY a.authority_id";

        $query = $this->db->query($sql);

        $ids = array();
        $i = 0;
        foreach ($query->result_array() as $row) :
            $ids[$i] = $row['authority_id'];
            $i++;
        endforeach;

        return $ids;
    }

    /**
     * returns all authority not linked to disclaimers records in database.
     * @access public
     * @return array|false the authority disclaimers records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllNotLinkedtoDisclaimer($disclaimerid, $start_param, $limit_param, $sort_param, $dir_param) {

        $disclaimerid = intval($disclaimerid);
        
        $start = intval($start_param);
        if ($start < 0) {
            $start = 0;
        }
        $limit = intval($limit_param);
        if ($limit < 0) {
            $limit = 1000;
        }
        $sort = 'authority_id';
        if (in_array($sort_param, array('authority_id', 'full_name', 'supplier_id'))) {
            $sort = $sort_param;
        }
        $dir = 'ASC';
        if (in_array($dir_param, array('DESC', 'ASC'))) {
            $dir = $dir_param;
        }

        $sql = "SELECT a.authority_id
                      ,a.supplier_id
                      ,a.full_name
                FROM AS_authority a
                WHERE a.authority_id NOT IN ( SELECT da.authority_id
                                                FROM AS_disclaimer_authority da
                                                WHERE da.disclaimerid=$disclaimerid) 
                ORDER BY a.$sort $dir
                OFFSET $start ROWS FETCH NEXT $limit ROWS ONLY";
        
        $query = $this->db->query($sql);

        return $query->result_array();
    }

//    public function countAllByNameAndType($name, $type) {
//
//        $name = $this->db->escape_like_str($name);
//        $type = $this->db->escape_like_str($type);
//
//        $sql = "SELECT Count(authority_id) AS total
//                FROM AS_authority a WHERE a.title LIKE '$name%' AND a.authority_type='$type'";
//
//        $query = $this->db->query($sql);
//        $result = $query->result_array();
//        $count = !isset($result[0]['total']) ? 0 : intval($result[0]['total']);
//        return $count;
//    }

    /**
     * returns all selfserve users records in database.
     * @access public
     * @return array|false the selfserve users records found in database, FALSE otherwise (i.e.none record found).
     */
    public function findAllByNameAndType($name, $type) {

        $name = $this->db->escape_like_str($name);
        $type = $this->db->escape_like_str($type);

        $sql = "SELECT  a.authority_id
                    ,a.authority_type
                    ,a.title
                    ,a.authority
                    ,a.status
                    ,a.description
                    ,a.group_id
                    ,a.picture
                    ,a.video
                    ,a.created_by
                    ,a.created
                    ,a.verified_by
                    ,a.verified
                    ,a.product_id
                    ,a.user_id
                    ,a.modified
                    ,a.modified_by
               FROM [" . DB_NAME . "].[dbo].[AS_authority] a WHERE a.title LIKE '$name%' AND a.authority_type='$type' 
               ORDER BY a.title ASC";

        $query = $this->db->query($sql);

        return $query->result_array();
    }

    function update($authority_id, $authority) {
        
//        echo '<pre>';
//        print_r($authority);
//        echo '</pre>';
//        exit;
        
        $this->db->where('authority_id', $authority_id);

        $query_result = $this->db->update('AS_authority', $authority);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return true;
    }

    function insert($authority) {
        
                
//        echo '<pre>';
//        print_r($authority);
//        echo '</pre>';
//        exit;
        
        $query_result = $this->db->insert('AS_authority', $authority);
        if (!$query_result) {
            $this->error = $this->db->_error_message();
            $this->errorno = $this->db->_error_number();
            return false;
        }

        return $this->db->insert_id();
    }

//    public function getImagesData() {
//
//        $sql = "SELECT  a.authority_id,a.picture
//               FROM AS_authority a WHERE a.picture IS NOT NULL AND a.picture!=''
//               ORDER BY a.authority_id ASC";
//
//        $query = $this->db->query($sql);
//        return $query->result_array();
//    }

}

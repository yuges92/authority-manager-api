<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Reference extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->model('reference_model', '', TRUE);
        //$this->load->helper('product');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_by = 0;
        $search_key = '';
        $start = 0;
        $limit = 1000;
        $sort = 1;
        $dir = 'ASC';

        $this->form_validation->set_rules('search_by', 'search_by', 'trim|is_natural|less_than[13]|greater_than[-1]');
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|max_length[30]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('search_by')) {
                $search_by = trim($this->input->post('search_by'));
            }

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }

            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $total = $this->reference_model->countAll($search_by, $search_key);
            $references = $this->reference_model->findAll($search_by, $search_key, $start, $limit, $sort, $dir);

            $clean_references = array();
            foreach ($references as $reference) :
                $temp = array();
                $temp = $reference; // hack to avoid json warning 
                $temp['title'] = stripped_of_invalid_utf8_chars_string($reference['title']);
                $temp['author'] = stripped_of_invalid_utf8_chars_string($reference['author']);
                $temp['year'] = stripped_of_invalid_utf8_chars_string($reference['year']);
                $temp['journal'] = stripped_of_invalid_utf8_chars_string($reference['journal']);
                $temp['references_id'] = stripped_of_invalid_utf8_chars_string($reference['references_id']);
                $clean_references[] = $temp;
            endforeach;


            if (!$reference) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['references'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['references'] = $clean_references;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    /**
     * returns all references records by idea in database.
     * @access public
     * @return array|false the reference records by idea found in database, FALSE otherwise (i.e.none record found).
     */
    public function getallbyidea() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        
        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|ideareference_sort_validation');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $this->load->model('reference_model', '', TRUE);
            $total = $this->reference_model->countAllByIdea(
                    $this->input->post('ideaid')
                    );
            
            $ideareferences = $this->reference_model->findAllByIdea(
                    $this->input->post('ideaid'),
                    $this->input->post('start'),
                    $this->input->post('limit'),
                    $this->input->post('sort'),
                    $this->input->post('dir')
                    );
            
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['ideareferences'] = $ideareferences;
           
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    
    
    public function getallbydisclaimer() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        
        echo 'sdsdsd';exit;
        
        $this->form_validation->set_rules('disclaimerid', 'disclaimerid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_numeric|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $this->load->model('reference_model', '', TRUE);
            $total = $this->reference_model->countAllByDisclaimer(
                    $this->input->post('disclaimerid')
                    );
            
            $disclaimerreferences = $this->reference_model->findAllByDisclaimer(
                    $this->input->post('disclaimerid'),
                    $this->input->post('start'),
                    $this->input->post('limit'),
                    $this->input->post('sort'),
                    $this->input->post('dir')
                    );
            
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['disclaimerreferences'] = $disclaimerreferences;
            
            
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    
    
    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $references_id = $this->input->post('references_id');
        if ($references_id) {
            $reference = $this->reference_model->find($references_id);
            if ($reference) {
                $this->data['status'] = 'SUCCESS';
                $this->data['reference'] = $reference;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Reference Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid Reference id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function addnew() {
        echo 'addnew';
    }

    private function _compareImages($str1, $str2) {

        $str1arr = explode(',', $str1);
        $str2arr = explode(',', $str2);
        if (!empty($str1arr) && !empty($str2arr)) {
            sort($str1arr);
            sort($str2arr);
            return ($str1arr == $str2arr);
        } else {
            return $str1 === $str2;
        }
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }
        //  if ($this->input->post('advice_id')) {
        if ($this->form_validation->run('edit_reference')) {

            $references_id = $this->input->post('references_id');
            $reference = $this->reference_model->find($references_id);
            if ($reference) {

                // Setting values for reference table columns
                $rrecord = array();
                $rrecord['author'] = $this->input->post('author');
                $rrecord['title'] = $this->input->post('title');
                $rrecord['journal'] = $this->input->post('journal');
                $rrecord['edition'] = $this->input->post('edition');
                $rrecord['vol_and_no'] = $this->input->post('vol_and_no');
                $rrecord['chapter'] = $this->input->post('chapter');
                $rrecord['pages'] = $this->input->post('pages');
                $rrecord['publisher'] = $this->input->post('publisher');
                $rrecord['place'] = $this->input->post('place');
                $rrecord['url'] = $this->input->post('url');
                $rrecord['abstract'] = $this->input->post('abstract');
                $rrecord['isbn_doi'] = $this->input->post('isbn_doi');
                $rrecord['year'] = $this->input->post('year');
                $last_accessed = strtotime($this->input->post('last_accessed'));
                $rrecord['last_accessed'] = date(DATE_FORMAT, $last_accessed);
                
                //$rrecord['last_accessed'] = $this->input->post('last_accessed');
                
                $rrecord['evidence_type'] = $this->input->post('evidence_type');
                $rrecord['type'] = $this->input->post('type');
                $rrecord['non_english_title'] = $this->input->post('non_english_title');
                $rrecord['status'] = $this->input->post('status');
                //$rrecord['isreview_date'] = $this->input->post('isreview_date');
                $isreview_date = strtotime($this->input->post('isreview_date'));
                $rrecord['isreview_date'] = date(DATE_FORMAT, $isreview_date);
                $rrecord['created'] = date(DATE_FORMAT, time());
                $rrecord['created_by'] = $_SESSION["meeuname"];
                $rrecord['modified'] = date(DATE_FORMAT, time());
                $rrecord['modified_by'] = $_SESSION["meeuname"];

                $updated = $this->reference_model->update($references_id, $rrecord);
                if($updated) {
                    $this->data['success'] = TRUE;
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save reference to database.";
                }
                
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Reference not found";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        //  }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_reference')) {

            // Setting values for selfserve_user table columns
            $rrecord = array();
            $rrecord['author'] = $this->input->post('author');
            $rrecord['title'] = $this->input->post('title');
            $rrecord['journal'] = $this->input->post('journal');
            $rrecord['edition'] = $this->input->post('edition');
            $rrecord['vol_and_no'] = $this->input->post('vol_and_no');
            $rrecord['chapter'] = $this->input->post('chapter');
            $rrecord['pages'] = $this->input->post('pages');
            $rrecord['publisher'] = $this->input->post('publisher');
            $rrecord['place'] = $this->input->post('place');
            $rrecord['url'] = $this->input->post('url');
            $rrecord['abstract'] = $this->input->post('abstract');
            $rrecord['isbn_doi'] = $this->input->post('isbn_doi');
            $rrecord['year'] = $this->input->post('year');
            $last_accessed = strtotime($this->input->post('last_accessed'));
            $rrecord['last_accessed'] = date(DATE_FORMAT, $last_accessed);
            
            //$rrecord['last_accessed'] = $this->input->post('last_accessed');
            $rrecord['evidence_type'] = $this->input->post('evidence_type');
            $rrecord['type'] = $this->input->post('type');
            $rrecord['non_english_title'] = $this->input->post('non_english_title');
            $rrecord['status'] = $this->input->post('status');
            
            //$rrecord['isreview_date'] = $this->input->post('isreview_date');
            $isreview_date = strtotime($this->input->post('isreview_date'));
            $rrecord['isreview_date'] = date(DATE_FORMAT, $isreview_date);
            
            $rrecord['created'] = date(DATE_FORMAT, time());
            $rrecord['created_by'] = $_SESSION["meeuname"];
            $rrecord['modified'] = date(DATE_FORMAT, time());
            $rrecord['modified_by'] = $_SESSION["meeuname"];

            $last_id = $this->reference_model->insert($rrecord);
            if (!$last_id) {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Could not save reference to database.";
            } else {
                $this->data['success'] = TRUE;
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function referencelinklist() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        $eId = 0;
        $start = 0;
        $limit = 1000;
        $sort = 1;
        $dir = 'ASC';

        $this->form_validation->set_rules('references_id', 'advice_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|xss_cleam|callback_reference_link_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run() /* && $this->model_name->method() */) {

            if ($this->input->post('references_id')) {
                $rId = trim($this->input->post('references_id'));
            }


            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $this->load->model('reference_link_model', '', TRUE);
            $total = $this->reference_link_model->countAllByReferenceId($rId);
            $reference_links = $this->reference_link_model->findAllByReferenceId($rId, $start, $limit, $sort, $dir);
            if (!$reference_links) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['referencelinks'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['referencelinks'] = $reference_links;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function savereferencelink() {

        $this->form_validation->set_rules('references_id', 'references_id', 'trim|numeric|is_natural|less_than[100000]');
        $this->form_validation->set_rules('lme_groupid', 'lme_groupid', 'trim|numeric|is_natural|less_than[100000]');
        $this->form_validation->set_rules('lme_scenarion_id', 'lme_scenarion_id', 'trim|numeric|is_natural|less_than[100000]');
        $this->form_validation->set_rules('sara_ideaid', 'sara_ideaid', 'trim|numeric|is_natural|less_than[100000]');
        $this->form_validation->set_rules('sara_disclaimerid', 'sara_disclaimerid', 'trim|numeric|is_natural|less_than[100000]');
        $this->form_validation->set_rules('dlf_class_id', 'dlf_class_id', 'trim|class_id_validation');
        $this->form_validation->set_rules('reable_advice_id', 'reable_advice_id', 'trim|numeric|is_natural|less_than[100000]');
        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            $rlrecord = array();
            // Setting values for selfserve_user table columns
            $rlrecord['references_id'] = $this->input->post('references_id');
            $rlrecord['lme_groupid'] = $this->input->post('lme_groupid');
            $rlrecord['lme_scenarion_id'] = $this->input->post('lme_scenarion_id');
            $rlrecord['sara_ideaid'] = $this->input->post('sara_ideaid');
            $rlrecord['sara_disclaimerid'] = $this->input->post('sara_disclaimerid');
            $rlrecord['dlf_class_id'] = $this->input->post('dlf_class_id');
            $rlrecord['reable_advice_id'] = $this->input->post('reable_advice_id');
            $id = $this->input->post('id') ? $this->input->post('id') : 0;
            $this->load->model('reference_link_model', '', TRUE);
            $referencelink = $this->reference_link_model->find($id);
            if ($referencelink) {
                $this->reference_link_model->update($id, $rlrecord);
                $this->data['status'] = 'SUCCESS';
            } else {
                $this->reference_link_model->insert($rlrecord);
                $this->data['status'] = 'SUCCESS';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    
    public function deletereferencelink() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('reference_link_model', '', TRUE);

                $id = $this->input->post('id');
                $reference_link = $this->reference_link_model->find($id);
                if ($reference_link) {
                    if (!$this->reference_link_model->delete($id)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Reference Link failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Reference Link not found';
                }
            } else {
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Invalid Data submitted';
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    public function findjournalsbyname() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_key = '';
        
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }
            
            $journals = $this->reference_model->findAllJournalsByName($search_key);
            if (!$journals) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['journals'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($journals);
                $this->data['journals'] = $journals;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    
    public function reference_link_sort_check($str) {
        if (!in_array($str, array('id', 'references_id', 'lme_groupid', 'lme_scenarion_id', 'sara_ideaid', 'sara_disclaimerid', 'dlf_class_id', 'reable_advice_id'))) {
            $this->form_validation->set_message('equipment_technique_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }
    
    

    public function sort_check($str) {
        if (!in_array($str, array('references_id', 'title', 'author', 'year', 'journal'))) {
            $this->form_validation->set_message('sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

}

/* End of file reference.php */
/* Location: ./application/controllers/reference.php */    
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Disclaimer extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('disclaimer_model', '', TRUE);
        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_numeric|max_length[7]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_numeric|max_length[1000]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->disclaimer_model->countAll();

            $disclaimers = $this->disclaimer_model->findAll(
                    $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

//            array_walk_recursive($disclaimers, function(&$val) {
//                $val = stripped_of_invalid_utf8_chars_string($val);
//            });

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['disclaimers'] = $disclaimers;
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $disclaimerid = $this->input->post('disclaimerid');
        if ($disclaimerid) {
            $disclaimer = $this->disclaimer_model->find($disclaimerid);
            if ($disclaimer) {
                $this->data['status'] = 'SUCCESS';
                $this->data['disclaimer'] = $disclaimer;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Disclaimer not found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid disclaimer id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('save_disclaimer')) {

            $date = date(DATE_FORMAT, time());

            // Setting values for idea table columns
            $drecord = array();
            $drecord['title'] = $this->input->post('title');
            $drecord['disclaimer'] = $this->input->post('disclaimer');
            $drecord['modified'] = $date;
            $drecord['modified_by'] = $_SESSION["seuname"];
            //$drecord['filename'] = $this->input->post('filename');

            $disclaimerid = $this->input->post('disclaimerid');
            if ($disclaimerid > 0) { // edit advice
                $disclaimer = $this->disclaimer_model->find($disclaimerid);
                if ($disclaimer) {
                    $this->load->helper('image');
                    $save_result = save_image('disclaimer', $disclaimer->disclaimerid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                        $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: " . $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_DISCLAIMERS_PICS_DIR . '/' . $save_result['filename'])) {
                            $drecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->disclaimer_model->update($disclaimer->disclaimerid, $drecord);
                        if ($updated) {

                            $this->data['success'] = TRUE;
                        } else {
                            $this->data['failure'] = TRUE;
                            $this->data['responseText'] = "Could not save disclaimer information!";
                        }
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Disclaimer not found!";
                }
            } else { // new advice
                $drecord['created'] = $date;
                $drecord['created_by'] = $_SESSION["seuname"];
                $newdisclaimerid = $this->disclaimer_model->insert($drecord);
                if ($newdisclaimerid) {
                    $this->load->helper('image');
                    $save_result = save_image('disclaimer', $newdisclaimerid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                        $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: " . $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_DISCLAIMERS_PICS_DIR . '/' . $save_result['filename'])) {
                            $drecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->disclaimer_model->update($newdisclaimerid, $drecord);

                        $this->data['success'] = TRUE;
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save disclaimer information!";
                }
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

//    private function _handleImageUpload($ifile) {
//        $this->load->library('upload');
//        $this->config->load('file_upload', TRUE);
//        $section_picture_settings = $this->config->item('section_picture', 'file_upload');
//        $section_picture_settings['file_name'] = $ifile;
//        $upload_result = array('error' => 0);
//        if ($_FILES['section_picture']['error'] === 0) {
//            $this->upload->initialize($section_picture_settings);
//            if (!$this->upload->do_upload('section_picture')) {
//                $upload_result = array('error' => 1, 'message' => $this->upload->display_errors());
//            }
//        } else {
//            $upload_result = array('error' => 1, 'message' => $_FILES['section_picture']['error']);
//        }
//
//        return $upload_result;
//    }

    public function deletedisclaimerauthority() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('disclaimerauthority_model', '', TRUE);

                $id = $this->input->post('id');
                $disclaimerauthorities = $this->disclaimerauthority_model->find($id);
                if ($disclaimerauthorities) {
                    if (!$this->disclaimerauthority_model->delete($id)) {
                        $this->data['success'] = FALSE;
                        $this->data['message'] = 'Delete Disclaimer Authority failed';
                    } else {
                        $this->data['success'] = TRUE;
                    }
                } else {
                    $this->data['success'] = FALSE;
                    $this->data['message'] = 'Disclaimer Authority not found';
                }
            } else {
                $this->data['success'] = FALSE;
                $this->data['message'] = 'Invalid Data submitted';
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function savedisclaimerauthorities() {

        $this->form_validation->set_rules('disclaimerid', 'disclaimerid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        //$this->form_validation->set_rules('authority_ids[]', 'authority_ids[]', 'required');
        if ($this->form_validation->run()) {

            $this->load->model('disclaimerauthority_model', '', TRUE);
            $this->load->model('authority_model', '', TRUE);
            $db_authority_ids = $this->authority_model->findAllIdsByDisclaimer($this->input->post('disclaimerid'));

            $authority_ids = $this->input->post('authority_ids[]');
            if (is_array($authority_ids) && !empty($authority_ids)) {
                foreach ($authority_ids as $authority_id) :
                    if (!in_array($authority_id, $db_authority_ids)) {
                        $darecord = array();
                        $darecord['disclaimerid'] = $this->input->post('disclaimerid');
                        $darecord['authority_id'] = $authority_id;

                        $this->disclaimerauthority_model->insert($darecord);
                    }
                endforeach;
            }
            $this->data['status'] = 'SUCCESS';
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');

        //echo json_encode($this->input->post());exit;

        echo json_encode($this->data);
        exit;
    }

//    public function authority_type_check($str) {
//        $authority_type_allowed = array('BASIC', 'COMPLEX', 'COMMERCIAL', 'BASIC1');
//        if (!in_array($str, $authority_type_allowed)) {
//            $this->form_validation->set_message('authority_type_check', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }
//
//    public function idea_sort_validation($str) {
//        if (!in_array($str, array('ideaid', 'title'))) {
//            $this->form_validation->set_message('idea_sort_validation', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }
//
//    public function authoritytextreplace_sort_check($str) {
//        if (!in_array($str, array('id', 'authority_id', 'look_for', 'action', 'replace_with'))) {
//            $this->form_validation->set_message('authoritytextreplace_sort_check', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }

//    public function authoritycity_sort_check($str) {
//        if (!in_array($str, array('id', 'city'))) {
//            $this->form_validation->set_message('authoritycity_sort_check', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }

//    public function ideareference_sort_check($str) {
//        if (!in_array($str, array('id', 'title', 'author', 'year'))) {
//            $this->form_validation->set_message('ideareference_sort_check', 'The %s field is not valid');
//            return FALSE;
//        } else {
//            return TRUE;
//        }
//    }

//    private function _save_image($settings) {
//        $upload_result = array('error' => 0);
//        if ($_FILES['disclaimer_picture']['error'] === 0) {
//            $this->load->library('upload');
//            $this->config->load('file_upload', TRUE);
//            $upload_settings = $this->config->item('disclaimer_picture', 'file_upload');
//            $upload_settings['file_name'] = $settings['file_name'];
//            if (!file_exists($upload_settings['upload_path'])) { // create directory if it does not exist
//                mkdir($upload_settings['upload_path'], 0777, true);
//            }
//            $this->upload->initialize($upload_settings);
//            if (!$this->upload->do_upload('disclaimer_picture')) {
//                $upload_result = array('error' => 1, 'message' => strip_tags($this->upload->display_errors()));
//            }
//        } else {
//            $upload_result = array('error' => 1, 'message' => $_FILES['disclaimer_picture']['error']);
//        }
//
//        return $upload_result;
//    }

}

/* End of file authority.php */
/* Location: ./application/controllers/authority.php */    
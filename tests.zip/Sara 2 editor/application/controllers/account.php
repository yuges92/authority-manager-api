<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Account extends MY_Controller {

    function __construct() {
        parent::__construct();

        $isAdmin = isset($_SESSION["seuname"]) && $_SESSION["seacctype"] == 'ADMINISTRATOR';
        if (!$isAdmin) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }
        $this->load->model('account2_model', '', TRUE);
        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->account2_model->countAll();
            $accounts = $this->account2_model->findAll(
                    $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            array_walk_recursive($accounts, function(&$val) {
                $val = stripped_of_invalid_utf8_chars_string($val);
            });

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['accounts'] = $accounts;
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('account_details')) {

            $account = $this->account2_model->find(
                    $this->input->post('accno')
            );

            if ($account) {
                $this->data['status'] = 'SUCCESS';
                $this->data['account'] = $account;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Account Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('save_account')) {

            $date = date(DATE_FORMAT, time());

            // Setting values for answer table columns
            $arecord = array();
            $arecord['username'] = $this->input->post('username');
            $arecord['password'] = $this->input->post('password');
            $arecord['read_permission'] = $this->input->post('read_permission') === 'on' ? 'Y' : 'N';
            $arecord['write_permission'] = $this->input->post('write_permission') === 'on' ? 'Y' : 'N';
            $arecord['edit_permission'] = $this->input->post('edit_permission') === 'on' ? 'Y' : 'N';
            $arecord['delete_permission'] = $this->input->post('delete_permission') === 'on' ? 'Y' : 'N';
            $arecord['created'] = $this->input->post('created');
            $arecord['company_name'] = $this->input->post('company_name');
            $arecord['active'] = $this->input->post('active') === 'on' ? 1 : 0;

            $accno = $this->input->post('accno');
            if ($accno > 0) { // edit advice
                $account = $this->account2_model->find($accno);
                if ($account) {
                    $arecord['created'] = $date;
                    $updated = $this->account2_model->update($accno, $arecord);
                    if (!$updated) {
                        $this->data['failure'] = TRUE;
                        $this->data['responseText'] = "Could not save account information!";
                    } else {
                        $this->data['success'] = TRUE;
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Account not found!";
                }
            } else { // new advice
                $arecord['created'] = $date;
                //$arecord['created_by'] = $_SESSION["seuname"];
                $newaccno = $this->account2_model->insert($arecord);
                if ($newaccno) {
                    $this->data['success'] = TRUE;
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save account information!";
                }
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

}

/* End of file answer.php */
/* Location: ./application/controllers/answer.php */    
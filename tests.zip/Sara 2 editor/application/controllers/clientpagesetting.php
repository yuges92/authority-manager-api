<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class ClientPageSetting extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('clientpagesetting_model', '', TRUE);
    }

    public function getallbyauthority() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|clientpagesetting_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->clientpagesetting_model->countAllByAuthority(
                    $this->input->post('authority_id')
            );

            $clientpagesettings = $this->clientpagesetting_model->findAllByAuthority(
                    $this->input->post('authority_id'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['clientpagesettings'] = $clientpagesettings;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('client_page_setting_details')) {

            $data = array();

            $client_page_setting = $this->clientpagesetting_model->find(
                    $this->input->post('id')
            );

            if ($client_page_setting) {
                $data['success'] = TRUE;
                $data['client_page_setting'] = $client_page_setting;
            } else {
                $data['error'] = 'Client Page Setting not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_client_page_setting')) {

            $data = array();

            $id = $this->input->post('id');
            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $cpstrecord = array();
            $cpstrecord['authority_id'] = $this->input->post('authority_id');
            $cpstrecord['page'] = $this->input->post('page');
            $cpstrecord['block_type'] = $this->input->post('block_type');
            $cpstrecord['block_setting_name'] = $this->input->post('block_setting_name');
            $cpstrecord['block_setting_value'] = $this->input->post('block_setting_value');
            $cpstrecord['created'] = $current_date;
            $cpstrecord['created_by'] = $_SESSION["seuname"];
            $cpstrecord['modified'] = $current_date;
            $cpstrecord['modified_by'] = $_SESSION["seuname"];
            
            $client_page_setting = $this->clientpagesetting_model->findOneBySetting($cpstrecord);
            if ($client_page_setting) {

                $client_page_setting_id = $this->clientpagesetting_model->update($client_page_setting->id, $cpstrecord);
                if ($client_page_setting_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = CLIENT_PAGE_SETTING_COULD_NOT_SAVE_TO_DATABASE;
                }
              
            } else {
                $data['error'] = CLIENT_PAGE_SETTING_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_client_page_setting')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $cpstrecord = array();
            $cpstrecord['authority_id'] = $this->input->post('authority_id');
            $cpstrecord['page'] = $this->input->post('page');
            $cpstrecord['block_type'] = $this->input->post('block_type');
            $cpstrecord['block_setting_name'] = $this->input->post('block_setting_name');
            $cpstrecord['block_setting_value'] = $this->input->post('block_setting_value');
            $cpstrecord['created'] = $current_date;
            $cpstrecord['created_by'] = $_SESSION["seuname"];
            $cpstrecord['modified'] = $current_date;
            $cpstrecord['modified_by'] = $_SESSION["seuname"];

            $db_client_page_setting = $this->clientpagesetting_model->findOneBySetting($cpstrecord);
            if (!$db_client_page_setting) {
                $client_page_setting_id = $this->clientpagesetting_model->insert($cpstrecord);
                if ($client_page_setting_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = CLIENT_PAGE_SETTING_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = CLIENT_PAGE_SETTING_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('clientpagesetting_model', '', TRUE);
                $id = $this->input->post('id');
                $answer_translation = $this->clientpagesetting_model->find($id);
                if ($answer_translation) {
                    if (!$this->clientpagesetting_model->delete($id)) {
                        $data['error'] = 'Delete Answer Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Answer Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file clientpagesetting.php */
/* Location: ./application/controllers/clientpagesetting.php */    
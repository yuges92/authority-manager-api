<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class PageTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('pagetranslation_model', '', TRUE);
    }

    public function getallbypage() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('pageid', 'pageid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|pagetranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->pagetranslation_model->countAllByPage(
                    $this->input->post('pageid')
            );

            $pagetranslations = $this->pagetranslation_model->findAllByPage(
                    $this->input->post('pageid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['pagetranslations'] = $pagetranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('page_translation_details')) {

            $data = array();

            $page_translation = $this->pagetranslation_model->find(
                    $this->input->post('id')
            );

            if ($page_translation) {
                $data['success'] = TRUE;
                $data['page_translation'] = $page_translation;
            } else {
                $data['error'] = 'Page Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_page_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $page_translation = $this->pagetranslation_model->find($id);
            if ($page_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $ptrecord = array();
                $ptrecord['title'] = $this->input->post('title');
                $ptrecord['body_text'] = $this->input->post('body_text');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $ptrecord['code'] = isset($language) ? $this->input->post('code') : '';
                $ptrecord['language'] = isset($language) ? $language : '';
                $ptrecord['created'] = $current_date;
                $ptrecord['created_by'] = $_SESSION["seuname"];
                $ptrecord['modified'] = $current_date;
                $ptrecord['modified_by'] = $_SESSION["seuname"];

                $db_page_translation = $this->pagetranslation_model->find($page_translation->id);
                
//                echo '<pre>';
//                print_r($db_page_translation);
//                echo '</pre>';exit;
//                
//                echo '<pre>';
//                print_r($disclaimer_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_page_translation->id==$page_translation->id) {
                    $page_translation_id = $this->pagetranslation_model->update($page_translation->id, $ptrecord);
                    if ($page_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_page_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $ptrecord = array();
            $ptrecord['pageid'] = $this->input->post('pageid');
            $ptrecord['title'] = $this->input->post('title');
            $ptrecord['body_text'] = $this->input->post('body_text');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $ptrecord['code'] = isset($language) ? $this->input->post('code') : '';
            $ptrecord['language'] = isset($language) ? $language : '';
            $ptrecord['created'] = $current_date;
            $ptrecord['created_by'] = $_SESSION["seuname"];
            $ptrecord['modified'] = $current_date;
            $ptrecord['modified_by'] = $_SESSION["seuname"];

            $db_page_translation = $this->pagetranslation_model->findOneByPageIdAndCode($ptrecord['pageid'], $ptrecord['code']);
            if (!$db_page_translation) {
                $page_translation_id = $this->pagetranslation_model->insert($ptrecord);
                if ($page_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('pagetranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $page_translation = $this->pagetranslation_model->find($id);
                if ($page_translation) {
                    if (!$this->pagetranslation_model->delete($id)) {
                        $data['error'] = 'Delete Page Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Page Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file pagetranslation.php */
/* Location: ./application/controllers/pagetranslation.php */    
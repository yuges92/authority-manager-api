<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SectionTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('sectiontranslation_model', '', TRUE);
    }

    public function getallbysection() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('sectionid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|grouptranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->sectiontranslation_model->countAllBySection(
                    $this->input->post('sectionid')
            );

            $sectiontranslations = $this->sectiontranslation_model->findAllBySection(
                    $this->input->post('sectionid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['sectiontranslations'] = $sectiontranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('section_translation_details')) {

            $data = array();

            $section_translation = $this->sectiontranslation_model->find(
                    $this->input->post('id')
            );

            if ($section_translation) {
                $data['success'] = TRUE;
                $data['section_translation'] = $section_translation;
            } else {
                $data['error'] = 'Section Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_section_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $section_translation = $this->sectiontranslation_model->find($id);
            if ($section_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $gtrecord = array();
                $strecord['sectionid'] = $this->input->post('sectionid');
                $strecord['name'] = $this->input->post('name');
                $strecord['description'] = $this->input->post('description');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $strecord['code'] = isset($language) ? $this->input->post('code') : '';
                $strecord['language'] = isset($language) ? $language : '';
                $strecord['created'] = $current_date;
                $strecord['created_by'] = $_SESSION["seuname"];
                $strecord['modified'] = $current_date;
                $strecord['modified_by'] = $_SESSION["seuname"];

                $db_sectioon_translation = $this->sectiontranslation_model->findOneBySectionIdAndCode($strecord['sectionid'], $strecord['code']);
                
//                echo '<pre>';
//                print_r($db_group_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($group_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_sectioon_translation->id==$section_translation->id) {
                    $section_translation_id = $this->sectiontranslation_model->update($section_translation->id, $strecord);
                    if ($section_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_section_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $strecord = array();
            $strecord['sectionid'] = $this->input->post('sectionid');
            $strecord['name'] = $this->input->post('name');
            $strecord['description'] = $this->input->post('description');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $strecord['code'] = isset($language) ? $this->input->post('code') : '';
            $strecord['language'] = isset($language) ? $language : '';
            $strecord['created'] = $current_date;
            $strecord['created_by'] = $_SESSION["seuname"];
            $strecord['modified'] = $current_date;
            $strecord['modified_by'] = $_SESSION["seuname"];

            $db_section_translation = $this->sectiontranslation_model->findOneBySectionIdAndCode($strecord['sectionid'], $strecord['code']);
            if (!$db_section_translation) {
                $section_translation_id = $this->sectiontranslation_model->insert($strecord);
                if ($section_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('sectiontranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $section_translation = $this->sectiontranslation_model->find($id);
                if ($section_translation) {
                    if (!$this->sectiontranslation_model->delete($id)) {
                        $data['error'] = 'Delete Section Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Section Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file sectiontranslation.php */
/* Location: ./application/controllers/sectiontranslation.php */    
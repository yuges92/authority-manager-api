<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Editor extends MY_Controller {

    function __construct() {
        parent::__construct();
    }
    
    public function index()
	{
		$this->load->view('editor');
	}
	
	public function home(){
		$this->load->view('editor');
	}
	
	public function config(){
//		$this->load->library("applicationbi");
//
//		$this->response(true,array(
//			"dock"		=> "top",
//			"user"		=> $this->getUser(),
//			"config"	=> array(
//				"wallpaper"	=> "resources/wallpapers/blue2.jpg"
//			),
//			"applications"	=> $this->applicationbi->getApplications($this->getUser())
//		));
    }

}

/* End of file editor.php */
/* Location: ./application/controllers/editor.php */    
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');


class SelfServeUser extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["meeuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('account_model', '', TRUE);
        $user = $this->account_model->findByUsername($_SESSION["meeuname"]);
        if ($user <= 0 || $user['type'] !== 'administrator') {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('selfserveuser_model', '', TRUE);
        $this->load->model('supplier_model', '', TRUE);
        $this->load->library('email');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_key = '';
        $start = 0;
        $limit = 1000;
        $sort = 'createdAt';
        $dir = 'ASC';

        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[51]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
        
        // if validation was successful with no errors
        if ($this->form_validation->run() /* && $this->model_name->method() */) {

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }


            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }


            $total = $this->selfserveuser_model->countAll($search_key);
            $users = $this->selfserveuser_model->findAll($search_key, $start, $limit, $sort, $dir);
            if (!$users) {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Users Not Found!';
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['users'] = $users;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function unverified() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $start = 0;
        $limit = 1000;
        $sort = 'createdAt';
        $dir = 'ASC';

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $total = $this->selfserveuser_model->countAllUnverified();
            $users = $this->selfserveuser_model->findAllUnverified($start, $limit, $sort, $dir);
            if (!$users) {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Users Not Found!';
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['users'] = $users;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $uid = $this->input->post('uid');
        if ($uid) {
            $user = $this->selfserveuser_model->find($uid);
            if ($user) {
                $this->data['status'] = 'SUCCESS';
                $this->data['user'] = $user;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'User Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid User id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function save() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('save_selfserve_user')) {

            $uid = $this->input->post('uid');
            $user = $this->selfserveuser_model->find($uid);
            if ($user) {

                // Setting values for selfserve_user table columns
                $surecord = array();
                $surecord['username'] = $this->input->post('username');
                $surecord['firstname'] = $this->input->post('firstname');
                $surecord['lastname'] = $this->input->post('lastname');
                $surecord['company'] = $this->input->post('company');
                $surecord['supplierId'] = $this->input->post('supplierId');
                $surecord['phone'] = $this->input->post('phone');
                $surecord['createdAt'] = date(DATE_FORMAT, strtotime($user->createdAt));
                $surecord['updatedAt'] = date(DATE_FORMAT, time());
                $surecord['updatedBy'] = $_SESSION["meeuname"];
                $surecord['active'] = $this->input->post('active');

                $this->selfserveuser_model->update($uid, $surecord);

                $surecord['id'] = $uid;
                $this->data['status'] = 'SUCCESS';
                $this->data['user'] = $surecord;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'User Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    
    public function verify() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('uid', 'uid', 'trim|required|is_natural_no_zero|less_than[50000]');
        $this->form_validation->set_rules('sid', 'sid', 'trim|required|supplier_id_validation');
        
        if ($this->form_validation->run()) {
            
            $uid = $this->input->post('uid');
            $user = $this->selfserveuser_model->find($uid);
            if ($user) {

                $sid = $this->input->post('sid');
                $supplier = $this->supplier_model->find($sid);
                if(!$supplier) {
                    $this->output->set_status_header('400'); //Triggers the jQuery error callback
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Supplier Not Found!';
                } else {
                    // Setting values for selfserve_user table columns
                    
                    $data['firstname'] = $user->firstname;
                    $data['lastname'] = $user->lastname;
                    //$message = $this->load->view('pages/selfserve_account_verified_email_template', $data, true);
                    //$this->email->message($message);
                    
                    $surecord = array();
                    $surecord['company'] = $supplier->supplier_name;
                    $surecord['supplierId'] = $supplier->supplier_id;
                    $surecord['active'] = 1;
                    $updateResult = $this->selfserveuser_model->update($uid, $surecord);
                    if($updateResult === TRUE) {
                        // send email to user
                        //$this->email->send();
                        $this->_send_mail( $user->username, 'DLF SelfServe System - User Registration', 'account_verified', $data);
                    }
                    
                    $this->data['status'] = 'SUCCESS';
                    
                                        // Setting values for selfserve_user table columns
//                    $surecord = array();
//                    $surecord['company'] = $supplier->supplier_name;
//                    $surecord['supplierId'] = $supplier->supplier_id;
//                    $surecord['active'] = 1;
//
//                    $this->selfserveuser_model->update($uid, $surecord);
//                    
//                    // send email to user
//                    $this->email->from( $this->config->item('data_services_email_address') , 'DLF Data Team');
//                    $this->email->to( $user->username );
//                    $this->email->subject('DLF SelfServe System - User Registration');
//                    $data['firstname'] = $user->firstname;
//                    $data['lastname'] = $user->lastname;
//                    $message = $this->load->view('pages/selfserve_account_verified_email_template', $data, true);
//                    $this->email->message($message);
//                    $this->email->send();
                    
                    
                }
                
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'User Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    
    public function active_check($str) {
        if ($str != '0' && $str != '1') {
            $this->form_validation->set_message('active_check', 'The %s field can not be the word "test"');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function sort_check($str) {
        if (!in_array($str, array('createdAt', 'company', 'username'))) {
            $this->form_validation->set_message('active_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function dir_check($str) {
        if (!in_array($str, array('DESC', 'ASC'))) {
            $this->form_validation->set_message('active_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    private function _send_mail( $to, $subject, $message, $data) {
        $this->load->library( 'email' );
        $this->email->from( $this->config->item('dlf_no_reply_email_address'), 'DLF SelfServe System' );
        $this->email->to( $to );
        $this->email->subject( $subject );
        $this->email->message( $this->load->view( 'pages/emails/'.$message, $data, true ) );
        $this->email->send();
    }
    
}

/* End of file selserveuser.php */
/* Location: ./application/controllers/selfserveuser.php */    
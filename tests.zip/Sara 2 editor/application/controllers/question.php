<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Question extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('question_model', '', TRUE);
    }

    public function getallbysection() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('sectionid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|question_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->question_model->countAllBySection(
                    $this->input->post('sectionid')
            );

            $questions = $this->question_model->findAllBySection(
                    $this->input->post('sectionid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->load->model('answer_model', '', TRUE);
            foreach ($questions as &$question) :
                $answers_info = $this->answer_model->findAllByQuestion(
                    $question['questionid']
                );
                $question['answersdescription']='';
                foreach ($answers_info as $answer_info) :
                    $question['answersdescription'] .= "<u>".$answer_info['description']."</u>:  ".$answer_info['nextquestionid'].":  ".$answer_info['sadescription']."<br />";
                endforeach;
                
                if(!isset($question['internalnotes'])) {
                    $question['internalnotes'] = '';
                }
                
            endforeach;
            
//            echo '<pre>';
//            print_r($questions);
//            echo '<pre>';exit;
            
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['questions'] = $questions;
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('question_details')) {

            $question = $this->question_model->find(
                    $this->input->post('questionid')
            );

            if ($question) {
                $this->data['status'] = 'SUCCESS';
                $this->data['question'] = $question;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Question Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        $data = array();
        if ($this->form_validation->run('edit_question')) {

            $questionid = $this->input->post('questionid');
            $question = $this->question_model->find($questionid);
            if ($question) {

                // Setting values for selfserve_user table columns
                $qrecord = array();
                $qrecord['sadescription'] = $this->input->post('sadescription');
                $qrecord['explanation'] = $this->input->post('explanation');
                $qrecord['internalnotes'] = $this->input->post('internalnotes');
                $qrecord['status'] = $this->input->post('status');
                $qrecord['order'] = $this->input->post('order');
                $qrecord['explanation'] = $this->input->post('internalnotes');
                $qrecord['samplequestion'] = $this->input->post('samplequestion') === 'on' ? 'Y' : 'N';

                $this->load->helper('image');
                $save_result = save_image('question', $question->questionid . '.jpg');
                if (isset($save_result['error'])) {
                    $data['error'] = "Could not save image filename to database: " . $save_result['error'];
                } else {
                    if (isset($save_result['filename']) && file_exists(SARA_QUESTIONS_PICS_DIR . '/' . $save_result['filename'])) {
                        $qrecord['filename'] = $save_result['filename'];
                    }
                    $updated = $this->question_model->update($question->questionid, $qrecord);
                    if ($updated) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = "Could not save question information!";
                    }
                }
            } else {
                $data['error'] = "Question not found";
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }
        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_question')) {

            // Setting values for selfserve_user table columns
            $qrecord = array();
            $qrecord['sectionid'] = $this->input->post('sectionid');
            $qrecord['sadescription'] = $this->input->post('sadescription');
            $qrecord['explanation'] = $this->input->post('explanation');
            $qrecord['internalnotes'] = $this->input->post('internalnotes');
            $qrecord['status'] = $this->input->post('status');
            $qrecord['order'] = $this->input->post('order');
            $qrecord['explanation'] = $this->input->post('internalnotes');
            $qrecord['samplequestion'] = $this->input->post('samplequestion') === 'on' ? 'Y' : 'N';

            $question_id = $this->question_model->insert($qrecord);
            if ($question_id) {
                $this->load->helper('image');
                $save_result = save_image('question', $question_id . '.jpg');
                if (isset($save_result['error'])) {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: " . $save_result['error'];
                } else {
                    if (isset($save_result['filename']) && file_exists(SARA_QUESTIONS_PICS_DIR . '/' . $save_result['filename'])) {
                        $qrecord['filename'] = $save_result['filename'];
                    }
                    $updated = $this->question_model->update($question_id, $qrecord);
                    $this->data['success'] = TRUE;
                }
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Could not save question information!";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallbyidea() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|question_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->question_model->countAllByIdea(
                    $this->input->post('ideaid')
            );

            $questions = $this->question_model->findAllByIdea(
                    $this->input->post('ideaid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['ideaquestions'] = $questions;
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallbydisclaimer() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('disclaimerid', 'disclaimerid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_numeric|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|question_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->question_model->countAllByDisclaimer(
                    $this->input->post('disclaimerid')
            );

            $questions = $this->question_model->findAllByDisclaimer(
                    $this->input->post('disclaimerid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['disclaimerquestions'] = $questions;
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

}

/* End of file section.php */
/* Location: ./application/controllers/section.php */    
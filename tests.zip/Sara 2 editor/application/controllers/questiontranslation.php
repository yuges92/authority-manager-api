<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class QuestionTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('questiontranslation_model', '', TRUE);
    }

    public function getallbyquestion() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('questionid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|questiontranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->questiontranslation_model->countAllByQuestion(
                    $this->input->post('questionid')
            );

            $questiontranslations = $this->questiontranslation_model->findAllByQuestion(
                    $this->input->post('questionid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['questiontranslations'] = $questiontranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('question_translation_details')) {

            $data = array();

            $question_translation = $this->questiontranslation_model->find(
                    $this->input->post('id')
            );

            if ($question_translation) {
                $data['success'] = TRUE;
                $data['question_translation'] = $question_translation;
            } else {
                $data['error'] = 'Question Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_question_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $question_translation = $this->questiontranslation_model->find($id);
            if ($question_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $qtrecord = array();
                $qtrecord['questionid'] = $this->input->post('questionid');
                $qtrecord['sadescription'] = $this->input->post('sadescription');
                $qtrecord['explanation'] = $this->input->post('explanation');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $qtrecord['code'] = isset($language) ? $this->input->post('code') : '';
                $qtrecord['language'] = isset($language) ? $language : '';
                $qtrecord['created'] = $current_date;
                $qtrecord['created_by'] = $_SESSION["seuname"];
                $qtrecord['modified'] = $current_date;
                $qtrecord['modified_by'] = $_SESSION["seuname"];

                $db_question_translation = $this->questiontranslation_model->findOneByQuestionIdAndCode($qtrecord['questionid'], $qtrecord['code']);
                
//                echo '<pre>';
//                print_r($db_question_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($question_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_question_translation->id==$question_translation->id) {
                    $question_translation_id = $this->questiontranslation_model->update($question_translation->id, $qtrecord);
                    if ($question_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_question_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $qtrecord = array();
            $qtrecord['questionid'] = $this->input->post('questionid');
            $qtrecord['sadescription'] = $this->input->post('sadescription');
            $qtrecord['explanation'] = $this->input->post('explanation');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $qtrecord['code'] = isset($language) ? $this->input->post('code') : '';
            $qtrecord['language'] = isset($language) ? $language : '';
            $qtrecord['created'] = $current_date;
            $qtrecord['created_by'] = $_SESSION["seuname"];
            $qtrecord['modified'] = $current_date;
            $qtrecord['modified_by'] = $_SESSION["seuname"];

            $db_question_translation = $this->questiontranslation_model->findOneByQuestionIdAndCode($qtrecord['questionid'], $qtrecord['code']);
            if (!$db_question_translation) {
                $question_translation_id = $this->questiontranslation_model->insert($qtrecord);
                if ($question_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('questiontranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $authoritycity = $this->questiontranslation_model->find($id);
                if ($authoritycity) {
                    if (!$this->questiontranslation_model->delete($id)) {
                        $data['error'] = 'Delete Question Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Question Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file questiontranslation.php */
/* Location: ./application/controllers/questiontranslation.php */    
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Page extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('page_model', '', TRUE);
        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->page_model->countAll();
            $pages = $this->page_model->findAll(
                    $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            array_walk_recursive($pages, function(&$val) {
                $val = stripped_of_invalid_utf8_chars_string($val);
            });

            $data['success'] = TRUE;
            $data['total'] = $total;
            $data['pages'] = $pages;
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('page_details')) {

            $page = $this->page_model->find(
                    $this->input->post('id')
            );

            if ($page) {
                $data['success'] = TRUE;
                $data['page'] = $page;
            } else {
                $data['error'] = 'Page Not Found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($data));
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('save_page')) {

            $date = date(DATE_FORMAT, time());

            // Setting values for page table columns
            $precord = array();
            $precord['title'] = $this->input->post('title');
            $precord['body_text'] = $this->input->post('body_text');
            $precord['createdAt'] = $date;
            $precord['createdBy'] = $_SESSION["seuname"];
            $precord['modifiedAt'] = $date;
            $precord['modifiedBy'] = $_SESSION["seuname"];
            //$precord['filename'] = $this->input->post('filename');

            $id = $this->input->post('id');
            if ($id > 0) { // edit advice
                $page = $this->page_model->find($id);
                if ($page) {
                    $updated = $this->page_model->update($id, $precord);
                    if (!$updated) {
                        $data['error'] = "Could not save page information!";
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = "Page not found!";
                }
            } else { // new advice
                $newid = $this->page_model->insert($precord);
                if ($newid) {
                    $updated = $this->page_model->update($newid, $precord);
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = "Could not save page information!";
                }
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file page.php */
/* Location: ./application/controllers/page.php */    
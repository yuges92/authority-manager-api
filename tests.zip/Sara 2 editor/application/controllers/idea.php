<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Idea extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('idea_model', '', TRUE);
        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $start = 0;
        $limit = 1000;
        $sort = 1;
        $dir = 'ASC';

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|idea_sort_validation');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $start = $this->input->post('start');
            $limit = $this->input->post('limit');
            $sort = $this->input->post('sort');
            $dir = $this->input->post('dir');

            $total = $this->idea_model->countAll();
            $ideas = $this->idea_model->findAll($start, $limit, $sort, $dir);

            array_walk_recursive($ideas, function(&$val) {
                $val = stripped_of_invalid_utf8_chars_string($val);
            });

            if (!$ideas) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['ideas'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['ideas'] = $ideas;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $ideaid = $this->input->post('ideaid');
        if ($ideaid) {
            $idea = $this->idea_model->find($ideaid);

            array_walk_recursive($idea, function(&$val) {
                $val = stripped_of_invalid_utf8_chars_string($val);
            });

            if ($idea) {
                $this->data['status'] = 'SUCCESS';
                $this->data['idea'] = $idea;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Idea Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid Idea id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        //echo $this->input->post('sadescription', FALSE);exit;
        
        if ($this->form_validation->run('save_idea')) {

            $date = date(DATE_FORMAT, time());

            // Setting values for idea table columns
            $irecord = array();
            $irecord['title'] = $this->input->post('title');
            $irecord['sadescription'] = htmlspecialchars_decode($this->input->post('sadescription', FALSE));
            $irecord['modified'] = $date;
            $irecord['modified_by'] = $_SESSION["seuname"];
            //$irecord['filename'] = $this->input->post('filename');
            //$settings = array();
            //$settings['file_name'] = $filename;

            $ideaid = $this->input->post('ideaid');
            if ($ideaid > 0) { // edit advice
                $idea = $this->idea_model->find($ideaid);
                if ($idea) {
                    $this->load->helper('image');
                    $save_result = save_image('idea', $idea->ideaid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                         $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: ". $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_IDEAS_PICS_DIR . '/' . $save_result['filename'])) {
                            $irecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->idea_model->update($ideaid, $irecord);
                        if ($updated) {
                            
                            $this->data['success'] = TRUE;
                        } else {
                            $this->data['failure'] = TRUE;
                            $this->data['responseText'] = "Could not save idea information!";
                        }
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Idea not found!";
                }
            } else { // new advice
                $irecord['created'] = $date;
                $irecord['created_by'] = $_SESSION["seuname"];
                $newideaid = $this->idea_model->insert($irecord);
                if ($newideaid) {
                    $this->load->helper('image');
                    $save_result = save_image('idea', $newideaid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                        $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: ". $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_IDEAS_PICS_DIR . '/' . $save_result['filename'])) {
                            $irecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->idea_model->update($newideaid, $irecord);
                        
                        $this->data['success'] = TRUE;
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save idea information!";
                }
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function ideacitylist() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        
        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|ideacity_sort_validation');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $iId = 0;
            $start = 0;
            $limit = 1000;
            $sort = 1;
            $dir = 'ASC';
            
            if ($this->input->post('ideaid')) {
                $iId = $this->input->post('ideaid');
            }
            if ($this->input->post('start')) {
                $start = $this->input->post('start');
            }
            if ($this->input->post('limit')) {
                $limit = $this->input->post('limit');
            }
            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }
            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $this->load->model('ideacity_model', '', TRUE);
            $total = $this->ideacity_model->countAllByIdeaId($iId);
            $ideacities = $this->ideacity_model->findAllByIdeaId($iId, $start, $limit, $sort, $dir);
            if (!$ideacities) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['ideacities'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['ideacities'] = $ideacities;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function deleteideacity() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('ideacity_model', '', TRUE);

                $id = $this->input->post('id');
                $ideacity = $this->ideacity_model->find($id);
                if ($ideacity) {
                    if (!$this->ideacity_model->delete($id)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Idea City failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Idea City not found';
                }
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveideacity() {

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('city', 'city', 'trim|ucwords|required|max_length[100]'); //|is_unique_ideacity[ideacity.city]');
        $this->form_validation->set_rules('city_county', 'city_county', 'trim|ucwords|max_length[255]'); //|is_unique_authoritycity[authoritycity.city]'
        if ($this->form_validation->run()) {

            $city_county = $this->input->post('city_county');
            $this->load->model('geodata_model', '', TRUE);
            $county = $this->geodata_model->findOneCountyByCounty($city_county);
            if ($county) {

                // Setting values for selfserve_user table columns
                $icprecord = array();
                $icprecord['ideaid'] = $this->input->post('ideaid');
                $icprecord['city'] = $this->input->post('city');
                $icprecord['county '] = $this->input->post('city_county');
                //$id = $this->input->post('id') ? $this->input->post('id') : 0;
                $this->load->model('ideacity_model', '', TRUE);
                $ideacities = $this->ideacity_model->findIdeaCities($this->input->post('ideaid'));
                if (!in_array($icprecord['city'], $ideacities)) {
                    //$ideacity = $this->ideacity_model->find($id);
                    //if ($ideacity) {
                    //    $this->ideacity_model->update($id, $icprecord);
                    //} else {
                    $this->ideacity_model->insert($icprecord);
                    //}
                }
                $this->data['status'] = 'SUCCESS';
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = "Could not find the County of the selected City!";
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveideacounty() {

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('county', 'county', 'trim|required|ucwords|max_length[255]'); //|is_unique_authoritycity[authoritycity.city]');
        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            //$acprecord = array();
            //$acprecord['authority_id'] = $this->input->post('authority_id');
            //$acprecord['county'] = $this->input->post('county');

            $this->load->model('ideacity_model', '', TRUE);
            $ideacities = $this->ideacity_model->findIdeaCities($this->input->post('ideaid'));

            $this->load->model('geodata_model', '', TRUE);
            $cities = $this->geodata_model->findAllCitiesByCounty($this->input->post('county'));
            foreach ($cities as $city) :

                if (!in_array($city['town'], $ideacities)) {
                    $icprecord = array();
                    $icprecord['ideaid'] = $this->input->post('ideaid');
                    $icprecord['city'] = $city['town'];
                    $icprecord['county'] = $this->input->post('county');
                    $this->ideacity_model->insert($icprecord);
                }

            endforeach;

//            echo '<pre>';
//            print_r($batch_insert);
//            echo '</pre>';
//            exit;
            //   $this->authoritycity_model->insert_batch($batch_insert);
            $this->data['status'] = 'SUCCESS';
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveideaauthorities() {

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric|is_natural_no_zero|less_than[100000]');
        //$this->form_validation->set_rules('authority_ids[]', 'authority_ids[]', 'required');
        if ($this->form_validation->run()) {

            $this->load->model('ideaauthority_model', '', TRUE);
            $this->load->model('authority_model', '', TRUE);
            $db_authority_ids = $this->authority_model->findAllIdsByIdea($this->input->post('ideaid'));

            $authority_ids = $this->input->post('authority_ids[]');
            if(is_array($authority_ids) && !empty($authority_ids)) {
                foreach ($authority_ids as $authority_id) :
                    if (!in_array($authority_id, $db_authority_ids)) {
                        $iarecord = array();
                        $iarecord['ideaid'] = $this->input->post('ideaid');
                        $iarecord['authority_id'] = $authority_id;

                        $this->ideaauthority_model->insert($iarecord);
                    }
                endforeach;
            }

            $this->data['status'] = 'SUCCESS';
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function authority_type_check($str) {
        $authority_type_allowed = array('BASIC', 'COMPLEX', 'COMMERCIAL', 'BASIC1');
        if (!in_array($str, $authority_type_allowed)) {
            $this->form_validation->set_message('authority_type_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function authoritytextreplace_sort_check($str) {
        if (!in_array($str, array('id', 'authority_id', 'look_for', 'action', 'replace_with'))) {
            $this->form_validation->set_message('authoritytextreplace_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function authoritycity_sort_check($str) {
        if (!in_array($str, array('id', 'city'))) {
            $this->form_validation->set_message('authoritycity_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    public function ideareference_sort_check($str) {
        if (!in_array($str, array('id', 'title', 'author', 'year'))) {
            $this->form_validation->set_message('ideareference_sort_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

}

/* End of file authority.php */
/* Location: ./application/controllers/authority.php */    
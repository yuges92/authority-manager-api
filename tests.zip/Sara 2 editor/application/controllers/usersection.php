<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class UserSection extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('usersection_model', '', TRUE);
        $this->load->model('authority_model', '', TRUE);
    }

    public function exportusercompletedsections() {

        $this->form_validation->set_rules('auth', 'auth', 'trim|required');
        $this->form_validation->set_rules('start_date', 'start_date', 'trim|required');
        $this->form_validation->set_rules('end_date', 'end_date', 'trim|required');
        if ($this->form_validation->run()) {

            $auth = $this->input->post('auth');

            $authority = $this->authority_model->findByShortName($auth);
            if ($authority) {
                $start_date = $this->input->post('start_date');
                $end_date = $this->input->post('end_date');
                //if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$dates['start_date']) && preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$dates['end_date'])) {
//        if (preg_match("/^[0-9]{4}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/",$dates['start_date']) && preg_match("/^[0-9]{4}(0[1-9]|1[0-2])(0[1-9]|[1-2][0-9]|3[0-1])$/",$dates['end_date'])) {
                $user_sections = $this->usersection_model->searchAllUserCompletedByAuthority($auth, $start_date, $end_date);
                if ($user_sections) {
                    
//
//                echo '<pre>';
//                print_r($user_sections);
//                echo '</pre>';
//                exit;
//                //load our new PHPExcel library
                    $this->load->library('excel');
//                //activate worksheet number 1
                    $this->excel->setActiveSheetIndex(0);
//                //name the worksheet
                    $this->excel->getActiveSheet()->setTitle($authority->short_name . '-users sections completed');
//                // read data to active sheet
                    PHPExcel_Shared_Font::setAutoSizeMethod(PHPExcel_Shared_Font::AUTOSIZE_METHOD_EXACT);

                    $heading = array('SECTION ID', 'SECTION NAME', 'TOTAL',);
                    //Loop Heading
                    $rowNumberH = 1;
                    $colH = 'A';
                    foreach ($heading as $h) :
                        $this->excel->getActiveSheet()->setCellValue($colH . $rowNumberH, $h);
                        $this->excel->getActiveSheet()->getColumnDimension($colH)->setAutoSize(true); // auto-resize cols
                        $colH++;
                    endforeach;
                    //Loop Result
                    $row = 2;
                    foreach ($user_sections as $us) :
                        $this->excel->getActiveSheet()->SetCellValue('A' . $row, $us['SECTION ID']);
                        $this->excel->getActiveSheet()->SetCellValue('B' . $row, $us['SECTION NAME']);
                        $this->excel->getActiveSheet()->SetCellValue('C' . $row, $us['total']);
                        $row++;
                    endforeach;
                    
                    if (!file_exists(EXPORTS_BASE_PATH)) {
                        mkdir(EXPORTS_BASE_PATH, 0777, TRUE);
                    }
                    
                    // save to file
                    $filename = md5(uniqid(rand(), true)) . '.csv'; //save our workbook as this file name
                    $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'CSV');
                    $objWriter->save(EXPORTS_BASE_PATH . $filename);
                    
                    // TO DO:: Create table file_exports and save entry every time an export is required
                    
                    $json['success'] = TRUE;
                    $json['filename'] = EXPORTS_BASE_URL . '/' . $filename;
                } else {
                    $json['failure'] = TRUE;
                    $json['message'] = 'No records found';
                }
            } else {
                $json['failure'] = TRUE;
                $json['message'] = 'Authority not found';
            }
        } else {
            $json['failure'] = TRUE;
            $json['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($json, JSON_UNESCAPED_SLASHES));
    }

}

/* End of file globalsetting.php */
/* Location: ./application/controllers/globalsetting.php */    
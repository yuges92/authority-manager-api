<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class GlobalSetting extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["meeuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('account_model', '', TRUE);
        $user = $this->account_model->findByUsername($_SESSION["meeuname"]);

        if ($user <= 0 || ( $user['type'] !== 'administrator' && $user['type'] !== 'user' )) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->library('form_validation');
        $this->load->model('global_setting_model', '', TRUE);
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $filter_by = 0;
        $search_key = '';
        $start = 0;
        $limit = 1000;
        $sort = 'createdAt';
        $dir = 'ASC';

        $this->form_validation->set_rules('filter_by', 'filter_by', 'trim|is_natural|less_than[13]|greater_than[-1]');
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
//        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_sort_check');
//        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
        // if validation was successful with no errors
        if ($this->form_validation->run() /* && $this->model_name->method() */) {

            if ($this->input->post('filter_by')) {
                $filter_by = trim($this->input->post('filter_by'));
            }

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }


            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $total = $this->global_setting_model->countAll($filter_by, $search_key);
            $globalsettings = $this->global_setting_model->findAll($filter_by, $search_key, $start, $limit, $sort, $dir);
            if (!$globalsettings) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['globalsettings'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['globalsettings'] = $globalsettings;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function findbytitle() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_key = '';

        $this->form_validation->set_rules('name', 'trim|min_length[2]|max_length[30]');

        // if validation was successful with no errors
        if ($this->form_validation->run() /* && $this->model_name->method() */) {

            if ($this->input->post('name')) {
                $name = trim($this->input->post('name'));
            }

            $topics = $this->topic_model->searchByTitle($name);
            if (!$topics) {
                $this->data['status'] = 'SUCCESS';
                $this->data['advices'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['topics'] = $topics;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $tId = $this->input->post('topic_id');
        if ($tId) {
            $topic = $this->topic_model->find($tId);
            if ($topic) {
                $this->data['status'] = 'SUCCESS';
                $this->data['topic'] = $topic;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Topic Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid Topic id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function add() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        $this->form_validation->set_rules('name', 'required|trim|max_length[50]');
        $this->form_validation->set_rules('value', 'required|trim|exactly_length[1]');

        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            $gsrecord = array();
            $name = $this->input->post('name');
            $value = $this->input->post('value');
            $global_setting = $this->global_setting_model->findByName($name);
            if ($global_setting) {
                $gsrecord['value'] = $value;
                $this->global_setting_model->update($global_setting->id, $gsrecord);
            } else {
                $gsrecord['name'] = $name;
                $gsrecord['value'] = $value;
                $this->global_setting_model->insert($gsrecord);
            }
            $this->data['success'] = TRUE;
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        $this->form_validation->set_rules('id', 'required|trim|numeric');
        $this->form_validation->set_rules('name', 'required|trim|max_length[50]');
        $this->form_validation->set_rules('value', 'required|trim|exactly_length[1]');

        //  if ($this->input->post('advice_id')) {
        if ($this->form_validation->run()) {

             // Setting values for global setting table columns
            $id = $this->input->post('id');
            $global_setting = $this->global_setting_model->find($id);
            if ($global_setting) {
                $gsrecord = array();
                $gsrecord['name'] = $this->input->post('name');
                $gsrecord['value'] = $this->input->post('value');
                $this->global_setting_model->update($id, $gsrecord);
                $this->data['success'] = TRUE;
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = 'Global setting not found.';
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        //  }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

}

/* End of file topic.php */
/* Location: ./application/controllers/topic.php */    
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Authority extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->model('authority_model', '', TRUE);
        $this->load->helper('product');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|numeric|max_length[5]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|numeric|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $this->authority_model->countAll();
            $this->data['authorities'] = $this->authority_model->findAll(
                    $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $authority_id = $this->input->post('authority_id');
        if ($authority_id) {
            $authority = $this->authority_model->find($authority_id);
            if ($authority) {
                $this->data['status'] = 'SUCCESS';
                $this->data['authority'] = $authority;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Authority Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid Authority id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_authority')) {

            $current_date = date(DATE_FORMAT, time());

            $authority_id = $this->input->post('authority_id');
            $authority = $this->authority_model->find($authority_id);
            if ($authority) {

                // Setting values for selfserve_user table columns
                $arecord = array();
                $arecord['supplier_id'] = $this->input->post('supplier_id');
                $arecord['full_name'] = $this->input->post('full_name');
                $arecord['short_name'] = $this->input->post('short_name');
                $arecord['authority_type'] = $this->input->post('authority_type');
                $arecord['email'] = $this->input->post('email');
                $arecord['local_authority_url'] = $this->input->post('local_authority_url');
                $arecord['website'] = $this->input->post('website');
                $arecord['active'] = $this->input->post('active') === 'on' ? 'Y' : 'N';
                $arecord['always_disclaimer'] = $this->input->post('always_disclaimer') === 'on' ? 'Y' : 'N';
                $arecord['introduction'] = $this->input->post('introduction');
                $arecord['disclaimer_text'] = $this->input->post('disclaimer_text');
                $arecord['disclaimer_text_cy'] = $this->input->post('disclaimer_text_cy');
                $arecord['report_results_message'] = $this->input->post('report_results_message');
                $arecord['helpline_text'] = $this->input->post('helpline_text');
                $arecord['send_report_to_authority'] = $this->input->post('send_report_to_authority') === 'on' ? 'Y' : 'N';
                $arecord['send_report_to_friend'] = $this->input->post('send_report_to_friend') === 'on' ? 'Y' : 'N';
                $arecord['include_childrens_group'] = $this->input->post('include_childrens_group') === 'on' ? 'Y' : 'N';
                $arecord['show_related_products'] = $this->input->post('show_related_products') === 'on' ? 'Y' : 'N';
                $arecord['feedback_form_url'] = $this->input->post('feedback_form_url');
                $arecord['feedback_form_url_cy'] = $this->input->post('feedback_form_url_cy');
                $arecord['report_no_results_message'] = $this->input->post('report_no_results_message');
                $arecord['local_authority'] = $this->input->post('local_authority') === 'on' ? 'Y' : 'N';
                $arecord['retailer_location'] = $this->input->post('retailer_location');

                $arecord['created'] = $current_date;
                $arecord['created_by'] = $_SESSION["seuname"];
                $arecord['modified'] = $current_date;
                $arecord['modified_by'] = $_SESSION["seuname"];

                $this->load->helper('image');
                $save_result = save_image('authority', $authority->authority_id . '.jpg');
                if (isset($save_result['error'])) {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: " . $save_result['error'];
                } else {
                    if (isset($save_result['filename']) && file_exists(SARA_AUTHORITY_PICS_DIR . '/' . $save_result['filename'])) {
                        $arecord['filename'] = $save_result['filename'];
                    }
                    $updated = $this->authority_model->update($authority->authority_id, $arecord);
                    if ($updated) {
                        $this->data['success'] = TRUE;
                    } else {
                        $this->data['failure'] = TRUE;
                        $this->data['responseText'] = "Could not save authority information!";
                    }
                }
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Authority not found";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function create() { 

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_authority')) {

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $arecord = array();
            $arecord['supplier_id'] = $this->input->post('supplier_id');
            $arecord['full_name'] = $this->input->post('full_name');
            $arecord['short_name'] = $this->input->post('short_name');
            $arecord['authority_type'] = $this->input->post('authority_type');
            $arecord['email'] = $this->input->post('email');
            $arecord['local_authority_url'] = $this->input->post('local_authority_url');
            $arecord['website'] = $this->input->post('website');
            $arecord['active'] = $this->input->post('active') === 'on' ? 'Y' : 'N';
            $arecord['always_disclaimer'] = $this->input->post('always_disclaimer') === 'on' ? 'Y' : 'N';
            $arecord['postcodes'] = $this->input->post('postcodes');
            $arecord['introduction'] = $this->input->post('introduction');
            $arecord['report_results_message'] = $this->input->post('report_results_message');
            $arecord['report_no_results_message'] = $this->input->post('report_no_results_message');
            $arecord['helpline_text'] = $this->input->post('helpline_text');
            $arecord['disclaimer_text'] = $this->input->post('disclaimer_text');
            $arecord['disclaimer_text_cy'] = $this->input->post('disclaimer_text_cy');
            $arecord['local_authority'] = $this->input->post('local_authority') === 'on' ? 'Y' : 'N';
            $arecord['send_report_to_authority'] = $this->input->post('send_report_to_authority') === 'on' ? 'Y' : 'N';
            $arecord['send_report_to_friend'] = $this->input->post('send_report_to_friend') === 'on' ? 'Y' : 'N';
            $arecord['retailer_location'] = $this->input->post('retailer_location');
            $arecord['include_childrens_group'] = $this->input->post('include_childrens_group') === 'on' ? 'Y' : 'N';
            $arecord['show_related_products'] = $this->input->post('show_related_products') === 'on' ? 'Y' : 'N';
            $arecord['feedback_form_url'] = $this->input->post('feedback_form_url');
            $arecord['feedback_form_url_cy'] = $this->input->post('feedback_form_url_cy');

            $arecord['created'] = $current_date;
            $arecord['created_by'] = $_SESSION["seuname"];
            $arecord['modified'] = $current_date;
            $arecord['modified_by'] = $_SESSION["seuname"];

            $authority_id = $this->authority_model->insert($arecord);
            if ($authority_id) {
                $this->load->helper('image');
                $save_result = save_image('authority', $authority_id . '.jpg');
                if (isset($save_result['error'])) {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: " . $save_result['error'];
                } else {
                    if (isset($save_result['filename']) && file_exists(SARA_AUTHORITY_PICS_DIR . '/' . $save_result['filename'])) {
                        $arecord['filename'] = $save_result['filename'];
                    }
                    $updated = $this->authority_model->update($authority_id, $arecord);
                    $this->data['success'] = TRUE;
                }
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Could not save authority information!";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function authoritytextreplacelist() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

//        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
//        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
//        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
//        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_authoritytextreplace_sort_check');
//        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
//        // if validation was successful with no errors
        $data = array();
        if ($this->form_validation->run('authority_text_replace_list_all')) {

            $this->load->model('authoritytextreplace_model', '', TRUE);
            $data['status'] = 'SUCCESS';
            $data['total'] = $this->authoritytextreplace_model->countAllByAuthorityId(
                    $this->input->post('authority_id')
            );
            $data['authoritytextreplaces'] = $this->authoritytextreplace_model->findAllByAuthorityId(
                    $this->input->post('authority_id'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

//    public function authoritytextreplacetranslationlist() {
//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }
//
//        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
//        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
//        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
//        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_authoritytextreplace_sort_check');
//        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
//        // if validation was successful with no errors
//        if ($this->form_validation->run()) {
//
//            $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
//            $this->data['status'] = 'SUCCESS';
//            $this->data['total'] = $this->authoritytextreplacetranslation_model->countAllByAuthorityId(
//                    $this->input->post('authority_id')
//            );
//            $this->data['authoritytextreplacetranslations'] = $this->authoritytextreplacetranslation_model->findAllByAuthorityId(
//                    $this->input->post('authority_id'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
//            );
//        } else {
//            $this->output->set_status_header('400'); //Triggers the jQuery error callback
//            $this->data['status'] = 'FAIL';
//            $this->data['message'] = validation_errors();
//        }
//
//        $this->output->set_content_type('application/json');
//        $this->output->set_output(json_encode($this->data));
//    }

    public function saveauthoritytextreplacetranslation() {

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('look_for', 'look_for', 'trim|max_length[500]');
        $this->form_validation->set_rules('action', 'action', 'trim|max_length[50]');
        $this->form_validation->set_rules('replace_with', 'replace_with', 'trim|max_length[3000]');
        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            $atrtprecord = array();
            $atrtprecord['authority_id'] = $this->input->post('authority_id');
            $atrtprecord['look_for'] = $this->input->post('look_for');
            $atrtprecord['action'] = $this->input->post('action');
            $atrtprecord['replace_with'] = $this->input->post('replace_with');
            $id = $this->input->post('id') ? $this->input->post('id') : 0;
            $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
            $authoritytextreplacetranslation = $this->authoritytextreplacetranslation_model->find($id);
            if ($authoritytextreplacetranslation) {
                $this->authoritytextreplacetranslation_model->update($id, $atrtprecord);
                $this->data['status'] = 'SUCCESS';
            } else {
                $this->authoritytextreplacetranslation_model->insert($atrtprecord);
                $this->data['status'] = 'SUCCESS';
            }
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function deleteauthoritytextreplacetransaltion() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('authoritytextreplacetranslation_model', '', TRUE);

                $id = $this->input->post('id');
                $authoritytextreplacetranslation = $this->authoritytextreplacetranslation_model->find($id);
                if ($authoritytextreplacetranslation) {
                    if (!$this->authoritytextreplacetranslation_model->delete($id)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Authority Text Replace Translation failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Authority Text Replace Translation not found';
                }
            } else {
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Invalid Data submitted';
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallbyidea() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $ideaid = $this->input->post('ideaid');
            $start = $this->input->post('start');
            $limit = $this->input->post('limit');
            $sort = $this->input->post('sort');
            $dir = $this->input->post('dir');

            $authorities = $this->authority_model->findAllByIdea($ideaid, $start, $limit, $sort, $dir);
            if (!$authorities) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['ideaauthorities'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($authorities);
                $this->data['ideaauthorities'] = $authorities;
            }
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallnotlinkedtoidea() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $ideaid = $this->input->post('ideaid');
            $start = $this->input->post('start');
            $limit = $this->input->post('limit');
            $sort = $this->input->post('sort');
            $dir = $this->input->post('dir');

            $authorities = $this->authority_model->findAllNotLinkedtoIdea($ideaid, $start, $limit, $sort, $dir);
            if (!$authorities) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['authorities'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($authorities);
                $this->data['authorities'] = $authorities;
            }
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallbydisclaimer() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('disclaimerid', 'disclaimerid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|numeric|max_length[5]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|numeric|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->authority_model->countAllByDisclaimer(
                    $this->input->post('disclaimerid')
            );

            $authorities = array();
            if ($total > 0) {
                $authorities = $this->authority_model->findAllByDisclaimer(
                        $this->input->post('disclaimerid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
                );
            }
            $this->data['disclaimerauthorities'] = $authorities;
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function getallnotlinkedtodisclaimer() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('disclaimerid', 'disclaimerid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|numeric|max_length[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|numeric|max_length[1000]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $authorities = $this->authority_model->findAllNotLinkedtoDisclaimer(
                    $this->input->post('disclaimerid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            if (!$authorities) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['authorities'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($authorities);
                $this->data['authorities'] = $authorities;
            }
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function deleteauthoritytextreplace() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('authoritytextreplace_model', '', TRUE);

                $id = $this->input->post('id');
                $authoritytextreplace = $this->authoritytextreplace_model->find($id);
                if ($authoritytextreplace) {
                    if (!$this->authoritytextreplace_model->delete($id)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Authority Text Replace failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Authority Text Replace not found';
                }
            } else {
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Invalid Data submitted';
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveauthoritytextreplace() {

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('look_for', 'look_for', 'trim|max_length[500]');
        $this->form_validation->set_rules('action', 'action', 'trim|max_length[50]');
        $this->form_validation->set_rules('replace_with', 'replace_with', 'trim|max_length[3000]');
        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            $atrtprecord = array();
            $atrtprecord['authority_id'] = $this->input->post('authority_id');
            $atrtprecord['look_for'] = $this->input->post('look_for');
            $atrtprecord['action'] = $this->input->post('action');
            $atrtprecord['replace_with'] = $this->input->post('replace_with');
            $id = $this->input->post('id') ? $this->input->post('id') : 0;
            $this->load->model('authoritytextreplace_model', '', TRUE);
            $authoritytextreplace = $this->authoritytextreplace_model->find($id);
            if ($authoritytextreplace) {
                $this->authoritytextreplace_model->update($id, $atrtprecord);
                $this->data['status'] = 'SUCCESS';
            } else {
                $this->authoritytextreplace_model->insert($atrtprecord);
                $this->data['status'] = 'SUCCESS';
            }
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function authoritycitylist() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        $aId = 0;
        $start = 0;
        $limit = 1000;
        $sort = 1;
        $dir = 'ASC';

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_authoritycity_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('authority_id')) {
                $aId = trim($this->input->post('authority_id'));
            }

            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $this->load->model('authoritycity_model', '', TRUE);
            $total = $this->authoritycity_model->countAllByAuthorityId($aId);
            $authoritycities = $this->authoritycity_model->findAllByAuthorityId($aId, $start, $limit, $sort, $dir);
            if (!$authoritycities) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['authoritycities'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['authoritycities'] = $authoritycities;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function deleteauthoritycity() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('id')) {

                $this->load->model('authoritycity_model', '', TRUE);

                $id = $this->input->post('id');
                $authoritycity = $this->authoritycity_model->find($id);
                if ($authoritycity) {
                    if (!$this->authoritycity_model->delete($id)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Authority City failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Authority City not found';
                }
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveauthoritycity() {

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('city', 'city', 'trim|ucwords|required|max_length[255]'); //|is_unique_authoritycity[authoritycity.city]');
        $this->form_validation->set_rules('city_county', 'city_county', 'trim|ucwords|max_length[255]'); //|is_unique_authoritycity[authoritycity.city]');

        if ($this->form_validation->run()) {

            $city_county = $this->input->post('city_county');
            $this->load->model('geodata_model', '', TRUE);
            $county = $this->geodata_model->findOneCountyByCounty($city_county);
            if ($county) {

                // Setting values for selfserve_user table columns
                $acprecord = array();
                $acprecord['authority_id'] = $this->input->post('authority_id');
                $acprecord['city'] = $this->input->post('city');
                $acprecord['county '] = $this->input->post('city_county');


                //$id = $this->input->post('id') ? $this->input->post('id') : 0;
                $this->load->model('authoritycity_model', '', TRUE);

                $authoritycities = $this->authoritycity_model->findAuthorityCities($this->input->post('authority_id'));
                if (!in_array($acprecord['city'], $authoritycities)) {
                    //$authoritycity = $this->authoritycity_model->find($id);
                    //if ($authoritycity) {
                    //    $this->authoritycity_model->update($id, $acprecord);
                    //} else {
                    $this->authoritycity_model->insert($acprecord);
                    //}
                }

                $this->data['status'] = 'SUCCESS';
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = "Could not find the County of the selected City!";
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function saveauthoritycounty() {

        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        $this->form_validation->set_rules('county', 'county', 'trim|ucwords|required|max_length[255]'); //|is_unique_authoritycity[authoritycity.city]');
        if ($this->form_validation->run()) {

            // Setting values for selfserve_user table columns
            //$acprecord = array();
            //$acprecord['authority_id'] = $this->input->post('authority_id');
            //$acprecord['county'] = $this->input->post('county');

            $this->load->model('authoritycity_model', '', TRUE);
            $authoritycities = $this->authoritycity_model->findAuthorityCities($this->input->post('authority_id'));
            $this->load->model('geodata_model', '', TRUE);
            $cities = $this->geodata_model->findAllCitiesByCounty($this->input->post('county'));
            foreach ($cities as $city) :

                if (!in_array($city['town'], $authoritycities)) {
                    $acprecord = array();
                    $acprecord['authority_id'] = $this->input->post('authority_id');
                    $acprecord['city'] = $city['town'];
                    $acprecord['county'] = $this->input->post('county');
                    $this->authoritycity_model->insert($acprecord);
                }

            endforeach;

//            echo '<pre>';
//            print_r($batch_insert);
//            echo '</pre>';
//            exit;
            //   $this->authoritycity_model->insert_batch($batch_insert);
            $this->data['status'] = 'SUCCESS';
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    private function _handleImageUpload($ifile) {
        $upload_result = array('error' => 0);
        if ($_FILES['authority_picture']['error'] === 0) {
            $this->load->library('upload');
            $this->config->load('file_upload', TRUE);
            $upload_settings = $this->config->item('authority_picture', 'file_upload');
            $upload_settings['file_name'] = $ifile;
            $upload_result = array('error' => 0);
            $config['allowed_types'] = 'jpg|jpeg';
            $config['max_size'] = "1000KB";
            if (!file_exists($upload_settings['upload_path'])) { // create directory if it does not exist
                mkdir($upload_settings['upload_path'], 0777, true);
            }
            $this->upload->initialize($upload_settings);
            if (!$this->upload->do_upload('authority_picture')) {
                $upload_result = array('error' => 1, 'message' => $this->upload->display_errors());
            }
        } else {
            $upload_result = array('error' => 1, 'message' => $_FILES['authority_picture']['error']);
        }
        return $upload_result;
    }

}

/* End of file authority.php */
/* Location: ./application/controllers/authority.php */    
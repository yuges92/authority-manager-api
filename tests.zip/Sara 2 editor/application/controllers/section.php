<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Section extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }
        
        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('section_model', '', TRUE);
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $filter_by = 0;
        $search_key = '';
        $start = 0;
        $limit = 1000;
        $sort = 'createdAt';
        $dir = 'ASC';

        $this->form_validation->set_rules('filter_by', 'filter_by', 'trim|is_natural|less_than[13]|greater_than[-1]');
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
//        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_sort_check');
//        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
        // if validation was successful with no errors
        if ($this->form_validation->run() /* && $this->model_name->method() */) {

            if ($this->input->post('filter_by')) {
                $filter_by = trim($this->input->post('filter_by'));
            }

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }


            if ($this->input->post('start')) {
                $start = intval($this->input->post('start'));
                if ($start < 0) {
                    $start = 0;
                }
            }

            if ($this->input->post('limit')) {
                $limit = intval($this->input->post('limit'));
                if ($limit < 50) {
                    $limit = 1000;
                }
            }

            if ($this->input->post('sort')) {
                $sort = trim($this->input->post('sort'));
            }

            if ($this->input->post('dir')) {
                $dir = trim($this->input->post('dir'));
            }

            $total = $this->section_model->countAll($filter_by, $search_key );
            $sections = $this->section_model->findAll($filter_by, $search_key, $start, $limit, $sort, $dir);
            if (!$sections) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['advices'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['sections'] = $sections;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        if ($this->form_validation->run('section_details')) {

            $section = $this->section_model->find(
                    $this->input->post('sectionid')
            );

            if ($section) {
                $data['success'] = TRUE;
                $data['group'] = $section;
            } else {
                $data['error'] = 'Section not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
        
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

      //  if ($this->input->post('advice_id')) {
            if ($this->form_validation->run('save_section')) {

                // Setting values for selfserve_user table columns
                $srecord = array();
                $srecord['title'] = $this->input->post('title');
                
                $filename = strtolower($this->input->post('title'));
                $filename = $filename . ".jpg";
                if (!empty($_FILES) && isset($_FILES['section_picture'])) {
                    
                    $upload_result = $this->_save_image($filename);
                    if ($upload_result['error']===0) {
                        $srecord['picture'] = $filename;
                    }
                }
                
                $sId = $this->input->post('section_id');
                $section = $this->section_model->find($sId);
                if ($section) {
                    $this->section_model->update($sId, $srecord);
                } else {
                    $last_id = $this->section_model->insert($srecord);
                }
                
                $this->data['success'] = TRUE;
                
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = strip_tags(validation_errors());
            }
      //  }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    public function getallbyidea() {
        
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        
        $this->form_validation->set_rules('ideaid', 'ideaid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');
        
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $ideaid = $this->input->post('ideaid');
            $start = $this->input->post('start');
            $limit = $this->input->post('limit');
            $sort = $this->input->post('sort');
            $dir = $this->input->post('dir');
            
            $sections = $this->section_model->findAllByIdea($ideaid, $start, $limit, $sort, $dir);
            if (!$sections) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['ideasections'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($sections);
                $this->data['ideasections'] = $sections;
            }
           
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    
   public function getallbydisclaimer() {
        
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
        
        $this->form_validation->set_rules('disclaimerid', 'ideaid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');
        
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->section_model->countAllByDisclaimer(
                    $this->input->post('disclaimerid'),
                    $this->input->post('start'),
                    $this->input->post('limit'),
                    $this->input->post('sort'),
                    $this->input->post('dir')
                    );
            
            $disclaimersections = $this->section_model->findAllByDisclaimer(
                    $this->input->post('disclaimerid'),
                    $this->input->post('start'),
                    $this->input->post('limit'),
                    $this->input->post('sort'),
                    $this->input->post('dir')
                    );
            
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['disclaimersections'] = $disclaimersections;
  
        } else {
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    
    private function _save_image($ifile) {
        $upload_result = array('error'=>0);
        if ($_FILES['section_picture']['error'] === 0) {
            $this->load->library('upload');
            $this->config->load('file_upload', TRUE);
            $upload_settings = $this->config->item('section_picture', 'file_upload');
            $upload_settings['file_name'] = $ifile;
            if (!file_exists($upload_settings['upload_path'])) { // create directory if it does not exist
                mkdir($upload_settings['upload_path'], 0777, true); 
            }
            $this->upload->initialize($upload_settings);
            if (!$this->upload->do_upload('section_picture')) {
                $upload_result = array('error'=>1, 'message'=>$this->upload->display_errors());
            }
        } else {
            $upload_result = array('error'=>1, 'message'=>$_FILES['section_picture']['error']);
        }

        return $upload_result;
    }
    
}

/* End of file section.php */
/* Location: ./application/controllers/section.php */    
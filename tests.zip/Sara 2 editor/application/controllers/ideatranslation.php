<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class IdeaTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('ideatranslation_model', '', TRUE);
    }

    public function getallbyidea() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('ideaid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|ideatranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->ideatranslation_model->countAllByIdea(
                    $this->input->post('ideaid')
            );

            $ideatranslations = $this->ideatranslation_model->findAllByIdea(
                    $this->input->post('ideaid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['ideatranslations'] = $ideatranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('idea_translation_details')) {

            $data = array();

            $idea_translation = $this->ideatranslation_model->find(
                    $this->input->post('id')
            );

            if ($idea_translation) {
                $data['success'] = TRUE;
                $data['idea_translation'] = $idea_translation;
            } else {
                $data['error'] = 'Idea Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_idea_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $idea_translation = $this->ideatranslation_model->find($id);
            if ($idea_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $itrecord = array();
                $itrecord['ideaid'] = $this->input->post('ideaid');
                $itrecord['title'] = $this->input->post('title');
                $itrecord['sadescription'] = htmlspecialchars_decode($this->input->post('sadescription', FALSE));
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $itrecord['code'] = isset($language) ? $this->input->post('code') : '';
                $itrecord['language'] = isset($language) ? $language : '';
                $itrecord['created'] = $current_date;
                $itrecord['created_by'] = $_SESSION["seuname"];
                $itrecord['modified'] = $current_date;
                $itrecord['modified_by'] = $_SESSION["seuname"];

                $db_idea_translation = $this->ideatranslation_model->findOneByIdeaIdAndCode($itrecord['ideaid'], $itrecord['code']);
                
//                echo '<pre>';
//                print_r($db_idea_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($idea_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_idea_translation->id==$idea_translation->id) {
                    $idea_translation_id = $this->ideatranslation_model->update($idea_translation->id, $itrecord);
                    if ($idea_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_idea_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $itrecord = array();
            $itrecord['ideaid'] = $this->input->post('ideaid');
            $itrecord['title'] = $this->input->post('title');
            $itrecord['sadescription'] = htmlspecialchars_decode($this->input->post('sadescription', FALSE));
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $itrecord['code'] = isset($language) ? $this->input->post('code') : '';
            $itrecord['language'] = isset($language) ? $language : '';
            $itrecord['created'] = $current_date;
            $itrecord['created_by'] = $_SESSION["seuname"];
            $itrecord['modified'] = $current_date;
            $itrecord['modified_by'] = $_SESSION["seuname"];

            $db_idea_translation = $this->ideatranslation_model->findOneByIdeaIdAndCode($itrecord['ideaid'], $itrecord['code']);
            if (!$db_idea_translation) {
                $idea_translation_id = $this->ideatranslation_model->insert($itrecord);
                if ($idea_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('ideatranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $authoritycity = $this->ideatranslation_model->find($id);
                if ($authoritycity) {
                    if (!$this->ideatranslation_model->delete($id)) {
                        $data['error'] = 'Delete Idea Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Idea Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file ideatranslation.php */
/* Location: ./application/controllers/ideatranslation.php */    
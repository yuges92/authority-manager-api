<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Answer extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->load->model('answer_model', '', TRUE);
        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->helper('text');
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->answer_model->countAll();
            $answers = $this->answer_model->findAll(
                    $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            array_walk_recursive($answers, function(&$val) {
                $val = stripped_of_invalid_utf8_chars_string($val);
            });

            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $total;
            $this->data['answers'] = $answers;
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('answer_details')) {

            $answer = $this->answer_model->find(
                    $this->input->post('answerid')
            );

            if ($answer) {
                $this->data['status'] = 'SUCCESS';
                $this->data['answer'] = $answer;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Answer Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function save() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('save_answer')) {

            $date = date(DATE_FORMAT, time());

            // Setting values for answer table columns
            $arecord = array();
            $arecord['description'] = $this->input->post('description');
            $arecord['index'] = $this->input->post('index');
            //$arecord['modified'] = $date;
            //$arecord['modified_by'] = $_SESSION["seuname"];
            //$arecord['filename'] = $this->input->post('filename');

            $answerid = $this->input->post('answerid');
            if ($answerid > 0) { // edit advice
                $answer = $this->answer_model->find($answerid);
                $old_filename = !empty($answer->filename) ? $answer->filename : '';
                if ($answer) {
                    $this->load->helper('image');
                    $save_result = save_image('answer', $answer->answerid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                         $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: ". $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_ANSWERS_PICS_DIR . '/' . $save_result['filename'])) {
                            $arecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->answer_model->update($answerid, $arecord);
                        if (!$updated) {
                            $this->data['failure'] = TRUE;
                            $this->data['responseText'] = "Could not save answer information!";
                        } else {
                            // delete old answer pic
                            //                            if (strlen($old_filename) !== '' && file_exists(SARA_ANSWERS_PICS_DIR . '/' . $old_filename)) {
                            //                                unlink(SARA_ANSWERS_PICS_DIR . '/' . $old_filename);
                            //                            }
                            
                            $this->data['success'] = TRUE;
                        }
                    }
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Answer not found!";
                }
            } else { // new advice
                //$arecord['created'] = $date;
                //$arecord['created_by'] = $_SESSION["seuname"];
                $newanswerid = $this->answer_model->insert($arecord);
                if ($newanswerid) {
                    $this->load->helper('image');
                    $save_result = save_image('answer', $newanswerid . '.jpg');
                    if (isset($save_result['error'])) {
                        $this->data['failure'] = TRUE;
                         $this->data['responseText'] = $this->data['responseText'] = "Could not save image filename to database: ". $save_result['error'];
                    } else {
                        if (isset($save_result['filename']) && file_exists(SARA_ANSWERS_PICS_DIR . '/' . $save_result['filename'])) {
                            $arecord['filename'] = $save_result['filename'];
                        }
                        $updated = $this->answer_model->update($newanswerid, $arecord);
                        
                    }
                    $this->data['success'] = TRUE;
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save answer information!";
                }
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

//    private function _save_image($settings) {
//        $upload_result = array('error' => 0);
//        if ($_FILES['answer_picture']['error'] === 0) {
//            $this->load->library('upload');
//            $this->config->load('file_upload', TRUE);
//            $upload_settings = $this->config->item('answer_picture', 'file_upload');
//            $upload_settings['file_name'] = $settings['filename'];
//            if (!file_exists($upload_settings['upload_path'])) { // create directory if it does not exist
//                mkdir($upload_settings['upload_path'], 0777, true);
//            }
//            $this->upload->initialize($upload_settings);
//            if (!$this->upload->do_upload('answer_picture')) {
//                $upload_result['error'] = 1;
//                $upload_result['message'] = strip_tags($this->upload->display_errors());
//            }
//        } else {
//            $upload_result = array('error'=>1, 'message'=>$_FILES['answer_picture']['error']);
//        }
//        return $upload_result;
//    }
}

/* End of file answer.php */
/* Location: ./application/controllers/answer.php */    
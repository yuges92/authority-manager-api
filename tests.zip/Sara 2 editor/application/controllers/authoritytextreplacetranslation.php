<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class AuthorityTextReplaceTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
    }

    public function getallbyauthority() {
        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }
//
//        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
//        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
//        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
//        $this->form_validation->set_rules('sort', 'sort', 'trim|required|callback_authoritytextreplace_sort_check');
//        $this->form_validation->set_rules('dir', 'dir', 'trim|required|callback_dir_check');
        // if validation was successful with no errors
        if ($this->form_validation->run('authority_text_replace_translation_list_all')) {

            $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = $this->authoritytextreplacetranslation_model->countAllByAuthorityId(
                    $this->input->post('authority_id')
            );
            $this->data['authoritytextreplacetranslations'] = $this->authoritytextreplacetranslation_model->findAllByAuthorityId(
                    $this->input->post('authority_id'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('disclaimer_translation_details')) {

            $data = array();

            $disclaimer_translation = $this->authoritytextreplacetranslation_model->find(
                    $this->input->post('id')
            );

            if ($disclaimer_translation) {
                $data['success'] = TRUE;
                $data['disclaimer_translation'] = $disclaimer_translation;
            } else {
                $data['error'] = 'Disclaimer Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_textreplacetranslation_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $authoritytextreplace_translation = $this->authoritytextreplacetranslation_model->find($id);
            if ($authoritytextreplace_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $record = array();
                $id = $this->input->post('id');
                $record['look_for'] = $this->input->post('look_for');
                $record['action'] = $this->input->post('action');
                $record['replace_with'] = $this->input->post('replace_with');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $record['code'] = isset($language) ? $this->input->post('code') : '';
                $record['language'] = isset($language) ? $language : '';
                $record['created'] = $current_date;
                $record['created_by'] = $_SESSION["seuname"];
                $record['modified'] = $current_date;
                $record['modified_by'] = $_SESSION["seuname"];

                $db_authoritytextreplacetranslatio_translation = $this->authoritytextreplacetranslation_model->findOneByIdAndCode($id);
                
//                echo '<pre>';
//                print_r($db_disclaimer_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($disclaimer_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_authoritytextreplacetranslatio_translation->id==$authoritytextreplace_translation->id) {
                    $authoritytextreplace_translation_id = $this->authoritytextreplacetranslation_model->update($id, $record);
                    if ($authoritytextreplace_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    
    
    
    
//    
//    
//    public function saveauthoritytextreplacetranslation() {
//
//        $this->form_validation->set_rules('authority_id', 'authority_id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
//        $this->form_validation->set_rules('look_for', 'look_for', 'trim|max_length[500]');
//        $this->form_validation->set_rules('action', 'action', 'trim|max_length[50]');
//        $this->form_validation->set_rules('replace_with', 'replace_with', 'trim|max_length[3000]');
//        if ($this->form_validation->run()) {
//
//            // Setting values for selfserve_user table columns
//            $atrtprecord = array();
//            $atrtprecord['authority_id'] = $this->input->post('authority_id');
//            $atrtprecord['look_for'] = $this->input->post('look_for');
//            $atrtprecord['action'] = $this->input->post('action');
//            $atrtprecord['replace_with'] = $this->input->post('replace_with');
//            $id = $this->input->post('id') ? $this->input->post('id') : 0;
//            $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
//            $authoritytextreplacetranslation = $this->authoritytextreplacetranslation_model->find($id);
//            if ($authoritytextreplacetranslation) {
//                $this->authoritytextreplacetranslation_model->update($id, $atrtprecord);
//                $this->data['status'] = 'SUCCESS';
//            } else {
//                $this->authoritytextreplacetranslation_model->insert($atrtprecord);
//                $this->data['status'] = 'SUCCESS';
//            }
//        } else {
//            $this->data['status'] = 'FAIL';
//            $this->data['message'] = strip_tags(validation_errors());
//        }
//
//        $this->output->set_content_type('application/json');
//        echo json_encode($this->data);
//        exit;
//    }
    
    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_textreplacetranslation_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $record = array();
            $record['authority_id'] = $this->input->post('authority_id');
            $record['look_for'] = $this->input->post('look_for');
            $record['action'] = $this->input->post('action');
            $record['replace_with'] = $this->input->post('replace_with');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $record['code'] = isset($language) ? $this->input->post('code') : '';
            $record['language'] = isset($language) ? $language : '';
            $record['created'] = $current_date;
            $record['created_by'] = $_SESSION["seuname"];
            $record['modified'] = $current_date;
            $record['modified_by'] = $_SESSION["seuname"];

            $db_authoritytextreplacetranslation = $this->authoritytextreplacetranslation_model->findOneByIdAndCode($record['authority_id'], $record['code']);
            if (!$db_authoritytextreplacetranslation) {
                $authoritytextreplacetranslation_id = $this->authoritytextreplacetranslation_model->insert($record);
                if ($authoritytextreplacetranslation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('authoritytextreplacetranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $authoritytextreplacetranslation = $this->authoritytextreplacetranslation_model->find($id);
                if ($authoritytextreplacetranslation) {
                    if (!$this->authoritytextreplacetranslation_model->delete($id)) {
                        $data['error'] = 'Delete Text Replace Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Disclaimer Text Replac not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file disclaimertranslation.php */
/* Location: ./application/controllers/disclaimertranslation.php */    
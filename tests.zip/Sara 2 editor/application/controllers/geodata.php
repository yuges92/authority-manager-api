<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Geodata extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->model('geodata_model', '', TRUE);
    }

    public function findtownsbyname() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_key = '';
        
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }
            
            $geodatas = $this->geodata_model->findAllByName($search_key);
            if (!$geodatas) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['towns'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($geodatas);
                $this->data['geodatas'] = $geodatas;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    
    public function findcountiesbyname() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $search_key = '';
        
        $this->form_validation->set_rules('search_key', 'search_key', 'trim|min_length[2]|max_length[30]');
        
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            if ($this->input->post('search_key')) {
                $search_key = trim($this->input->post('search_key'));
            }
            
            $geodatas = $this->geodata_model->findAllCountiesByName($search_key);
            if (!$geodatas) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['geodatas'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = count($geodatas);
                $this->data['geodatas'] = $geodatas;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }
    
     public function countieslistall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $geodatas = $this->geodata_model->findAllCounties();
        if (!$geodatas) {
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = 0;
            $this->data['geodatas'] = array();
        } else {
            $this->data['status'] = 'SUCCESS';
            $this->data['total'] = count($geodatas);
            $this->data['geodatas'] = $geodatas;
        }
     
        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

}

/* End of file authority.php */
/* Location: ./application/controllers/geodata.php */    
<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class AnswerTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('answertranslation_model', '', TRUE);
    }

    public function getallbyanswer() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('answerid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|answertranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->answertranslation_model->countAllByAnswer(
                    $this->input->post('answerid')
            );

            $answertranslations = $this->answertranslation_model->findAllByAnswer(
                    $this->input->post('answerid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['answertranslations'] = $answertranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('answer_translation_details')) {

            $data = array();

            $answer_translation = $this->answertranslation_model->find(
                    $this->input->post('id')
            );

            if ($answer_translation) {
                $data['success'] = TRUE;
                $data['answer_translation'] = $answer_translation;
            } else {
                $data['error'] = 'Answer Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_answer_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $answer_translation = $this->answertranslation_model->find($id);
            if ($answer_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $atrecord = array();
                $atrecord['answerid'] = $this->input->post('answerid');
                $atrecord['description'] = $this->input->post('description');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $atrecord['code'] = isset($language) ? $this->input->post('code') : '';
                $atrecord['language'] = isset($language) ? $language : '';
                $atrecord['created'] = $current_date;
                $atrecord['created_by'] = $_SESSION["seuname"];
                $atrecord['modified'] = $current_date;
                $atrecord['modified_by'] = $_SESSION["seuname"];

                $db_answer_translation = $this->answertranslation_model->findOneByAnswerIdAndCode($atrecord['answerid'], $atrecord['code']);
                
//                echo '<pre>';
//                print_r($db_disclaimer_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($disclaimer_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_answer_translation->id==$answer_translation->id) {
                    $answer_translation_id = $this->answertranslation_model->update($answer_translation->id, $atrecord);
                    if ($answer_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_answer_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $atrecord = array();
            $atrecord['answerid'] = $this->input->post('answerid');
            $atrecord['description'] = $this->input->post('description');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $atrecord['code'] = isset($language) ? $this->input->post('code') : '';
            $atrecord['language'] = isset($language) ? $language : '';
            $atrecord['created'] = $current_date;
            $atrecord['created_by'] = $_SESSION["seuname"];
            $atrecord['modified'] = $current_date;
            $atrecord['modified_by'] = $_SESSION["seuname"];

            $db_answer_translation = $this->answertranslation_model->findOneByAnswerIdAndCode($atrecord['answerid'], $atrecord['code']);
            if (!$db_answer_translation) {
                $answer_translation_id = $this->answertranslation_model->insert($atrecord);
                if ($answer_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('answertranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $answer_translation = $this->answertranslation_model->find($id);
                if ($answer_translation) {
                    if (!$this->answertranslation_model->delete($id)) {
                        $data['error'] = 'Delete Answer Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Answer Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file answertranslation.php */
/* Location: ./application/controllers/answertranslation.php */    
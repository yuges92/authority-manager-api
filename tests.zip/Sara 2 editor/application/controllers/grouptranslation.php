<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class GroupTranslation extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');

        $this->load->model('grouptranslation_model', '', TRUE);
    }

    public function getallbygroup() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('sectionid', 'sectionid', 'trim|required|numeric');
        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|grouptranslation_sort_check');
        $this->form_validation->set_rules('dir', 'dir', 'trim|dir_validation');

        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $total = $this->grouptranslation_model->countAllByGroup(
                    $this->input->post('sectionid')
            );

            $grouptranslations = $this->grouptranslation_model->findAllByGroup(
                    $this->input->post('sectionid'), $this->input->post('start'), $this->input->post('limit'), $this->input->post('sort'), $this->input->post('dir')
            );

            $this->data['success'] = TRUE;
            $this->data['total'] = $total;
            $this->data['grouptranslations'] = $grouptranslations;
        } else {
            $this->data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        if ($this->form_validation->run('group_translation_details')) {

            $data = array();

            $group_translation = $this->grouptranslation_model->find(
                    $this->input->post('id')
            );

            if ($group_translation) {
                $data['success'] = TRUE;
                $data['group_translation'] = $group_translation;
            } else {
                $data['error'] = 'Group Translation not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_group_translation')) {

            $data = array();

            $id = $this->input->post('id');
            $group_translation = $this->grouptranslation_model->find($id);
            if ($group_translation) {

                $current_date = date(DATE_FORMAT, time());

                // Setting values for selfserve_user table columns
                $gtrecord = array();
                $gtrecord['sectionid'] = $this->input->post('sectionid');
                $gtrecord['name'] = $this->input->post('name');
                $gtrecord['description'] = $this->input->post('description');
                $language_codes = $this->config->item('valid_language_codes');
                $language = $language_codes[$this->input->post('code')];
                $gtrecord['code'] = isset($language) ? $this->input->post('code') : '';
                $gtrecord['language'] = isset($language) ? $language : '';
                $gtrecord['created'] = $current_date;
                $gtrecord['created_by'] = $_SESSION["seuname"];
                $gtrecord['modified'] = $current_date;
                $gtrecord['modified_by'] = $_SESSION["seuname"];

                $db_group_translation = $this->grouptranslation_model->findOneByGroupIdAndCode($gtrecord['sectionid'], $gtrecord['code']);
                
//                echo '<pre>';
//                print_r($db_group_translation);
//                echo '</pre>';
//                
//                echo '<pre>';
//                print_r($group_translation);
//                echo '</pre>';
//                exit;
                
                if ($db_group_translation->id==$group_translation->id) {
                    $group_translation_id = $this->grouptranslation_model->update($group_translation->id, $gtrecord);
                    if ($group_translation_id) {
                        $data['success'] = TRUE;
                    } else {
                        $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                    }
                } else {
                    $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_NOT_FOUND;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_group_translation')) {

            $data = array();

            $current_date = date(DATE_FORMAT, time());

            // Setting values for selfserve_user table columns
            $gtrecord = array();
            $gtrecord['sectionid'] = $this->input->post('sectionid');
            $gtrecord['name'] = $this->input->post('name');
            $gtrecord['description'] = $this->input->post('description');
            $language_codes = $this->config->item('valid_language_codes');
            $language = $language_codes[$this->input->post('code')];
            $gtrecord['code'] = isset($language) ? $this->input->post('code') : '';
            $gtrecord['language'] = isset($language) ? $language : '';
            $gtrecord['created'] = $current_date;
            $gtrecord['created_by'] = $_SESSION["seuname"];
            $gtrecord['modified'] = $current_date;
            $gtrecord['modified_by'] = $_SESSION["seuname"];

            $db_group_translation = $this->grouptranslation_model->findOneByGroupIdAndCode($gtrecord['sectionid'], $gtrecord['code']);
            if (!$db_group_translation) {
                $group_translation_id = $this->grouptranslation_model->insert($gtrecord);
                if ($group_translation_id) {
                    $data['success'] = TRUE;
                } else {
                    $data['error'] = TRANSLATION_COULD_NOT_SAVE_TO_DATABASE;
                }
            } else {
                $data['error'] = TRANSLATION_RECORD_ALREADY_EXISTS;
            }
        } else {
            $data['error'] = strip_tags(validation_errors());
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        $this->form_validation->set_rules('id', 'id', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {
            if ($this->input->post('id')) {
                $this->load->model('grouptranslation_model', '', TRUE);
                $id = $this->input->post('id');
                $group_translation = $this->grouptranslation_model->find($id);
                if ($group_translation) {
                    if (!$this->grouptranslation_model->delete($id)) {
                        $data['error'] = 'Delete Group Translation failed';
                    } else {
                        $data['success'] = TRUE;
                    }
                } else {
                    $data['error'] = 'Group Translation not found';
                }
            } else {
                $data['error'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

}

/* End of file grouptranslation.php */
/* Location: ./application/controllers/grouptranslation.php */    
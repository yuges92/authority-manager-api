<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class SectionIdea extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->model('sectionidea_model', '', TRUE);
    }

    public function listall() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('start', 'start', 'trim|required|is_natural|less_than[10000]');
        $this->form_validation->set_rules('limit', 'limit', 'trim|required|is_natural|less_than[1001]');
        $this->form_validation->set_rules('sort', 'sort', 'trim|required|sectionidea_sort_validation');
        $this->form_validation->set_rules('dir', 'dir', 'trim|required|dir_validation');
        // if validation was successful with no errors
        if ($this->form_validation->run()) {

            $sectionid = 0;
            if ($this->input->post('sectionid')) {
                $sectionid = trim($this->input->post('sectionid'));
            }

            $total = $this->sectionidea_model->countAll($sectionid);
            $sectionideas = $this->sectionidea_model->findAll(
                    $sectionid,
                    $this->input->post('start'),
                    $this->input->post('limit'),
                    $this->input->post('sort'),
                    $this->input->post('dir')
                    );
            if (!$sectionideas) {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = 0;
                $this->data['sectionideas'] = array();
            } else {
                $this->data['status'] = 'SUCCESS';
                $this->data['total'] = $total;
                $this->data['sectionideas'] = $sectionideas;
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $pkey = $this->input->post('pkey');
        if ($pkey) {
            $sectionidea = $this->sectionidea_model->find($pkey);
            if ($sectionidea) {
                $this->data['status'] = 'SUCCESS';
                $this->data['sectionidea'] = $sectionidea;
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = 'Authority Not Found!';
            }
        } else {
            $this->output->set_status_header('400'); //Triggers the jQuery error callback
            $this->data['status'] = 'FAIL';
            $this->data['message'] = 'Invalid Authority id';
        }

        $this->output->set_content_type('application/json');
        $this->output->set_output(json_encode($this->data));
    }

    public function edit() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('edit_sectionidea')) {
            $pkey = $this->input->post('pkey');
            $sectionidea = $this->sectionidea_model->find($pkey);
            if ($sectionidea) {

                // Setting values for selfserve_user table columns
                $arecord = array();
                $arecord['[order]'] = $this->input->post('order');
                
                $updated = $this->sectionidea_model->update($pkey, $arecord);
                if ($updated) {
                    $this->data['success'] = TRUE;
                } else {
                    $this->data['failure'] = TRUE;
                    $this->data['responseText'] = "Could not save order to database.";
                }
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Section idea not found";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    public function create() {

//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }

        if ($this->form_validation->run('new_authority')) {

            // Setting values for selfserve_user table columns
            $arecord = array();
            $arecord['supplier_id'] = $this->input->post('supplier_id');
            $arecord['full_name'] = $this->input->post('full_name');
            $arecord['short_name'] = $this->input->post('short_name');
            $arecord['authority_type'] = $this->input->post('authority_type');
            $arecord['email'] = $this->input->post('email');
            $arecord['local_authority_url'] = $this->input->post('local_authority_url');
            $arecord['website'] = $this->input->post('website');
            $arecord['always_disclaimer'] = $this->input->post('always_disclaimer') === 'on' ? 'Y' : 'N';
            $arecord['postcodes'] = $this->input->post('postcodes');
            $arecord['introduction'] = $this->input->post('introduction');
            $arecord['report_results_message'] = $this->input->post('report_results_message');
            $arecord['report_no_results_message'] = $this->input->post('report_no_results_message');
            $arecord['disclaimer_text'] = $this->input->post('disclaimer_text');
            $arecord['disclaimer_text_cy'] = $this->input->post('disclaimer_text_cy');
            $arecord['local_authority'] = $this->input->post('local_authority') === 'on' ? 'Y' : 'N';
            $arecord['retailer_location'] = $this->input->post('retailer_location');

            $last_id = $this->sectionidea_model->insert($arecord);
            if ($last_id) {
                if (!empty($_FILES) && isset($_FILES['authority_picture']) && $_FILES['authority_picture']['size'] > 0) {
                    $filename = $last_id . ".jpg";
                    $upload_result = $this->_handleImageUpload($filename);
                    if ($upload_result['error'] === 0) {
                        $arecord['filename'] = $filename;
                        $this->sectionidea_model->update($last_id, $arecord);
                    } else {
                        log_message('error', "Could not save image filename to database: $filename. " . strip_tags($upload_result['message']));
                        //$this->data['failure'] = TRUE;
                        $this->data['responseText'] = "Could not save image filename to database: $filename";
                    }
                }
                $this->data['success'] = TRUE;
            } else {
                $this->data['failure'] = TRUE;
                $this->data['responseText'] = "Could not save authority to database.";
            }
        } else {
            $this->data['failure'] = TRUE;
            $this->data['responseText'] = strip_tags(validation_errors());
        }
        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }
    
    public function delete() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $this->form_validation->set_rules('pkey', 'pkey', 'trim|numeric|is_natural_no_zero|less_than[100000]');
        if ($this->form_validation->run()) {

            if ($this->input->post('pkey')) {

                $pkey = $this->input->post('pkey');
                $sectionidea = $this->sectionidea_model->find($pkey);
                if ($sectionidea) {
                    if (!$this->sectionidea_model->delete($pkey)) {
                        $this->data['status'] = 'FAIL';
                        $this->data['message'] = 'Delete Section Idea failed';
                    } else {
                        $this->data['status'] = 'SUCCESS';
                    }
                } else {
                    $this->data['status'] = 'FAIL';
                    $this->data['message'] = 'Section Idea not found';
                }
            } else {
                $this->output->set_status_header('400'); //Triggers the jQuery error callback
                $this->data['status'] = 'FAIL';
                $this->data['message'] = strip_tags(validation_errors());
            }
        }

        $this->output->set_content_type('application/json');
        echo json_encode($this->data);
        exit;
    }

}

/* End of file section.php */
/* Location: ./application/controllers/section.php */    
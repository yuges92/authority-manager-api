<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Group extends MY_Controller {

    function __construct() {
        parent::__construct();

        if (!isset($_SESSION["seuname"])) {
            require_once '../../lib/system_constants.php';
            redirect(APP_BASE_URL . "login.php\n\n");
        }

        $this->config->load('form_validation');
        $this->load->library('form_validation');
        $this->load->model('group_model', '', TRUE);
    }

    public function details() {

        if (!IS_AJAX) {
            exit('No direct script access allowed');
        }

        $data = array();
        if ($this->form_validation->run('group_details')) {

            $group = $this->group_model->find(
                    $this->input->post('sectionid')
            );

            if ($group) {
                $data['success'] = TRUE;
                $data['group'] = $group;
            } else {
                $data['error'] = 'Group not found!';
            }
        } else {
            $data['error'] = validation_errors();
        }

        $this->output->set_content_type('application/json');
        echo json_encode($data);
        exit;
    }

    public function builtTree() {
        return array();
//        if (!IS_AJAX) {
//            exit('No direct script access allowed');
//        }
//
//        $groups=array();
//        $sectionid = $this->input->post('sectionid');
//       // if (isInteger($sectionid)) {
//       //     $groups = $this->_getGroups($sectionid); 
//       // } else {
//            $groups = $this->group_model->findTopGroups();
//       // }
//
//        $this->data['nodes'] = $groups;
//        
//        $this->output->set_content_type('application/json');
//        $this->output->set_output(json_encode($this->data));
    }

    function _getTopGroups() {

        $nodes = array();

        $groupDAO = GroupDAO::getInstance();
        $groups = $groupDAO->findTop();

        foreach ($groups as $group) :
            $nodes[] = buildGroupNode($group);
        endforeach;

        return $nodes;
    }

    function _getGroups($sectionid) {

        $nodes = array();

        // find groups
        $groupDAO = GroupDAO::getInstance();
        $groups = $groupDAO->findChildren($sectionid);
        foreach ($groups as $group)
            array_push($nodes, buildGroupNode($group));

        // find sections
        $sectionDAO = SectionDAO::getInstance();
        $sections = $sectionDAO->findAllByParentID($sectionid);
        foreach ($sections as $section)
            array_push($nodes, buildSectionNode($section));

        return $nodes;
    }

    public function dir_check($str) {
        if (!in_array($str, array('DESC', 'ASC'))) {
            $this->form_validation->set_message('active_check', 'The %s field is not valid');
            return FALSE;
        } else {
            return TRUE;
        }
    }

    /*
      private function _save_image($ifile) {
      $this->load->library('upload');
      $this->config->load('file_upload', TRUE);
      $upload_settings = $this->config->item('authority_picture', 'file_upload');
      $upload_settings['file_name'] = $ifile;
      $upload_result = array('error' => 0);
      if ($_FILES['authority_picture']['error'] === 0) {
      $config['allowed_types'] = 'jpg|jpeg';
      $config['max_size'] = "1000KB";
      if (!file_exists($upload_settings['upload_path'])) {
      mkdir($upload_settings['upload_path'], 0777, true); // create dir if not exists
      }
      $this->upload->initialize($upload_settings);
      if (!$this->upload->do_upload('authority_picture')) {
      $upload_result = array('error' => 1, 'message' => $this->upload->display_errors());
      }
      } else {
      $upload_result = array('error' => 1, 'message' => $_FILES['authority_picture']['error']);
      }

      return $upload_result;
      }
     */
}

/* End of file authority.php */
/* Location: ./application/controllers/authority.php */    
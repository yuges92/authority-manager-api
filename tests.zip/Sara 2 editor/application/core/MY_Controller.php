<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/* File: application/core/BaseController.php 
 * 
 * To protect an entire application
 * 
 *  */
class MY_Controller extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if( !authenticated() ) {
            if (IS_AJAX) {
                $this->output->set_status_header('999', 'Unauthorized User!'); //Triggers the jQuery error callback
                exit;
            } else {
                //header("Location: " . APP_BASE_URL . "login.php\n\n");
                redirect(APP_BASE_URL . "login.php\n\n");
            }
        }
        
    }
}
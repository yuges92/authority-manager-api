<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

// required to change the default behavior of the post() XSS beahviour
// Now we can turn off global XSS filtering and it will automatically filter inputs unless we 
// specify false as the second parameter in our call to the Input library's post() method. 
// Just one method down is the get() method, and we can change that in the same way.
class MY_Input extends CI_Input {

    function __construct()
    {
        parent::__construct();
    }

    function post($index = '', $xss_clean = TRUE)
    {
        return parent::post($index, $xss_clean);
    }
}